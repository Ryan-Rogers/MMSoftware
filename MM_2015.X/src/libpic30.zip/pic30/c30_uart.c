/*
 *  Provides a definition for __C30_UART
 */

int __C30_UART=1;
