#include "crc.h"

/******************************************************************************
 * Function:        void CRC_Config(UINT16 poly , UINT16 config)
 *
 * PreCondition:    None   
 *
 * Input:           poly - Polynomial to calculate CRC
 *                  config - CRC Control reg value
 *                  
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        This function configures CRC module
 *
 * Note:            None
 *****************************************************************************/

#if defined (_CRC_PROG_V1)

void CRC_Config(UINT16 poly , UINT16 config)
{
   CRCXOR = poly;
   CRCCON = config;
}

#elif defined (_CRC_PROG_V2)

void CRC_Config(UINT32 poly, UINT16 config1, UINT16 config2)
{
   CRCXORL = (UINT16)(poly & 0x0000FFFF);
   CRCXORH = (UINT16)(poly >> 16);
   CRCCON1 = config1;
   CRCCON2 = config2;
}   

#else
#warning "Does not build on this target"
#endif
