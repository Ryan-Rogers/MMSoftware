#include "crc.h"

#if defined (_CRC_PROG_V1) 

/******************************************************************************
 * Function:        UINT16 CRC_Calc_ChecksumWord(UINT16* data, UINT16 Number_of_words,
 *                                       UINT16 prev_CRC)
 *
 * PreCondition:    CRC Module must be configured   
 *
 * Input:           data - Pointer to the first data word for which CRC needs to be 
 *                         calculated.
 *                  Number_of_words - Total number of words for which CRC needs to be 
 *                         calculated.
 *                  prev_CRC - previous CRC result. Note*
 *                  
 * Output:          Returns Two Byte CRC checksum based on the set polynomial
 *
 * Side Effects:    None
 *
 * Overview:        This function calculates CRC checksum for the data provide by the user,
 *                  based on the polynomial set in the CRCXOR Register.
 *
 * Note:            This input parameter is provided as a provision to allow continuation
 *                  of previously computed checksum. In case the checksum is being calculated
 *                  for a fresh set of data then the input value for prev_CRC should be '0'.
 *****************************************************************************/

UINT16 CRC_Calc_ChecksumWord(UINT16* data, UINT16 Number_of_words, UINT16 prev_CRC)
{
   SET_CRC_RESULT(prev_CRC);
   Start_CRC_Calculation();
   do
   {
       while(1 != Get_CRC_FIFO_EMPTY_STATUS());
      
       while((0 == Get_CRC_FIFO_FULL_STATUS() && (0 < Number_of_words)))
       {
          WRITE_CRC_DATA_WORD(*data);
          data++;
          Number_of_words--;
       }
    }while (0 < Number_of_words);

   while(CRCCONbits.CRCFUL==1);	
   CRCDAT = 0x0000;	/* Do this to shift the last word out of the 	*/
			/* CRC shift register		        	*/

   while(1 != Get_CRC_FIFO_EMPTY_STATUS());
   Stop_CRC_Calculation();
   Nop(); 
   return(GET_CRC_RESULT());
}

/******************************************************************************
 * Function:        UINT16 CRC_Calc_ChecksumByte(UINT8* data, UINT16 Number_of_bytes,
 *                                       UINT16 prev_CRC)
 *
 * PreCondition:    CRC Module must be configured   
 *
 * Input:           data - Pointer to the first byte word for which CRC needs  
 *                         to be calculated.
 *                  Number_of_bytes - Total number of bytes for which CRC needs 
 *                         to be calculated.
 *                  prev_CRC - previous CRC result. Note*
 *                  
 * Output:          Returns One Byte CRC checksum based on the set polynomial
 *
 * Side Effects:    None
 *
 * Overview:        This function calculates CRC checksum for the data provide by ,
 *                  the user based on the polynomil set in the CRCXOR Register.
 *
 * Note:            This input parameter is provided as a provision to allow continuation
 *                  of previously computed checksum. In case the checksum is being calculated
 *                  for a fresh set of data then the input value for prev_CRC should be '0'.
 *****************************************************************************/

UINT16 CRC_Calc_ChecksumByte(UINT8* data, UINT16 Number_of_bytes, UINT16 prev_CRC)
{
   SET_CRC_RESULT(prev_CRC);
   Start_CRC_Calculation();
   do
   {
       while(1 != Get_CRC_FIFO_EMPTY_STATUS());
       
       while((0 == Get_CRC_FIFO_FULL_STATUS() && (0 < Number_of_bytes)))
       {
          WRITE_CRC_DATA_BYTE(*data);
          data++;
          Number_of_bytes--;
       }
   }while (0 < Number_of_bytes);

    while(CRCCONbits.CRCFUL==1);
    CRCDAT = 0x0000;	/* Do this to shift the last word out of the 	*/
			/* CRC shift register			        */

   while(1 != Get_CRC_FIFO_EMPTY_STATUS());
   Stop_CRC_Calculation();     
   Nop();
   return(GET_CRC_RESULT());
}

#elif defined (_CRC_PROG_V2)

/******************************************************************************
 * Function:        UINT16 CRC_Calc_ChecksumWord(UINT16* data, UINT16 Number_of_words,
 *                                       UINT16 prev_CRC)
 *
 * PreCondition:    CRC Module must be configured   
 *
 * Input:           data - Pointer to the first data word for which CRC needs to be 
 *                         calculated.
 *                  Number_of_words - Total number of words for which CRC needs to be 
 *                         calculated.
 *                  prev_CRC - previous CRC result. Note*
 *                  
 * Output:          Returns Two Byte CRC checksum based on the set polynomial
 *
 * Side Effects:    None
 *
 * Overview:        This function calculates CRC checksum for the data provide by the user,
 *                  based on the polynomial set in the CRCXOR Register.
 *
 * Note:            This input parameter is provided as a provision to allow continuation
 *                  of previously computed checksum. In case the checksum is being calculated
 *                  for a fresh set of data then the input value for prev_CRC should be '0'.
 *****************************************************************************/

UINT16 CRC_Calc_ChecksumWord(UINT16* data, UINT16 Number_of_words, UINT16 prev_CRC)
{
   SET_CRC_RESULT(prev_CRC);
   Start_CRC_Calculation();
   do
   {
       while(1 != Get_CRC_FIFO_EMPTY_STATUS());
      
       while((0 == Get_CRC_FIFO_FULL_STATUS() && (0 < Number_of_words)))
       {
          WRITE_CRC_DATA_WORD(*data);
          data++;
          Number_of_words--;
       }
    }while (0 < Number_of_words);

   while(CRCCON1bits.CRCFUL==1);	
   CRCDATL = 0x0000;	/* Do this to shift the last word out of the 	*/
			/* CRC shift register		        	*/

   while(1 != Get_CRC_FIFO_EMPTY_STATUS());
   Stop_CRC_Calculation();
   Nop(); 
   return(GET_CRC_RESULT());
}

/******************************************************************************
 * Function:        UINT16 CRC_Calc_ChecksumByte(UINT8* data, UINT16 Number_of_bytes,
 *                                       UINT16 prev_CRC)
 *
 * PreCondition:    CRC Module must be configured   
 *
 * Input:           data - Pointer to the first byte word for which CRC needs  
 *                         to be calculated.
 *                  Number_of_bytes - Total number of bytes for which CRC needs 
 *                         to be calculated.
 *                  prev_CRC - previous CRC result. Note*
 *                  
 * Output:          Returns One Byte CRC checksum based on the set polynomial
 *
 * Side Effects:    None
 *
 * Overview:        This function calculates CRC checksum for the data provide by ,
 *                  the user based on the polynomil set in the CRCXOR Register.
 *
 * Note:            This input parameter is provided as a provision to allow continuation
 *                  of previously computed checksum. In case the checksum is being calculated
 *                  for a fresh set of data then the input value for prev_CRC should be '0'.
 *****************************************************************************/

UINT16 CRC_Calc_ChecksumByte(UINT8* data, UINT16 Number_of_bytes, UINT16 prev_CRC)
{
   SET_CRC_RESULT(prev_CRC);
   Start_CRC_Calculation();
   do
   {
       while(1 != Get_CRC_FIFO_EMPTY_STATUS());
       
       while((0 == Get_CRC_FIFO_FULL_STATUS() && (0 < Number_of_bytes)))
       {
          WRITE_CRC_DATA_BYTE(*data);
          data++;
          Number_of_bytes--;
       }
   }while (0 < Number_of_bytes);

    while(CRCCON1bits.CRCFUL==1);
    CRCDATL = 0x0000;	/* Do this to shift the last word out of the 	*/
			/* CRC shift register			        */

   while(1 != Get_CRC_FIFO_EMPTY_STATUS());
   Stop_CRC_Calculation();     
   Nop();
   return(GET_CRC_RESULT());
}

/******************************************************************************
 * Function:        UINT32 CRC_Calc_ChecksumDWord(UINT32* data, UINT16 Number_of_words,
 *                                       UINT32 prev_CRC)
 *
 * PreCondition:    CRC Module must be configured   
 *
 * Input:           data - Pointer to the first data double word for which CRC needs to be 
 *                         calculated.
 *                  Number_of_words - Total number of dwords for which CRC needs to be 
 *                         calculated.
 *                  prev_CRC - previous CRC result. Note*
 *                  
 * Output:          Returns Four Byte CRC checksum based on the set polynomial
 *
 * Side Effects:    None
 *
 * Overview:        This function calculates CRC checksum for the data provide by the user,
 *                  based on the polynomial set in the CRCXOR Register.
 *
 * Note:            This input parameter is provided as a provision to allow continuation
 *                  of previously computed checksum. In case the checksum is being calculated
 *                  for a fresh set of data then the input value for prev_CRC should be '0'.
 *****************************************************************************/

UINT32 CRC_Calc_ChecksumDWord(UINT32* data, UINT16 Number_of_words, UINT32 prev_CRC)
{
   unsigned int result_l,result_h;
   long unsigned int result;
   SET_CRC_RESULT_LO((UINT16)(prev_CRC));
   SET_CRC_RESULT_HI((UINT16)(prev_CRC >> 16));   
   Start_CRC_Calculation();
   do
   {
       while(1 != Get_CRC_FIFO_EMPTY_STATUS());
      
       while((0 == Get_CRC_FIFO_FULL_STATUS() && (0 < Number_of_words)))
       {
          WRITE_CRC_DATA_DWORDL((UINT16)(*data));
	  WRITE_CRC_DATA_DWORDH((UINT16)(*data >> 16));
          data++;
          Number_of_words--;
       }
    
   }while (0 < Number_of_words);

   while(CRCCON1bits.CRCFUL==1);	
   CRCDATH = 0x0000;			        	
   CRCDATL = 0x0000;	/* Do this to shift the last word out of the shift register */
   
   while(1 != Get_CRC_FIFO_EMPTY_STATUS());
   Stop_CRC_Calculation();
   Nop(); 
   result_l = CRCWDATL;
   result_h = CRCWDATH;
   result = result_h;
   result = result << 16;
   result = result | result_l ;

   return(result);
}

#else
#warning "Does not build on this target"
#endif
