#include "CTMU.h"

#ifdef _CTMUIF


/********************************************************************
*     Function Name :  ConfigIntCTMU                                *
*     Description   :  This routine configures the interrupts for   *
*                      the CTMU module.                             *
*     Parameters    :  config                                       *
*     Return Value  :  None                                         *
********************************************************************/

void ConfigIntCTMU(unsigned int config)

{

		_CTMUIF = 0;                   /* Clear IF bit */
		_CTMUIP = (config &0x0007);    /* Assign interrupt priority */
		_CTMUIE = (config &0x0008)>>3; /* Interrupt Enable/Disable bit */
		
}

#else
#warning "does not build on target"
#endif	
