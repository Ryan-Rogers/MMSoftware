#include "CTMU.h"

#ifdef _CTMUIF


/********************************************************************
*     Function Name :  OpenCTMU                                     *
*     Description   :  This routine enables the CTMU module         *
*                      			                            *
*     Parameters    :  config1, config2, config3                    *
*     Return Value  :  None                                         *
********************************************************************/


void OpenCTMU(unsigned int config1, unsigned int config2, unsigned int config3)

{

	CTMUCON1 = config1;
	CTMUCON2 = config2;
	CTMUICON = config3;
}

#else
#warning "Does not build on target"
#endif
