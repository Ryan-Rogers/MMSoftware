#include "CTMU.h"

#ifdef _CTMUIF

/********************************************************************
*     Function Name :  CloseCTMU                                    *
*     Description   :  This routine disables the CTMU module and its*
*                      interrupt bits.                              *
*     Parameters    :  None                                         *
*     Return Value  :  None                                         *
********************************************************************/


void CloseCTMU(void)
{
	
		_CTMUIF = 0; /* Disable the Interrupt flag bit in the
                                Interrupt Flag Control Register */ 
		_CTMUIE = 0; /* Disable the Interrupt bit in the 
                                Interrupt Enable Control Register */
		CTMUCON1bits.CTMUEN = 0;/* Disable the module. All pins controlled
                                by PORT Functions */

}

#else
#warning "does not build on target"
#endif		
