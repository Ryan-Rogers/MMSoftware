#include "CTMU.h"

#if defined _CTMUIF


/********************************************************************
*     Function Name :  CurrentControlCTMU                           *
*     Description   :  This routine sets the current levels for the *
*                      CTMU module				                    *
*     Parameters    :  config                                       *
*     Return Value  :  None                                         *
********************************************************************/

void CurrentControlCTMU(unsigned int config)

{

		CTMUICON = config;
		
}

#else
#warning "does not build on target"
#endif		
