#include <ports.h>

#if defined(__dsPIC33E__) || defined(__dsPIC24E__)

/********************************************************************
* Function Name     : ConfigCNPulldownPortA
* Description       : Configures the internal pull-up resistor bits for Port A
* Parameters        : None
* Return Value      : None
*********************************************************************/

#ifdef _CNPDA0

void ConfigCNPulldownPortA(unsigned int config)
{
    CNPDA = config;
}

#endif
/********************************************************************
* Function Name     : ConfigCNPulldownPortB
* Description       : Configures the internal pull-up resistor bits for Port B
* Parameters        : None
* Return Value      : None
*********************************************************************/
#ifdef _CNPDB0

void ConfigCNPulldownPortB(unsigned int config)
{
    CNPDB = config;
}

#endif
/********************************************************************
* Function Name     : ConfigCNPulldownPortC
* Description       : Configures the internal pull-up resistor bits for Port C
* Parameters        : None
* Return Value      : None
*********************************************************************/
#ifdef _CNPDC1
void ConfigCNPulldownPortC(unsigned int config)
{
    CNPDC = config;
}
#endif
/********************************************************************
* Function Name     : ConfigCNPulldownPortD
* Description       : Configures the internal pull-up resistor bits for Port D
* Parameters        : None
* Return Value      : None
*********************************************************************/
#ifdef _CNPDD5
void ConfigCNPulldownPortD(unsigned int config)
{
    CNPDD = config;
}
#endif
/********************************************************************
* Function Name     : ConfigCNPulldownPortE
* Description       : Configures the internal pull-up resistor bits for Port E
* Parameters        : None
* Return Value      : None
*********************************************************************/
#if defined (_CNPUE12) || defined (_CNPUE8)
void ConfigCNPulldownPortE(unsigned int config)
{
    CNPDE = config;
}
#endif
/********************************************************************
* Function Name     : ConfigCNPulldownPortF
* Description       : Configures the internal pull-up resistor bits for Port F
* Parameters        : None
* Return Value      : None
*********************************************************************/
#ifdef _CNPDF0
void ConfigCNPulldownPortF(unsigned int config)
{
    CNPDF = config;
}
#endif
/********************************************************************
* Function Name     : ConfigCNPulldownPortG
* Description       : Configures the internal pull-up resistor bits for Port G
* Parameters        : None
* Return Value      : None
*********************************************************************/
#ifdef _CNPDG6
void ConfigCNPulldownPortG(unsigned int config)
{
    CNPDG = config;
}
#endif
/********************************************************************
* Function Name     : ConfigCNPulldownPortH
* Description       : Configures the internal pull-up resistor bits for Port H
* Parameters        : None
* Return Value      : None
*********************************************************************/
#ifdef _CNPDH
void ConfigCNPulldownPortH(unsigned int config)
{
    CNPDH = config;
}

#endif

/********************************************************************
* Function Name     : ConfigCNPulldownPortJ
* Description       : Configures the internal pull-up resistor bits for Port J
* Parameters        : None
* Return Value      : None
*********************************************************************/
#ifdef _CNPDJ

void ConfigCNPulldownPortJ(unsigned int config)
{
    CNPDJ = config;
}

#endif
/********************************************************************
* Function Name     : ConfigCNPulldownPortK
* Description       : Configures the internal pull-up resistor bits for Port K
* Parameters        : None
* Return Value      : None
*********************************************************************/
#ifdef _CNPDK

void ConfigCNPulldownPortK(unsigned int config)
{
    CNPDK = config;
}

#endif


#endif
