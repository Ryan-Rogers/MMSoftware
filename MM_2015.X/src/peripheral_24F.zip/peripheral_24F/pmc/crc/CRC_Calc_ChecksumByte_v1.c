 #include "crc.h"
 
#if defined (crc_v1_2)  || defined (LIB_BUILD)
/***************************************************************************************
Function           : unsigned short int CRC_Calc_ChecksumByte(unsigned char* data, unsigned short int Number_of_bytes, 
                                                  unsigned short int prev_CRC)
                                          
Description        : This function calculates CRC checksum for the data provide by the 
                     user,based on the polynomial set in the CRCXOR Register.
 
Arguments          : data - Pointer to the first data byte for which CRC needs to    
                     be calculated.
                     Number_of_bytes - Total number of bytes for which CRC needs 
                     to be calculated.
                     prev_CRC - previous CRC result.
                     
Returns            : Returns One Byte CRC checksum based on the set polynomial.
 
Remarks            : Input parameter is provided as a provision to allow continuation 
                     of previously being computed checksum. In case the checksum is
                     being calculated for a fresh set of data then the input value for
                     prev_CRC should be '0'.
*****************************************************************************************/  
unsigned short int CRC_Calc_ChecksumByte_v1(unsigned char* data, unsigned short int Number_of_bytes, unsigned short int prev_CRC)
{
   SET_CRC_RESULT(prev_CRC);
   do
   {
       while(1 != Get_CRC_FIFO_EMPTY_STATUS_v1());
       Stop_CRC_Calulation_v1();
       while((0 == Get_CRC_FIFO_FULL_STATUS_v1() && (0 < Number_of_bytes)))
       {
          WRITE_CRC_DATA_BYTE(*data);
          data++;
          Number_of_bytes--;
       }
       Start_CRC_Calulation_v1();
   }while (0 < Number_of_bytes);

   while(1 != Get_CRC_FIFO_EMPTY_STATUS_v1());
   Nop();
   Nop();
   return(GET_CRC_RESULT());
}
#else
#warning "Does not build on this target"
#endif
