#include "crc.h"

#if defined (crc_v1_1) ||defined (crc_v1_2)|| defined (LIB_BUILD)
/********************************************************************************** 
   Function           : void CRC_Config_INTR(unsigned char intr_byte)
   
   Description        :This function configures CRC interrupts.
  
   Arguments          : intr_byte -  I2C interrupt priority and enable/disable
                        information as defined below
                        CRC Interrupt enable/disable
	                        *	CRC_INT_ENABLE
	                        *	CRC_INT_DISABLE
                        CRC Interrupt priority
	                        *	CRC_INT_PRIOR_7
	                        *	CRC_INT_PRIOR_6
	                        *	CRC_INT_PRIOR_5
	                        *	CRC_INT_PRIOR_4
	                        *	CRC_INT_PRIOR_3
	                        *	CRC_INT_PRIOR_2
	                        *	CRC_INT_PRIOR_1
	                        *	CRC_INT_PRIOR_0
   
   Returns            : None
   
   Remarks            : This function clears the Interrupt Flag bits, sets the
                        interrupt priorities of master and slave and enables/disables
                        the interrupt  
*************************************************************************************/                                                                                        

void CRC_Config_INTR(unsigned char intr_byte)
{
   IFS4bits.CRCIF = 0;                       /* clear the CRC Interrupts */

   IPC16bits.CRCIP = (intr_byte & 0x07);
   IEC4bits.CRCIE = (intr_byte & 0x08)>>3;
}
#else
#warning "Does not build on this target"
#endif
