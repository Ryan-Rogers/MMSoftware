#include "crc.h"
 
#if defined (crc_v1_1) || defined (LIB_BUILD)
/********************************************************************************* 
   Function           : void CRC_Config(unsigned short int poly , unsigned short int config)
   
   Description        : This function configures CRC module.
   
   Arguments          :  poly - Polynomial to calculate CRC
			 config - This contains the parameter configured in CRCCON
				      register as defined below
					  CRC Mode bit
						 *	CRC_IDLE_STOP
						 *	CRC_IDLE_CON
					  Valid words 
						 *	CRC_POLYNOMIAL_LEN1 
						 *	CRC_POLYNOMIAL_LEN2
						 *	CRC_POLYNOMIAL_LEN3 
						 *	CRC_POLYNOMIAL_LEN4
						 *	CRC_POLYNOMIAL_LEN5 
						 *	CRC_POLYNOMIAL_LEN6
						 *	CRC_POLYNOMIAL_LEN7 
						 *	CRC_POLYNOMIAL_LEN8
						 *	CRC_POLYNOMIAL_LEN9 
						 *	CRC_POLYNOMIAL_LEN20
						 *	CRC_POLYNOMIAL_LEN11 
						 *	CRC_POLYNOMIAL_LEN12
						 *	CRC_POLYNOMIAL_LEN13
						 *	CRC_POLYNOMIAL_LEN14 
						 *	CRC_POLYNOMIAL_LEN15
						 *	CRC_POLYNOMIAL_LEN16
					  Start CRC bit 
						 *	CRC_START_SERIAL_SHIFT
						 *	CRC_SERIAL_SHIFT_OFF
						             
   Returns            : None
   
   Remarks            : This function configures the XOR of polynomial term and
                        CRCCON register.                                                      
***********************************************************************************/
void CRC_Config(unsigned short int poly , unsigned short int config)
{
   CRCXOR = poly;
   CRCCON = config;
}
#else
#warning "Does not build on this target"
#endif
