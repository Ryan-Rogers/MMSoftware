 

#include "ctmu.h"

#if defined (ctmu_v1_1) || defined (ctmu_v2_1) || defined (ctmu_v2_2) || defined (ctmu_v2_3) || defined (ctmu_v2_4) ||defined (ctmu_v2_5) || defined (ctmu_v2_6) || defined (LIB_BUILD)
/*************************************************************************************
Function          : void CurrentControlCTMU(unsigned int config)

Overview          : This function selects the current source range and trims the
                         current source of CTMU.

Parameters        :  config - This contains the parameters to be configured in the
                           CTMU1CON register as defined below						   
						Current Source Trim bits
						  *CTMU_POS_CURR_TRIM_62
						  *CTMU_POS_CURR_TRIM_60
						  *....
						  *CTMU_POS_CURR_TRIM_4
						  *CTMU_POS_CURR_TRIM_2
						  *CTMU_NOMINAL_CURRENT
						  *CTMU_NEG_CURR_TRIM_2
						  *CTMU_NEG_CURR_TRIM_4
						  *...
						  *CTMU_NEG_CURR_TRIM_60
						  *CTMU_NEG_CURR_TRIM_62
						   Current Source Range Select bits
						  *CTMU_CURR_RANGE_100_BASE_CURR
						  *CTMU_CURR_RANGE_10_BASE_CURR
						  *CTMU_CURR_RANGE_BASE_CURR
						  *CTUM_CURR_SOURCE_DISABLE

Returns           : None

Remarks           : The level of current is user-selectable across three ranges or a total of two
                         orders of magnitude, with the ability to trim the output in �2% increments
************************************************************************************************/

void CurrentControlCTMU(unsigned int config)
{
	CTMUICON = config;
}

#else
#warning "Does not build on this target"
#endif
