 

#include "ctmu.h"

#if defined (ctmu_v2_4) ||defined (ctmu_v2_5) || defined (ctmu_v2_6) || defined (LIB_BUILD)

/*************************************************************************************
Function    : void OpenCTMU_v2_1(unsigned int config1,unsigned int config2, unsigned int config3)
                                  
Overview    : For seamless migration, it is recommended to call the above function as "OpenCTMU".  

Parameters  : config1 - This contains the parameters to be configured in the CTMUCON1 		register						   
              config2 - This contains the parameters to be configured in the 
                           CTMUCON2 register 
			  config3 - This contains the parameters to be configured in the 
					 CTMUICON 
					 
Returns     : None
			
Remarks     : This function configures the CTMU for the following parameters:
		       Operating mode, Sleep mode behavior, Edge Select,Delay generation,Current 
		       source trim and current source range select.
************************************************************************************************/

void OpenCTMU_v2_1(unsigned int config1,unsigned int config2 ,unsigned int config3)
{ 
   unsigned char i;
   
 /*Select the current source range and adjust the current source */
   CTMUICON = config3 ; 	
   CTMUCON2 = config2 ; 
   
   CTMUCON1bits.IDISSEN = 1; //discharge the connected circuit   
   for(i=0;i<150;i++)
   Nop();
   CTMUCON1bits.IDISSEN = 0; 
   
   CTMUCON1bits.CTMUEN = 0;
    /*Disable the current source*/  
   CTMUCON2bits.EDG1STAT = 0; 
   CTMUCON2bits.EDG2STAT = 0;
     
 /*Configure the CTMU*/
   CTMUCON1 = config1 & 0x3F00;  
   
   CTMUCON1bits.CTMUEN = 1;  //enable CTMU     	
}

#else
#warning "Does not build on this target"
#endif	
