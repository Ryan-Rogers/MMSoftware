 

#include "ctmu.h"

#if defined (ctmu_v2_1) || defined (ctmu_v2_2)|| defined (ctmu_v2_3) || defined (LIB_BUILD)

/*************************************************************************************
Function            : void OpenCTMU_v3 (unsigned int config1, unsigned int config2, unsigned int config3)
                                  
Overview    : For seamless migration, it is recommended to call the above function as "OpenCTMU".  

Parameters  : config1 - This contains the parameters to be configured in the CTMUCON1L register						   
          config2 - This contains the parameters to be configured in the CTMUCON1H register 
	config3 - This contains the parameters to be configured in the CTMUCON2L 
					 
Returns           : None
			
Remarks           : This function configures the CTMU for the following parameters:
		       Operating mode, Sleep mode behavior, Edge Select,Delay generation,Current 
		       source trim and current source range select.
************************************************************************************************/

void OpenCTMU_v3(unsigned int config1,unsigned int config2 ,unsigned int config3)
{ 
   unsigned char i;
   
 /*Select the current source range and adjust the current source */
   CTMUCON1H = config2 ; 
   CTMUCON2L = config3 ; 	
   
   CTMUCON1Lbits.IDISSEN = 1; //discharge the connected circuit   
   for(i=0;i<150;i++)
   Nop();
   CTMUCON1Lbits.IDISSEN = 0; 
   
   CTMUCON1Lbits.CTMUEN = 0;
	
 /*Disable the current source*/  
   CTMUCON1Hbits.EDG1STAT = 0;
   CTMUCON1Hbits.EDG2STAT = 0; 
     
 /*Configure the CTMU*/
   CTMUCON1L = config1 & 0x3FFF;  
   
   CTMUCON1Lbits.CTMUEN = 1;  //enable CTMU     	
}

#else
#warning "Does not build on this target"
#endif	
