 

#include "ctmu.h"

#if defined (ctmu_v1_1) || defined (LIB_BUILD)

/*************************************************************************************
Function            : void OpenCTMU_v1(unsigned int config1, unsigned int config2)
                                  
Overview    : For seamless migration, it is recommended to call the above function as "OpenCTMU". 

Parameters        : config1 - This contains the parameters to be configured in the 
                           CTMUCON register as defined below                     
							 
					 config2 - This contains the parameters to be configured in the 
					 CTMUICON register as defined below		
					 
Returns           : None
			
Remarks           : This function configures the CTMU for the following parameters:
		       Operating mode, Sleep mode behavior, Edge Select,Delay generation,Current 
		       source trim and current source range select.
************************************************************************************************/

void OpenCTMU_v1(unsigned int config1,unsigned int config2)
{ 
   unsigned char i;
   
 /*Select the current source range and adjust the current source */
   CTMUICON = config2 ; 	
   
   CTMUCONbits.IDISSEN = 1; //discharge the connected circuit   
   for(i=0;i<150;i++)
   Nop();
   CTMUCONbits.IDISSEN = 0; 
   
   CTMUCONbits.CTMUEN = 0;
    /*Disable the current source*/  
   CTMUCONbits.EDG1STAT = 0;
   CTMUCONbits.EDG2STAT = 0; 
     
 /*Configure the CTMU*/
   CTMUCON = config1 & 0x3FFC;  
   
   CTMUCONbits.CTMUEN = 1;  //enable CTMU     	
}

#else
#warning "Does not build on this target"
#endif	
