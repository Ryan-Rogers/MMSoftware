 

#include "ctmu.h"

#if defined (ctmu_v1_1) || defined (ctmu_v2_1) || defined (ctmu_v2_2) || defined (ctmu_v2_3) || defined (ctmu_v2_4) ||defined (ctmu_v2_5) || defined (ctmu_v2_6) || defined (ctmu_v3_1) || defined (ctmu_v3_2) || defined (ctmu_v3_3) || defined (LIB_BUILD)
/***************************************************************************************
Function           : void ConfigIntCTMU(unsigned int config)

Overview           : This function configures the CTMU interrupt.

Parameters         : config - CTMU interrupt priority and enable/disable information 
	                 as defined below 
					 
	                 CTMU Interrupt enable/disable
						*	CTMU_INT_ENABLE 
						*	CTMU_INT_DISABLE
					 CTMU Interrupt priority
	                    *	CTMU_INT_PRI_0 
	                    *	CTMU_INT_PRI_1
	                    *	CTMU_INT_PRI_2
	                    *	CTMU_INT_PRI_3
	                    *	CTMU_INT_PRI_4
	                    *	CTMU_INT_PRI_5
	                    *	CTMU_INT_PRI_6
	                    *	CTMU_INT_PRI_7
                                            
Returns            : None 

Remarks            : This function clears the Interrupt Flag bit and then sets the interrupt priority 
                          and enables/disables the interrupt. 
****************************************************************************************/

void ConfigIntCTMU(unsigned int config)
{
    /* Clearing the Interrupt Flag bit */
    IFS4bits.CTMUIF = 0;

    /* Setting Priority */
    IPC19bits.CTMUIP = config & 0x07;

    /* Setting the Interrupt enable bit */
    IEC4bits.CTMUIE = (config & 0x08)>>3;
}

#else
#warning "Does not build on this target"
#endif
