 

#include "ctmu.h"

#if defined (ctmu_v3_1) || defined (ctmu_v3_2)|| defined (ctmu_v3_3) || defined (LIB_BUILD)

/***********************************************************************************************
Function:    void CloseCTMU_v3(void)

Overview:    This function turns off the CTMU module and disables the CTMU interrupts. 

Parameters:  None 

Returns:     None
 
Remarks:     This function first disables the CTMU interrupt and then turns off the CTMU
             module.The Interrupt Flag bit is also cleared.
***********************************************************************************************/
void CloseCTMU_v3(void)
{
    /* disable CTMU interrupt */
    IEC4bits.CTMUIE = 0;

    /* turn off CTMU */
    CTMUCON1Lbits.CTMUEN = 0;
    
    /*turn off current source*/
    CTMUCON1Hbits.EDG1STAT = 0;
    CTMUCON1Hbits.EDG2STAT = 0;

    /* clear CTMUIF bit */
    IFS4bits.CTMUIF = 0;
}

#else
#warning "Does not build on this target"
#endif
