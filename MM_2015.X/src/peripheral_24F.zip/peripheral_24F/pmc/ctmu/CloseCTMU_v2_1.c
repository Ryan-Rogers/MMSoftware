#include "ctmu.h"

#if defined (ctmu_v2_4)||defined (ctmu_v2_5)|| defined (ctmu_v2_6) || defined (LIB_BUILD)

/***********************************************************************************************
Function:    void CloseCTMU_v2_1(void)

Overview:    This function turns off the CTMU module and disables the CTMU interrupts. 

Parameters:  None 

Returns:     None
 
Remarks:     This function first disables the CTMU interrupt and then turns off the CTMU
             module.The Interrupt Flag bit is also cleared.
***********************************************************************************************/
void CloseCTMU_v2_1(void)
{
    /* disable CTMU interrupt */
    IEC4bits.CTMUIE = 0;

    /* turn off CTMU */
    CTMUCON1bits.CTMUEN = 0;
    
    /*turn off current source*/
	CTMUCON2bits.EDG1STAT = 0; 
    CTMUCON2bits.EDG2STAT = 0;

    /* clear CTMUIF bit */
    IFS4bits.CTMUIF = 0;
}

#else
#warning "Does not build on this target"
#endif
