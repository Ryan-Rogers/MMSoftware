 
#include <incap.h>

#if defined (icap_v2_2) || defined (LIB_BUILD)
/********************************************************************
Function Prototype : void CloseCapture9(void)
 
Include            : incap.h
 
Description        : This function turns off the Input Capture module
 
Arguments          : None
 
Return Value       : None
 
Remarks            : This function disables the Input Capture interrupt 
                     and then turns off the module. The Interrupt 
                     Flag bit is also cleared.                                        
********************************************************************/
void CloseCapture9(void)
{
    IEC5bits.IC9IE = 0; /* disable the interrupt */
    IC9CON1bits.ICM = 0; /* Input Capture x(ic_no) Off */
    IFS5bits.IC9IF = 0; /* disable the interrupt flag */
}

#else
#warning "Does not build on this target"
#endif
