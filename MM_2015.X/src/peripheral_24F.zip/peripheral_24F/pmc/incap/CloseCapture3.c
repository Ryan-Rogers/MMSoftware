 
#include <incap.h>

#if defined (icap_v1_2) || defined (LIB_BUILD)
/********************************************************************
Function Prototype : void CloseCapture3(void)
 
Include            : incap.h
 
Description        : This function turns off the Input Capture module
 
Arguments          : None
 
Return Value       : None
 
Remarks            : This function disables the Input Capture interrupt 
                     and then turns off the module. The Interrupt 
                     Flag bit is also cleared.                                        
********************************************************************/
void CloseCapture3(void)
{
    IEC2bits.IC3IE = 0; /* disable the interrupt */
    IC3CONbits.ICM = 0; /* Input Capture x(ic_no) Off */
    IFS2bits.IC3IF = 0; /* disable the interrupt flag */
}

#else
#warning "Does not build on this target"
#endif
