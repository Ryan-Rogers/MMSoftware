 
#include "incap.h"

#if defined (icap_v3_2)  || defined (LIB_BUILD)
/*******************************************************************************
Function Prototype : unsigned int ReadCapture1_v3(void)
 
Include            : incap.h
 
Description        : This function reads all the pending Input Capture buffers.
 
Arguments          : buffer - This is the pointer to the locations where the 
                     data read from the Input Capture buffers have to be stored.
 
Return Value       : None
 
Remarks            : This function reads all the pending Input Capture buffers
                     until the buffers are empty indicated by the ICxCON<ICBNE>
                     bit getting cleared.
*******************************************************************************/
unsigned int ReadECapture1_v3(void)
{
  union CaptureResult
	{
	 unsigned int result;	// holds the 16-bit captured value
	 char byte[2];		// holds the 16-bit captured value
	}Cap;

 while (IFS1bits.CCP3IF)
    {
        
		Cap.byte[0]=CCPR3L;    /* Read CA1L into the lower byte*/
		Cap.byte[1]=CCPR3H;	 /* Read CA1H into the high byte*/	
	}	
	
	return (Cap.result);
}

#else
#warning "Does not build on this target"
#endif
