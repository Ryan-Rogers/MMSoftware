 
#include <incap.h>

#if defined (icap_v1_2) || defined (LIB_BUILD)
/*******************************************************************************
Function Prototype : void OpenCapture5_v1(unsigned int config)
 
Include            : incap.h
 
Description        : For seamless migration, it is recommended to call the above function as "OpenCapture5".
 
Arguments          : config - This contains the parameters to be configured in the
                     ICxCON register as defined below					
 
Return Value       : None
 
Remarks            : This function configures the input capture module.
********************************************************************************/

void OpenCapture5_v1(unsigned int config)
{
    /* Config contains Clock source, number of Captures per interuppt
                                    and Capture Mode */
    IC5CON = config;
}

#else
#warning "Does not build on this target"
#endif
