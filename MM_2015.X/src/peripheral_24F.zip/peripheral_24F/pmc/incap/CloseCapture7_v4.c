 
#include <incap.h>

#if defined (icap_v2_2) || defined (icap_v2_4)|| defined (LIB_BUILD)
/********************************************************************
Function Prototype : void CloseCapture7(void)
 
Include            : incap.h
 
Description        : This function turns off the Input Capture module
 
Arguments          : None
 
Return Value       : None
 
Remarks            : This function disables the Input Capture interrupt 
                     and then turns off the module. The Interrupt 
                     Flag bit is also cleared.                                        
********************************************************************/
void CloseCapture7(void)
{
    IEC1bits.IC7IE = 0; /* disable the interrupt */
    IC7CON1bits.ICM = 0; /* Input Capture x(ic_no) Off */
    IFS1bits.IC7IF = 0; /* disable the interrupt flag */
}

#else
#warning "Does not build on this target"
#endif
