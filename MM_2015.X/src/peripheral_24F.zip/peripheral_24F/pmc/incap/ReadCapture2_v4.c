 
#include <incap.h>


#if defined (icap_v2_1)  || defined (icap_v2_2)|| defined (icap_v2_3) || defined (icap_v2_4)|| defined (LIB_BUILD)
/*******************************************************************************
Function Prototype : void ReadCapture2_v4(unsigned int * buffer)
 
Include            : incap.h
 
Description        : This function reads all the pending Input Capture buffers.
 
Arguments          : buffer - This is the pointer to the locations where the 
                     data read from the Input Capture buffers have to be stored.
 
Return Value       : None
 
Remarks            : This function reads all the pending Input Capture buffers
                     until the buffers are empty indicated by the ICxCONx<ICBNE>
                     bit getting cleared.
*******************************************************************************/

void ReadCapture2_v4(unsigned int * buffer)
{
    while (IC2CON1bits.ICBNE)
    {
        *buffer++ = IC2BUF; /* reads the input capture buffer */
    }
}

#else
#warning "Does not build on this target"
#endif
