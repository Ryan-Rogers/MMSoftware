 
#include <incap.h>

#if defined (icap_v3_2) || defined (LIB_BUILD)
/*********************************************************************************
Function Prototype : void ConfigIntCapture3_v3(unsigned int config)
 
Include            : incap.h
 
Description        : This function configures the Input Capture interrupt.
 
Arguments          : config - Input Capture interrupt priority and enable/disable
                     information as defined below
					 
					 Interrupt enable/disable					
					   *	IC_INT_ON					
					   *	IC_INT_OFF					
					 Interrupt Priority					
					   *	IC_INT_PRIOR_0					
					   *	IC_INT_PRIOR_1					
					   *	IC_INT_PRIOR_2					
					   *	IC_INT_PRIOR_3					
					   *	IC_INT_PRIOR_4					
					   *	IC_INT_PRIOR_5					
					   *	IC_INT_PRIOR_6					
					   *	IC_INT_PRIOR_7
 
Return Value       : None
 
Remarks            : This function clears the Interrupt Flag bit and then sets 
                     the interrupt priority and enables/disables the interrupt.
**********************************************************************************/
void ConfigIntCapture3_v3(unsigned int config)
{
    IFS1bits.CCP3IF = 0;                     /* Clear IF bit */
    IPC6bits.CCP3IP = (config &0x0007);      /* assigning Interrupt Priority
                                             to IPC Control REgister */
    IEC1bits.CCP3IE = (config &0x0008) >> 3; /* assiging InputCapture Enable/
                                              Disable bit of IEC Register*/
}

#else
#warning "Does not build on this target"
#endif
