 
#include <incap.h>

#if defined (icap_v2_2) || defined (LIB_BUILD)
/*******************************************************************************
Function Prototype : void ReadCapture78(unsigned long int  * buffer)
 
Include            : incap.h
 
Description        : This function reads all the pending Input Capture buffers.
 
Arguments          : buffer - This is the pointer to the locations where the 
                     data read from the Input Capture buffers have to be stored.
 
Return Value       : None
 
Remarks            : This function reads all the pending Input Capture buffers
                     until the buffers are empty indicated by the ICxCONx<ICBNE>
                     bit getting cleared.
*******************************************************************************/

void ReadCapture78(unsigned long int  * buffer)
{
	unsigned long int  value =0;
	
	while (IC7CON1bits.ICBNE && IC8CON1bits.ICBNE)
	{
		value = IC8BUF;
		value = value<<16;
		value = value | IC7BUF;		
		*buffer++ = value; /* reads the input capture buffer */
	}
}


#else
#warning "Does not build on this target"
#endif
