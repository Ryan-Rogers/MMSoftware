 
#include <incap.h>

#if defined (icap_v2_2) || defined (icap_v2_4)|| defined (LIB_BUILD)
/*******************************************************************************
Function Prototype : void ReadCapture7(unsigned int * buffer)
 
Include            : incap.h
 
Description        : This function reads all the pending Input Capture buffers.
 
Arguments          : buffer - This is the pointer to the locations where the 
                     data read from the Input Capture buffers have to be stored.
 
Return Value       : None
 
Remarks            : This function reads all the pending Input Capture buffers
                     until the buffers are empty indicated by the ICxCONx<ICBNE>
                     bit getting cleared.
*******************************************************************************/

void ReadCapture7(unsigned int * buffer)
{
    while (IC7CON1bits.ICBNE)
    {
        *buffer++ = IC7BUF; /* reads the input capture buffer */
    }
}

#else
#warning "Does not build on this target"
#endif
