 
#include <incap.h>

#if defined (icap_v1_2) || defined (LIB_BUILD)
/*******************************************************************************
Function Prototype : void ReadCapture5(unsigned int * buffer)
 
Include            : incap.h
 
Description        : This function reads all the pending Input Capture buffers.
 
Arguments          : buffer - This is the pointer to the locations where the 
                     data read from the Input Capture buffers have to be stored.
 
Return Value       : None
 
Remarks            : This function reads all the pending Input Capture buffers
                     until the buffers are empty indicated by the ICxCON<ICBNE>
                     bit getting cleared.
*******************************************************************************/

void ReadCapture5(unsigned int * buffer)
{
    while (IC5CONbits.ICBNE)
    {
        *buffer++ = IC5BUF; /* reads the input capture buffer */
    }
}

#else
#warning "Does not build on this target"
#endif
