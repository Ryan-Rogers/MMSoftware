 
#include <incap.h>

#if defined (icap_v1_2) || defined (LIB_BUILD)
/*******************************************************************************
Function Prototype : void OpenCapture4(unsigned int config)
 
Include            : incap.h
 
Description        : This function configures the Input Capture module.
 
Arguments          : config - This contains the parameters to be configured in the
                     ICxCON register as defined below
					 
			 Idle mode operation					
			   *	IC_IDLE_CON					
			   *	IC_IDLE_STOP					
			 Clock select					
			   *	IC_TIMER2_SRC					
			   *	IC_TIMER3_SRC					
			 Captures per interrupt					
			   *	IC_INT_4CAPTURE					
			   *	IC_INT_3CAPTURE					
			   *	IC_INT_2CAPTURE					
			   *	IC_INT_1CAPTURE					
			   *	IC_INTERRUPT   					
			 IC mode select	
			   *	IC_INTERRUPT				
			   *	IC_EVERY_16_RISE_EDGE					
			   *	IC_EVERY_4_RISE_EDGE					
			   *	IC_EVERY_RISE_EDGE					
			   *	IC_EVERY_FALL_EDGE
			   *	IC_EVERY_EDGE					
			   *	IC_INPUTCAP_OFF
 
Return Value       : None
 
Remarks            : This function configures the input capture module.
********************************************************************************/
void OpenCapture4( unsigned int config)
{
    /* Config contains Clock source, number of Captures per interuppt
                                    and Capture Mode */
    IC4CON = config;
}

#else
#warning "Does not build on this target"
#endif
