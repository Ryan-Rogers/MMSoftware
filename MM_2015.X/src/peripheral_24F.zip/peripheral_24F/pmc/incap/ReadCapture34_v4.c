 
#include <incap.h>

#if defined (icap_v2_1) || defined (icap_v2_2) || defined (icap_v2_4)|| defined (LIB_BUILD)
/*******************************************************************************
Function Prototype : void ReadCapture34(unsigned long int  * buffer)
 
Include            : incap.h
 
Description        : This function reads all the pending Input Capture buffers.
 
Arguments          : buffer - This is the pointer to the locations where the 
                     data read from the Input Capture buffers have to be stored.
 
Return Value       : None
 
Remarks            : This function reads all the pending Input Capture buffers
                     until the buffers are empty indicated by the ICxCONx<ICBNE>
                     bit getting cleared.
*******************************************************************************/


void ReadCapture34(unsigned long int  * buffer)
{
	unsigned long int  value =0;
	
	while (IC3CON1bits.ICBNE && IC4CON1bits.ICBNE)
	{
		value = IC4BUF;
		value = value<<16;
		value = value | IC3BUF;		
		*buffer++ = value; /* reads the input capture buffer */
	}
}


#else
#warning "Does not build on this target"
#endif
