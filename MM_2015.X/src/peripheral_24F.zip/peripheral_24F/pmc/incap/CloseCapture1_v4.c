 
#include <incap.h>

#if defined (icap_v2_1) || defined (icap_v2_2) || defined (icap_v2_3)|| defined (icap_v2_4)|| defined (LIB_BUILD)
/********************************************************************
Function Prototype : void CloseCapture1_v4(void)
 
Include            : incap.h
 
Description        : This function turns off the Input Capture module
 
Arguments          : None
 
Return Value       : None
 
Remarks            : This function disables the Input Capture interrupt 
                     and then turns off the module. The Interrupt 
                     Flag bit is also cleared.                                        
********************************************************************/
void CloseCapture1_v4(void)
{
	IEC0bits.IC1IE = 0; /* disable the interrupt */
	IC1CON1bits.ICM = 0; /* Input Capture x(ic_no) Off */
    IFS0bits.IC1IF = 0; /* disable the interrupt flag */
}

#else
#warning "Does not build on this target"
#endif
