 
#include <incap.h>

#if defined (icap_v3_1) ||defined (icap_v3_2) || defined (LIB_BUILD)
/*******************************************************************************
Function Prototype : void OpenCapture1_v3(unsigned int config)
 
Include            : incap.h
 
Description        : This function configures the Input Capture module.
 
Arguments          :  config - This contains the parameters to be configured in the
                     CCPxCON register as defined below
					 
			 	
					Enable CCP Interrupts:
				    * CAPTURE_INT_ON        
				    * CAPTURE_INT_OFF  
				    * CAPTURE_INT_MASK
					Capture configuration
				     * CAP_EVERY_FALL_EDGE
				     * CAP_EVERY_RISE_EDGE 
				     * CAP_EVERY_4_RISE_EDGE  
				     * CAP_EVERY_16_RISE_EDGE
				     * CAP_MODE_MASK		
 
Return Value       : None
 
Remarks            : This function configures the input capture for idle mode, clock select,
                      capture per interrupt and mode select
********************************************************************************/
void OpenCapture1_v3(unsigned int config)
{
    CCP1CON = config & 0x0F;  // Configure capture
  if(config&0x80)
  {
    IFS0bits.CCP1IF = 0;   // Clear the interrupt flag
    IEC0bits.CCP1IE = 1;   // Enable the interrupt
  }
}

#else
#warning "Does not build on this target"
#endif
