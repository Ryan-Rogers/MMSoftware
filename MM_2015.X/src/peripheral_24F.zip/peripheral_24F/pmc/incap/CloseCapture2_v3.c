 
#include <incap.h>

#if defined (icap_v3_1) ||defined (icap_v3_2)  || defined (LIB_BUILD)
/********************************************************************
Function Prototype : void CloseCapture2_v3(void)
 
Include            : incap.h
 
Description        : This function turns off the Input Capture module
 
Arguments          : None
 
Return Value       : None
 
Remarks            : This function disables the Input Capture interrupt 
                     and then turns off the module. The Interrupt 
                     Flag bit is also cleared.                                        
********************************************************************/
void CloseCapture2_v3(void)
{
    IEC0bits.CCP2IE = 0; /* disable the interrupt */
    CCP2CON=0x00;           // Reset the CCP module
    IFS0bits.CCP2IF = 0; /* disable the interrupt flag */
}

#else
#warning "Does not build on this target"
#endif
