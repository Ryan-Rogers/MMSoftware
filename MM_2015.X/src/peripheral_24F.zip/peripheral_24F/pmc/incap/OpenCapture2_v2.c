 
#include <incap.h>

#if defined (icap_v2_1) || defined (icap_v2_2)|| defined (icap_v2_3) || defined (icap_v2_4)|| defined (LIB_BUILD)
/*******************************************************************************
Function Prototype : void OpenCapture2_GB(unsigned int config1, unsigned int config2)
 
Include            : incap.h
 
Description        : For seamless migration, it is recommended to call the above function as "OpenCapture2".
 
Arguments          : config1 - This contains the parameters to be configured in the ICxCON1 register 			   
					 config2 - This contains the parameters to be configured in the ICxCON2 register
					 		
Return Value       : None
 
Remarks            : This function configures the input capture module.
********************************************************************************/
void OpenCapture2_v2(unsigned int config1, unsigned int config2)
{
	IC2CON1 = config1;
	IC2CON2 = config2;
}

#else
#warning "Does not build on this target"
#endif
