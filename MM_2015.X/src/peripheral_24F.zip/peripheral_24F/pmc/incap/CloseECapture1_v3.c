 
#include <incap.h>

#if defined (icap_v3_2)  || defined (LIB_BUILD)
/********************************************************************
Function Prototype : void CloseECapture1_v3(void)
 
Include            : incap.h
 
Description        : This function turns off the Input Capture module
 
Arguments          : None
 
Return Value       : None
 
Remarks            : This function disables the Input Capture interrupt 
                     and then turns off the module. The Interrupt 
                     Flag bit is also cleared.                                        
********************************************************************/
void CloseECapture1_v3(void)
{
    IEC1bits.CCP3IE = 0; /* disable the interrupt */
    ECCP1CON=0x00;           // Reset the CCP module
    IFS1bits.CCP3IF = 0; /* disable the interrupt flag */
}

#else
#warning "Does not build on this target"
#endif
