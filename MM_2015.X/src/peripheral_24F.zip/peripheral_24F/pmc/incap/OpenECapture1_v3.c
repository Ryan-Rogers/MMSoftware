 
#include <incap.h>

#if defined (icap_v3_2) || defined (LIB_BUILD)
/*******************************************************************************
Function Prototype : void OpenECapture1_v3(unsigned int config)
 
Include            : incap.h
 
Description        : This function configures the Input Capture module.
 
Arguments          :  config - This contains the parameters to be configured in the
                     CCPxCON register as defined below
					 
			 	
			Enable ECCP Interrupts:
				    * CAPTURE_INT_ON        
				    * CAPTURE_INT_OFF  
				    * CAPTURE_INT_MASK
				Capture configuration
				     * ECAP_EVERY_FALL_EDGE
				     * ECAP_EVERY_RISE_EDGE 
				     * ECAP_EVERY_4_RISE_EDGE  
				     * ECAP_EVERY_16_RISE_EDGE
				     * ECAP_MODE_MASK		
 
Return Value       : None
 
Remarks            : This function configures the input capture for idle mode, clock select,
                      capture per interrupt and mode select
********************************************************************************/
void OpenECapture1_v3(unsigned int config)
{
    ECCP1CON = config & 0x0F;  // Configure capture
  if(config&0x80)
  {
    IFS1bits.CCP3IF = 0;   // Clear the interrupt flag
    IEC1bits.CCP3IE = 1;   // Enable the interrupt
  }
}

#else
#warning "Does not build on this target"
#endif
