 
#include <incap.h>

#if defined (icap_v1_2) || defined (LIB_BUILD)
/*********************************************************************************
Function Prototype : void ConfigIntCapture4(unsigned int config)
 
Include            : incap.h
 
Description        : This function configures the Input Capture interrupt.
 
Arguments          : config - Input Capture interrupt priority and enable/disable
                     information as defined below
					 
					 Interrupt enable/disable					
					   *	IC_INT_ON					
					   *	IC_INT_OFF					
					 Interrupt Priority					
					   *	IC_INT_PRIOR_0					
					   *	IC_INT_PRIOR_1					
					   *	IC_INT_PRIOR_2					
					   *	IC_INT_PRIOR_3					
					   *	IC_INT_PRIOR_4					
					   *	IC_INT_PRIOR_5					
					   *	IC_INT_PRIOR_6					
					   *	IC_INT_PRIOR_7
 
Return Value       : None
 
Remarks            : This function clears the Interrupt Flag bit and then sets 
                     the interrupt priority and enables/disables the interrupt.
**********************************************************************************/
void ConfigIntCapture4(unsigned int config)
{
    IFS2bits.IC4IF = 0;                   /* Clear IF bit */
    IPC9bits.IC4IP = (config &0x0007);    /* assigning Interrupt Priority
                                             to IPC Register             */
    IEC2bits.IC4IE = (config &0x0008) >> 3;/* assiging Interrupt Enable/
                                              Disable Register           */
}

#else
#warning "Does not build on this target"
#endif
