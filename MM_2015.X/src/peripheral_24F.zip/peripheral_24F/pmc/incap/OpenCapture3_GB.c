 
#include <incap.h>

/* These devices support Input Capture 3 thru Input Capture 6 */
#if defined (icap_v2_2) || defined (icap_v2_1) || defined (LIB_BUILD)
/*******************************************************************************
Function Prototype : void OpenCapture3_GB(unsigned int config1, unsigned int config2)
 
Include            : incap.h
 
Description        : This function configures the Input Capture module.
 
Arguments          : config1 - This contains the parameters to be configured in the
                     ICxCON1 register as defined below
					 
		 Idle mode operation					
		   *	IC_IDLE_CON					
		   *	IC_IDLE_STOP					
		 Clock select
		   *	IC_SYSCLK_SRC
		   *	IC_TIMER1_SRC					
		   *	IC_TIMER2_SRC					
		   *	IC_TIMER3_SRC
		   *	IC_TIMER4_SRC
		   *	IC_TIMER5_SRC					
		 Captures per interrupt					
		   *	IC_INT_4CAPTURE					
		   *	IC_INT_3CAPTURE					
		   *	IC_INT_2CAPTURE					
		   *	IC_INT_1CAPTURE					
		   *	IC_INTERRUPT   					
		 IC mode select	
		   *	IC_INTERRUPT				
		   *	IC_EVERY_16_RISE_EDGE					
		   *	IC_EVERY_4_RISE_EDGE					
		   *	IC_EVERY_RISE_EDGE					
		   *	IC_EVERY_FALL_EDGE
		   *	IC_EVERY_EDGE					
		   *	IC_INPUTCAP_OFF
					   
		 config2 - This contains the parameters to be configured in the
                     ICxCON2 register as defined below
					 
                     Cascade Module operation enable\disable
                       *	IC_CASCADE_ENABLE
                       *	IC_CASCADE_DISABLE 
                     Trigger Operation Select bit
                       *	IC_TRIGGER_ENABLE 
                       *	IC_SYNC_ENABLE
                     Timer Trigger bit
                       *	IC_TRIGGER_TIMER
                       *	IC_UNTRIGGER_TIMER 
                     Source selection for synchronisation and trigger operation
                       *	IC_SYNC_TRIG_IN_DISABLE
                       *	IC_SYNC_TRIG_IN_OC1	
                       *	IC_SYNC_TRIG_IN_OC2	
                       *	IC_SYNC_TRIG_IN_OC3
                       *	IC_SYNC_TRIG_IN_OC4
                       *	IC_SYNC_TRIG_IN_OC5
                       *	IC_SYNC_TRIG_IN_OC6
                       *	IC_SYNC_TRIG_IN_OC7
                       *	IC_SYNC_TRIG_IN_OC8
                       *	IC_SYNC_TRIG_IN_OC9
                       *	IC_SYNC_TRIG_IN_IC5
                       *	IC_SYNC_TRIG_IN_TMR1
                       *	IC_SYNC_TRIG_IN_TMR2
                       *	IC_SYNC_TRIG_IN_TMR3	
		   *	IC_SYNC_TRIG_IN_TMR4	
		   *	IC_SYNC_TRIG_IN_TMR5	
		   *	IC_SYNC_TRIG_IN_IC7		
		   *	IC_SYNC_TRIG_IN_IC8		
		   *	IC_SYNC_TRIG_IN_IC1		
		   *	IC_SYNC_TRIG_IN_IC2	
		   *	IC_SYNC_TRIG_IN_IC3
		   *	IC_SYNC_TRIG_IN_IC4		
		   *	IC_SYNC_TRIG_IN_CMP1	
		   *	IC_SYNC_TRIG_IN_CMP2	
		   *	IC_SYNC_TRIG_IN_CMP3	
		   *	IC_SYNC_TRIG_IN_AD		
		   *	IC_SYNC_TRIG_IN_CTMU	
		   *	IC_SYNC_TRIG_IN_IC6		
		   *	IC_SYNC_TRIG_IN_IC9
					 		
Return Value       : None
 
Remarks            : This function configures the input capture module.
********************************************************************************/
void OpenCapture3_GB(unsigned int config1, unsigned int config2)
{
	IC3CON1 = config1;
	IC3CON2 = config2;
}

#else
#warning "Does not build on this target"
#endif
