 
#include <outcompare.h>

#if defined (ocmp_v2_1) ||defined (ocmp_v2_2)|| defined (ocmp_v2_5)|| defined (LIB_BUILD)
/**************************************************************************
Function Prototype : void CloseOC56(void) 

Include            : outcompare.h
 
Description        : This function turns off the output compare cascade module.                    
 
Arguments          : None
 
Return Value       : None
 
Remarks            : This function disables the Output Compare interrupt and 
                     then turns off the module. The Interrupt Flag bit is 
                     also cleared for OC5 and OC6.
**************************************************************************/

void CloseOC56(void)
{   
    IEC2bits.OC5IE = 0;  /* Disable the Output Compare5 interrupt */    
    IEC2bits.OC6IE = 0; /* Disable the Output Compare6 interrupt*/
    	
    OC5CON1bits.OCM = 0;  /* Turn off Output Compare5 */
    OC6CON1bits.OCM = 0; /* Turn off Output Compare6*/      
    
    IFS2bits.OC5IF = 0;  /* Disable the Interrupt Flag of Output Compare5 */
    IFS2bits.OC6IF = 0; /* Disable the Interrupt Flag of Output Compare6 */
}

#else
#warning "Does not build on this target"
#endif
