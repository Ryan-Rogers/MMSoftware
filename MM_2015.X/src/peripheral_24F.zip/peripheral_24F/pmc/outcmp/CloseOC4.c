 
#include <outcompare.h>

#if defined (ocmp_v1_2) || defined (LIB_BUILD)
/**************************************************************************
Function Prototype : void CloseOC4(void) 

Include            : outcompare.h
 
Description        : This function turns off the Output Compare module.
 
Arguments          : None
 
Return Value       : None
 
Remarks            : This function disables the Output Compare interrupt and 
                     then turns off the module. The Interrupt Flag bit is 
                     also cleared.
**************************************************************************/
void CloseOC4(void)
{   
    IEC1bits.OC4IE = 0;/* Disable the Interrupt bit in IEC Register */
    OC4CONbits.OCM = 0;/* Turn off Output Compare */
    IFS1bits.OC4IF = 0;/* Disable the Interrupt Flag bit in IFS Register */
}

#else
#warning "Does not build on this target"
#endif
