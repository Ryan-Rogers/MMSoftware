 
#include <outcompare.h>

#if defined (ocmp_v2_3) || defined (ocmp_v2_2)  || defined (ocmp_v2_1) || defined (ocmp_v2_4)||defined (LIB_BUILD)
/*************************************************************************************
Function           : char SetDCOC12PWM_GB(unsigned long dutycycle,unsigned long period)

Include            : outcompare.h
 
Description        : This function configures the Output Compare Secondary Duty Cycle
                     register (OCxRS) when the module is in PWM mode.

Arguments          : dutycycle - This is the duty cycle value to be stored into Output
                     Compare Main Duty Cycle register (OCxR).
                     period - This is the period stored into Secondary register (OCxRS)
 
Return Value       : Returns '1' on successful loading value else return '-1'.
 
Remarks            : The Output Compare Main and Secondary register will be
                     configured with new value only if the module is in PWM mode.
**************************************************************************************/

char SetDCOC12PWM_GB(unsigned long dutycycle,unsigned long period)
{       
    if(((OC1CON1bits.OCM & 0x06) == 0x06) && ((OC2CON1bits.OCM & 0x06) == 0x06 ))/* check if OC is in PWM Mode */
    {
    	if(OC1CON2bits.OC32 == 1 && OC2CON2bits.OC32 == 1 ) /*check if OC is in cascade mode*/     
    	{
       		OC1R = dutycycle;       /* Odd OCx loaded with LSB */
       		OC2R = dutycycle >> 16; /* Even OCx loaded with MSB */      
       		OC1RS = period;
       		OC2RS = period >> 16;
      		return 1;
    	}
    	else
    	 return -1;
    }	    
    else
       return -1;       
}

#else
#warning "Does not build on this target"
#endif
