 
#include <outcompare.h>

#if defined (ocmp_v1_2) || defined (LIB_BUILD)
/**********************************************************************
Function Prototype : unsigned int ReadDCOC3PWM(void)
 
Include            : outcompare.h
 
Description        : This function reads the duty cycle from the Output Compare 
                     Secondary register.
 
Arguments          : None
 
Return Value       : This function returns the content of OCxRS register
 
Remarks            : This function reads the duty cycle from the Output Compare Secondary
                     register (OCxRS)
**********************************************************************/

unsigned int ReadDCOC3PWM(void)
{
    
        return OC3RS; /* Output Compare Secondary Register */
  
}

#else
#warning "Does not build on this target"
#endif
