 
#include <outcompare.h>

#if defined (ocmp_v2_1) ||defined (ocmp_v2_2)|| defined (LIB_BUILD)
/**************************************************************************************
Function Prototype : char SetPulseOC78(unsigned long int pulse_start,unsigned long int pulse_stop)
 
Include            : outcompare.h
 
Description        : This function configures the Cascade Output Compare main and secondary
                     registers (OCxR and OCxRS ) when the module is not in PWM mode.
 
Arguments          : pulse_start - This is the value to be stored into Output Compare 
                     Main register (OCxR). 
                     pulse_stop - This is the value to be stored into Output Compare 
                     Secondary register (OCxRS). 
                     [For Single Compare Mode pulse_stop value is ignored.]
 
Return Value       :Returns '1' if value is loaded.Else �-1� is returned.
 
Remarks            : The Output Compare duty cycle registers (OCxR and OCxRS) will be
                     configured with new values only if the module is not in PWM mode.
                     Where Odd module contains LSB value and even contains MSB value.
**************************************************************************************/

char SetPulseOC78(unsigned long int pulse_start, unsigned long int pulse_stop)
{   
   
    if(((OC7CON1bits.OCM & 0x06) != 0x06) && ((OC8CON1bits.OCM & 0x06) != 0x06))/* check if OC is in NON PWM Mode */
    {
	  if( OC7CON2bits.OC32 == 1 && OC8CON2bits.OC32 == 1 ) /*check if OC is in cascade mode*/
	  {
	     if((((OC7CON1bits.OCM & 0x07) >> 2)==0x01) && (((OC8CON1bits.OCM & 0x07) >> 2)==0x01)) /* check if OC is in Dual Compare Mode */
	     {
		     /* assign pulse_start to Main Register */ 
	        OC7R = pulse_start;       /* Odd Output compare module loaded with LSB value */
	        OC8R = pulse_start >> 16; /* Even Output compare module loaded with MSB value */
	        
	        /* assign pulse_stop to Secondary Register */
	        OC7RS = pulse_stop;       
	        OC8RS = pulse_stop >> 16;
	     } 
	     else
	       OC7R = pulse_start;
	       OC8R = pulse_start >> 16;
       return 1;
      }
      else
       return -1;        
    }     
    else    
       return -1;         
}

#else
#warning "Does not build on this target"
#endif
