 
#include <outcompare.h>

#if defined (ocmp_v3_1)  || defined (ocmp_v3_2) || defined (ocmp_v4_0) || defined (LIB_BUILD)
/***********************************************************************************
Function Prototype : void ConfigIntOC1_v3(unsigned int config)

Include            : outcompare.h
 
Description        : This function configures the Output Compare interrupt.
 
Arguments          : config - Output Compare interrupt priority and enable/disable
                     information as defined below
					 
						Interrupt enable/disable
						   *	OC_INT_ON
						   *	OC_INT_OFF
						Interrupt Priority
						   *	OC_INT_PRIOR_0
						   *	OC_INT_PRIOR_1
						   *	OC_INT_PRIOR_2
						   *	OC_INT_PRIOR_3
						   *	OC_INT_PRIOR_4
						   *	OC_INT_PRIOR_5
						   *	OC_INT_PRIOR_6
						   *	OC_INT_PRIOR_7
 
Return Value        : None
 
Remarks             : This function clears the Interrupt Flag bit and then sets 
                      the interrupt priority and enables/disables the interrupt.
************************************************************************************/

void ConfigIntOC1_v3(unsigned int config)
{   
    IFS0bits.CCP1IF = 0 ;                /* Clear IF bit */
    IPC0bits.CCP1IP=(config &0x0007);    /* Assign Interrupt Priority */ 
    IEC0bits.CCP1IE=(config &0x0008)>>3; /* Enable/disable Interrupt */ 
}

#else
#warning "Does not build on this target"
#endif
