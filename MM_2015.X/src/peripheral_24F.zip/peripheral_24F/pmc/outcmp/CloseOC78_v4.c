 
#include <outcompare.h>

#if defined (ocmp_v2_1) ||defined (ocmp_v2_2)|| defined (LIB_BUILD)
/**************************************************************************
Function Prototype : void CloseOC78(void) 

Include            : outcompare.h
 
Description        : This function turns off the output compare cascade module. 
                     
Arguments          : None
 
Return Value       : None
 
Remarks            : This function disables the Output Compare interrupt and 
                     then turns off the module. The Interrupt Flag bit is 
                     also cleared for OC7 and OC8.
**************************************************************************/

void CloseOC78(void)
{   
    IEC2bits.OC7IE = 0;  /* Disable the Output Compare7 interrupt */    
    IEC2bits.OC8IE = 0; /* Disable the Output Compare8 interrupt*/
    	
    OC7CON1bits.OCM = 0;  /* Turn off Output Compare7 */
    OC8CON1bits.OCM = 0; /* Turn off Output Compare8*/      
    
    IFS2bits.OC7IF = 0;  /* Disable the Interrupt Flag of Output Compare7 */
    IFS2bits.OC8IF = 0; /* Disable the Interrupt Flag of Output Compare8 */
}

#else
#warning "Does not build on this target"
#endif
