 
#include <outcompare.h>

#if defined (ocmp_v1_2) || defined (LIB_BUILD)
/**************************************************************************
Function Prototype : void CloseOC5(void) 

Include            : outcompare.h
 
Description        : This function turns off the Output Compare module.
 
Arguments          : None
 
Return Value       : None
 
Remarks            : This function disables the Output Compare interrupt and 
                     then turns off the module. The Interrupt Flag bit is 
                     also cleared.
**************************************************************************/

void CloseOC5(void)
{   
    IEC2bits.OC5IE = 0;/* Disable the Interrupt bit in IEC Register */
    OC5CONbits.OCM = 0;/* Turn off Output Compare */
    IFS2bits.OC5IF = 0;/* Disable the Interrupt Flag bit in IFS Register */
}

#else
#warning "Does not build on this target"
#endif
