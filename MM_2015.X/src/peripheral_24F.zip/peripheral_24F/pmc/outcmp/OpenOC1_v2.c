 
#include <outcompare.h>

#if defined (ocmp_v2_1) || defined (ocmp_v2_2) || defined (ocmp_v2_3)|| defined (ocmp_v2_4)|| defined (ocmp_v2_5)|| defined (LIB_BUILD)
/************************************************************************************************
Function Prototype : void OpenOC1_GB(unsigned int config1,unsigned int config2, 
                                      unsigned int value1, unsigned int value2)

Include            : outcompare.h
 
Description        : For seamless migration, it is recommended to call the above function as "OpenOC1".
 
Arguments          : config1 - This contains the parameters to be configured in the OCxCON1 register 
			         config2 - This contains the parameters to be configured in the OCxCON2 register 
					 value1 - This contains the value to be stored into OCxRS Secondary					
			                  Register.[In single compare mode, user may set this parameter as 0x0000]								
			         value2 - This contains the value to be stored into OCxR Main Register
 
Return Value       : None
 
Remarks            : This function configures the Output Compare Module Control register
                     (OCxCON)with the parameters like Clock select, mode of operation, 
                      operation in Idle mode.It also configures the OCxRS and OCxR registers.
**********************************************************************************************/

void OpenOC1_GB(unsigned int config1,unsigned int config2, unsigned int value1, unsigned int value2)
{
    OC1CON1bits.OCM = 0; /* turn off OC before switching to new mode */
    OC1RS = value1;     /* assign value1 to OCxRS Secondary Register */
    OC1R = value2;      /* assign value2 to OCxR Main Register*/  
	OC1CON2 = config2;  /* assign config to OCxCON Register*/
    OC1CON1 = config1;    
    
}

#else
#warning "Does not build on this target"
#endif
