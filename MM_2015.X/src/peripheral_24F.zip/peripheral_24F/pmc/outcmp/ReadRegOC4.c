 
#include <outcompare.h>

#if defined (ocmp_v1_2) ||defined (ocmp_v2_1)|| defined (ocmp_v2_2) || defined (ocmp_v2_5)||\
    defined (ocmp_v2_3)|| defined (LIB_BUILD)
/*************************************************************************************
Function Prototype : unsigned int ReadRegOC4(char reg)
 
Include            : outcompare.h
 
Description        : This function reads the duty cycle registers when Output Compare
                     module is not in PWM mode.
 
Arguments          : reg - This indicates if the read should happen from the main or
                     secondary duty cycle registers of Output Compare module.
                     If reg is �1�, then the contents of Main Duty Cycle register
                     (OCxR) is read.
                     If reg is �0�, then the contents of Secondary Duty Cycle register
                     (OCxRS) is read.

Return Value       : This function returns the content of OCxRS register 
 
Remarks            : Return Main (OCxR) or seconday register value(OCxRS)
****************************************************************************************/

unsigned int ReadRegOC4(char reg)
{   
                                  
    if(reg)
    {       
        return OC4R; /* Output Compare main Register */
        
    }     
    return OC4RS;    /* Output Compare Secondary Register */
 
}

#else
#warning "Does not build on this target"
#endif
