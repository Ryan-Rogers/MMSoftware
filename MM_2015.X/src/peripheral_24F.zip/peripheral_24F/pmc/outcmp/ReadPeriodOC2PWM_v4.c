 
#include <outcompare.h>

#if defined (ocmp_v2_1) ||defined (ocmp_v2_2)||defined (ocmp_v2_3)|| defined (ocmp_v2_4)|| defined (ocmp_v2_5)|| defined (LIB_BUILD)
/**********************************************************************
Function Prototype : unsigned int ReadPeriodOC2PWM4(void)
 
Include            : outcompare.h
 
Description        : This function reads the duty cycle from the Output Compare 
                     register.
 
Arguments          : None
 
Return Value       : This function returns the content of OCxRS register 
 
Remarks            : This function reads the duty cycle from the Output Compare 
                     register (OCxRS) 
**********************************************************************/
unsigned int ReadPeriodOC2PWM(void)
{
   
        return OC2RS; /* Output Compare Main Register */
  
}

#else
#warning "Does not build on this target"
#endif
