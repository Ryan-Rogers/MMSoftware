 
#include <outcompare.h>

#if defined (ocmp_v2_1)||defined (ocmp_v2_2)|| defined (ocmp_v2_5)||defined (LIB_BUILD)
/**************************************************************************
Function Prototype : void CloseOC6(void) 

Include            : outcompare.h
 
Description        : This function turns off the Output Compare module.
 
Arguments          : None
 
Return Value       : None
 
Remarks            : This function disables the Output Compare interrupt and 
                     then turns off the module. The Interrupt Flag bit is 
                     also cleared.
**************************************************************************/

void CloseOC6(void)
{   
    IEC2bits.OC6IE = 0;/* Disable the Interrupt bit in IEC Register */
    OC6CON1bits.OCM = 0;/* Turn off Output Compare */
    IFS2bits.OC6IF = 0;/* Disable the Interrupt Flag bit in IFS Register */
}

#else
#warning "Does not build on this target"
#endif
