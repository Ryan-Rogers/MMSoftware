 
#include <outcompare.h>

#if defined (ocmp_v2_1) ||defined (ocmp_v2_2)|| defined (ocmp_v2_3)|| defined (ocmp_v2_4)|| defined (ocmp_v2_5)||defined (LIB_BUILD)
/**********************************************************************
Function Prototype : unsigned long int ReadPeriodOC12PWM(void)
 
Include            : outcompare.h
 
Description        : This function reads the duty cycle for cascaded output 
                     compare module.
 
Arguments          : None
 
Return Value       : This function returns the content of OCxRS register 
 
Remarks            : Odd OCxR contains LSB and Even OCxRS contains MSB value.
**********************************************************************/

unsigned long int ReadPeriodOC12PWM(void)
{
   
   unsigned long int value=0;
   
   value = OC2RS;
   value = value << 16;
   value = value | OC1RS;
   
   return value;      
   
}

#else
#warning "Does not build on this target"
#endif
