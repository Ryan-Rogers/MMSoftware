 
#include <outcompare.h>

#if defined (ocmp_v2_1) ||defined (ocmp_v2_2)|| defined (ocmp_v2_3)|| defined (ocmp_v2_5)||defined (LIB_BUILD)
/**************************************************************************
Function Prototype : void CloseOC34(void) 

Include            : outcompare.h
 
Description        : This function turns off the output compare cascade module.                     
 
Arguments          : None
 
Return Value       : None
 
Remarks            : This function disables the Output Compare interrupt and 
                     then turns off the module. The Interrupt Flag bit is 
                     also cleared for OC3 and OC4.
**************************************************************************/

void CloseOC34(void)
{   
    IEC1bits.OC3IE = 0;  /* Disable the Output Compare3 interrupt */    
    IEC1bits.OC4IE = 0; /* Disable the Output Compare4 interrupt*/
    	
    OC3CON1bits.OCM = 0;  /* Turn off Output Compare3 */
    OC4CON1bits.OCM = 0; /* Turn off Output Compare4*/      
    
    IFS1bits.OC3IF = 0;  /* Disable the Interrupt Flag of Output Compare3 */
    IFS1bits.OC4IF = 0; /* Disable the Interrupt Flag of Output Compare4 */
}

#else
#warning "Does not build on this target"
#endif
