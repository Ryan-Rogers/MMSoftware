#include <outcompare.h>

#if defined (ocmp_v4_0) || defined (LIB_BUILD)

/**************************************************************************
Function Prototype : void Config_shutdown_src(unsigned int config) 

Include            : outcompare.h
 
Description        : This function configures the shutdown source for ECCP.
 
Arguments          : None
 
Return Value       : None
 
Remarks            : This function determines which of the available sources 
					 shuts down the ECCP module along with the shutdown states
					 of the PxA/B/C/D pins.
**************************************************************************/

void Config_shutdown_src(unsigned int config)
{
	ECCP1AS = config & 0x7F;
}

#else
#warning "Does not build on this target"
#endif