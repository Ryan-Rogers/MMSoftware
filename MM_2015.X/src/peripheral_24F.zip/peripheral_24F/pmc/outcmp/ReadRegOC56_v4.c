 
#include <outcompare.h>

#if defined (ocmp_v2_1) ||defined (ocmp_v2_2)|| defined (ocmp_v2_5)|| defined (LIB_BUILD)
/*************************************************************************************
Function Prototype : unsigned long int ReadRegOC56(char reg)
 
Include            : outcompare.h
 
Description        : This function reads the duty cycle registers 
 
Arguments          : reg - This indicates if the read should happen from the main or
                     secondary duty cycle registers of Output Compare module.
                     If reg is �1�, then the contents of Main Duty Cycle register
                     (OCxR) is read.
                     If reg is �0�, then the contents of Secondary Duty Cycle register
                     (OCxRS) is read.

Return Value       : This function returns the content of OCxR or OCxRS register 
 
Remarks            : None
****************************************************************************************/

unsigned long int ReadRegOC56(char reg)
{  
	long value =0;	   
                                             
        if(reg)
        {   
	        value = OC6R;
	        value = value << 16;
	        value = value | OC5R;               
        }
        else
        {     
            value = OC6RS;
	        value = value << 16;
	        value = value | OC5RS;   
	    } 
            return value; 
   
}

#else
#warning "Does not build on this target"
#endif
