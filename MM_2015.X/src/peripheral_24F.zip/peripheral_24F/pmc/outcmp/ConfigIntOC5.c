 
#include <outcompare.h>

#if defined (ocmp_v1_2)  || defined (ocmp_v2_1) || defined (ocmp_v2_2)  || defined (ocmp_v2_3) || defined (ocmp_v2_5)||\
    defined (LIB_BUILD)
/***********************************************************************************
Function Prototype : void ConfigIntOC5(unsigned int config)

Include            : outcompare.h
 
Description        : This function configures the Output Compare interrupt.
 
Arguments          : config - Output Compare interrupt priority and enable/disable
				 information as defined below
					 
					Interrupt enable/disable						
					   *	OC_INT_ON						
					   *	OC_INT_OFF						
					Interrupt Priority						
					   *	OC_INT_PRIOR_0						
					   *	OC_INT_PRIOR_1						
					   *	OC_INT_PRIOR_2		
					   *	OC_INT_PRIOR_3						
					   *	OC_INT_PRIOR_4						
					   *	OC_INT_PRIOR_5						
					   *	OC_INT_PRIOR_6						
					   *	OC_INT_PRIOR_7

 
Return Value        : None
 
Remarks             : This function clears the Interrupt Flag bit and then sets 
                      the interrupt priority and enables/disables the interrupt.
************************************************************************************/
void ConfigIntOC5(unsigned int config)
{
    IFS2bits.OC5IF = 0;                  /* Clear IF bit */
    IPC10bits.OC5IP = (config &0x0007);   /* Assign Interrupt Priority */
    IEC2bits.OC5IE = (config &0x0008)>>3;/* Enable/disable Interrupt */
}

#else
#warning "Does not build on this target"
#endif
