 
#include <outcompare.h>

#if defined (ocmp_v3_1) ||defined (ocmp_v3_2) || defined(ocmp_v4_0)|| defined (LIB_BUILD)
/**************************************************************************
Function Prototype : void CloseOC2_v3(void) 

Include            : outcompare.h
 
Description        : This function turns off the Output Compare module.
 
Arguments          : None
 
Return Value       : None
 
Remarks            : This function disables the Output Compare interrupt and 
                     then turns off the module. The Interrupt Flag bit is 
                     also cleared.
**************************************************************************/

void CloseOC2_v3(void)
{   
    IEC0bits.CCP2IE = 0;  /* Disable the Interrupt bit in IEC Register */
    CCP2CON = 0x00;  /* Turn off Output Compare */
    IFS0bits.CCP2IF = 0;  /* Disable the Interrupt Flag bit in IFS Register */
}

#else
#warning "Does not build on this target"
#endif
