 
#include <outcompare.h>

#if defined (ocmp_v2_1) ||defined (ocmp_v2_2) ||defined (ocmp_v2_3)|| defined (ocmp_v2_5)|| defined (LIB_BUILD)
/*************************************************************************************
Function Prototype : char SetDCOC34PWM_GB(unsigned long int dutycycle,unsigned long int period)

Include            : outcompare.h

Description        : For seamless migration, it is recommended to call the above function as "SetDCOC34PWM".
                     This function configures the Output Compare Secondary Duty Cycle register (OCxRS) 
					 when the module is in PWM mode.

Arguments          : dutycycle - This is the duty cycle value to be stored into Output
                     Compare Main Duty Cycle register (OCxR).
                     period - This is the period stored into Secondary register (OCxRS)
 
Return Value       : Returns '1' on successful loading value else return '-1'.
 
Remarks            : The Output Compare Main and Secondary register will be
                     configured with new value only if the module is in PWM mode.
**************************************************************************************/

char SetDCOC34PWM_GB(unsigned long int dutycycle,unsigned long int period)
{       
    if(((OC3CON1bits.OCM & 0x06) == 0x06) && ((OC4CON1bits.OCM & 0x06) == 0x06 ))/* check if OC is in PWM Mode */
    {
    	if(OC3CON2bits.OC32 == 1 && OC4CON2bits.OC32 == 1 ) /*check if OC is in cascade mode*/     
    	{
       		OC3R = dutycycle;       /* Odd OCx loaded with LSB */
       		OC4R = dutycycle >> 16; /* Even OCx loaded with MSB */      
       		OC3RS = period;
       		OC4RS = period >> 16;
      		return 1;
    	}
    	else
    	 return -1;
    }	    
    else
       return -1;       
}

#else
#warning "Does not build on this target"
#endif
