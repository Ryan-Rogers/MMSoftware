 
#include <outcompare.h>

#if defined (ocmp_v2_1) ||defined (ocmp_v2_2)|| defined (ocmp_v2_5)||defined (LIB_BUILD)
/**********************************************************************
Function Prototype : unsigned int ReadPeriodOC7PWM(void)
 
Include            : outcompare.h
 
Description        : This function reads the duty cycle from the Output Compare 
                     Secondary register.
 
Arguments          : None
 
Return Value       : This function returns the content of OCxRS register 
 
Remarks            : This function reads the duty cycle from the Output Compare
                     register (OCxRS)
**********************************************************************/

unsigned int ReadPeriodOC7PWM(void)
{
          
        return OC7RS;       /* Output Compare Register */
   
}

#else
#warning "Does not build on this target"
#endif
