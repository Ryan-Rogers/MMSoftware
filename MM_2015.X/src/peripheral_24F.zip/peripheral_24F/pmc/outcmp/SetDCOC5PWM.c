 
#include <outcompare.h>

#if defined (ocmp_v1_2) || defined (LIB_BUILD)
/*************************************************************************************
Function Prototype : char SetDCOC5PWM(unsigned int dutycycle)

Include            : outcompare.h
 
Description        : This function configures the Output Compare Secondary Duty Cycle
                     register (OCxRS) when the module is in PWM mode.

Arguments          : dutycycle - This is the duty cycle value to be stored into Output
                     Compare Secondary Duty Cycle register (OCxRS).
 
Return Value       : Returns '1' on successful loading value else return '-1'.
 
Remarks            : The Output Compare Secondary Duty Cycle register (OCxRS) will be
                     configured with new value only if the module is in PWM mode.
**************************************************************************************/

char SetDCOC5PWM(unsigned int dutycycle)
{   
    /* check if OC is in PWM Mode */
    if((OC5CONbits.OCM & 0x06) == 0x06) 
    {
       OC5RS = dutycycle;   /* assign to OCRS */
       return 1;
    }
    else
       return -1;    
}

#else
#warning "Does not build on this target"
#endif
