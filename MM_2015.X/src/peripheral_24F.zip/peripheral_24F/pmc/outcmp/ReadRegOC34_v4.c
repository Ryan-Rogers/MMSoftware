 
#include <outcompare.h>

#if defined (ocmp_v2_1) || defined (ocmp_v2_2) || defined (ocmp_v2_3) || defined (ocmp_v2_5)|| defined (LIB_BUILD)
/*************************************************************************************
Function Prototype : unsigned long int ReadRegOC34(char reg)
 
Include            : outcompare.h
 
Description        : This function reads the duty cycle registers when Output Compare
                     module is not in PWM mode.
 
Arguments          : reg - This indicates if the read should happen from the main or
                     secondary duty cycle registers of Output Compare module.
                     If reg is �1�, then the contents of Main Duty Cycle register
                     (OCxR) is read.
                     If reg is �0�, then the contents of Secondary Duty Cycle register
                     (OCxRS) is read.

Return Value       : This function returns the content of OCxRS register when Output
                     Compare module is in PWM mode. Else �-1� is returned
 
Remarks            : The read of Duty Cycle register happens only when Output Compare
                     module is not in PWM mode. Else, a value of �-1� is returned.
****************************************************************************************/

unsigned long int ReadRegOC34(char reg)
{  
	long value =0;
	   
    /* check if OC is in NON_PWM Mode */
    if((((OC3CON1bits.OCM & 0x06) != 0x06) && (OC4CON1bits.OCM & 0x06) != 0x06)) 
    {                                                    
        if(reg)
        {   
	        value = OC4R;
	        value = value << 16;
	        value = value | OC3R;               
        }
        else
        {     
            value = OC4RS;
	        value = value << 16;
	        value = value | OC3RS;   
	    } 
            return value; 
    }  
    return -1;  
}

#else
#warning "Does not build on this target"
#endif
