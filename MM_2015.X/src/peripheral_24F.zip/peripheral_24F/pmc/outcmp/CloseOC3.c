 
#include <outcompare.h>


#if defined (ocmp_v1_2) || defined (LIB_BUILD)
/**************************************************************************
Function Prototype : void CloseOC3(void) 

Include            : outcompare.h
 
Description        : This function turns off the Output Compare module.
 
Arguments          : None
 
Return Value       : None
 
Remarks            : This function disables the Output Compare interrupt and 
                     then turns off the module. The Interrupt Flag bit is 
                     also cleared.
**************************************************************************/
void CloseOC3(void)
{   
    IEC1bits.OC3IE = 0;/* Disable the Interrupt bit in IEC Register */
    OC3CONbits.OCM = 0;/* Turn off Output Compare 3 */
    IFS1bits.OC3IF = 0;/* Disable the Interrupt Flag bit in IFS Register */
}

#else
#warning "Does not build on this target"
#endif
