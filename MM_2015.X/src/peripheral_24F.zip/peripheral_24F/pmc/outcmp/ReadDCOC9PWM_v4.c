 
#include <outcompare.h>

#if defined (ocmp_v2_1) ||defined (ocmp_v2_2)||defined (LIB_BUILD)
/**********************************************************************
Function Prototype : unsigned int ReadDCOC9PWM(void)
 
Include            : outcompare.h
 
Description        : This function reads the duty cycle from the Output Compare 
                     register.
 
Arguments          : None
 
Return Value       : This function returns the content of OCxR register 
 
Remarks            : This function reads the duty cycle from the Output Compare 
                     register 
**********************************************************************/

unsigned int ReadDCOC9PWM(void)
{
   
   return OC9R;       /* Output Compare Register */
   
}

#else
#warning "Does not build on this target"
#endif
