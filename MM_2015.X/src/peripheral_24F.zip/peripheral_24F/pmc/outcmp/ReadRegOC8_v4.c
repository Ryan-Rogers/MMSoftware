 
#include <outcompare.h>

#if defined (ocmp_v2_1)|| defined (ocmp_v2_2) || defined (LIB_BUILD)
/*************************************************************************************
Function Prototype : unsigned int ReadRegOC8(char reg)
 
Include            : outcompare.h
 
Description        : This function reads the duty cycle registers 
 
Arguments          : reg - This indicates if the read should happen from the main or
                     secondary duty cycle registers of Output Compare module.
                     If reg is �1�, then the contents of Main Duty Cycle register
                     (OCxR) is read.
                     If reg is �0�, then the contents of Secondary Duty Cycle register
                     (OCxRS) is read.

Return Value       : This function returns the content of OCxR or OCxRS register
 
Remarks            :  Reads Main (OCxR) or secondary (OCxRS) register value.
****************************************************************************************/

unsigned int ReadRegOC8(char reg)
{   
                                                     
        if(reg)
        {       
            return OC8R; /* Output Compare main Register */
            
        }     
        return OC8RS;    /* Output Compare Secondary Register */
  
}

#else
#warning "Does not build on this target"
#endif
