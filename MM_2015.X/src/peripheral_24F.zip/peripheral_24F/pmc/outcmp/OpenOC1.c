 
#include <outcompare.h>

#if defined (ocmp_v1_2) || defined (ocmp_v1_1)  || defined (LIB_BUILD)
/************************************************************************************************
Function Prototype : void OpenOC1(unsigned int config, unsigned int value1, unsigned int value2)

Include            : outcompare.h
 
Description        : This function configures the Output Compare module.
 
Arguments          : config - This contains the parameters to be configured in the
				OCxCON register as defined below					
				
					 Idle mode operation					
					   *	OC_IDLE_STOP					
					   *	OC_IDLE_CON					
					 Clock select					
					   *	OC_TIMER2_SRC					
					   *	OC_TIMER3_SRC					
					 Output Compare modes of operation					
					   *	OC_PWM_FAULT_PIN_ENABLE					
					   *	OC_PWM_FAULT_PIN_DISABLE					
					   *	OC_CONTINUE_PULSE					
					   *	OC_SINGLE_PULSE					
					   *	OC_TOGGLE_PULSE					
					   *	OC_HIGH_LOW					
					   *	OC_LOW_HIGH					
					   *	OC_OFF	
					   				
			 value1 - This contains the value to be stored into OCxRS Secondary					
			 Register.[In single compare mode, user may set this parameter as 0x0000]					
			 
			 value2 - This contains the value to be stored into OCxR Main					
			 Register
 
Return Value       : None
 
Remarks            : This function configures the Output Compare Module Control register
                     (OCxCON)with the parameters like Clock select, mode of operation, 
                      operation in Idle mode.It also configures the OCxRS and OCxR registers.
**********************************************************************************************/

void OpenOC1(unsigned int config, unsigned int value1, unsigned int value2)
{
    OC1CONbits.OCM = 0; /* turn off OC before switching to new mode */
    OC1RS = value1;     /* assign value1 to OCxRS Secondary Register */
    OC1R = value2;      /* assign value2 to OCxR Main Register*/  
    OC1CON = config;    /* assign config to OCxCON Register*/
}

#else
#warning "Does not build on this target"
#endif
