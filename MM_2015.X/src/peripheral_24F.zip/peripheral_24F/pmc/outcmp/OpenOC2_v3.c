 
#include <outcompare.h>

#if defined (ocmp_v3_1) || defined (ocmp_v3_2)  || defined (ocmp_v4_0) || defined (LIB_BUILD)
/************************************************************************************************
Function Prototype : void OpenOC2_v3(unsigned int config, unsigned int value1, unsigned int value2)

Include            : outcompare.h
 
Description        : This function configures the Output Compare module.
 
Arguments          : config: bit definitions to configure compare   
*	 		 	period: time period for the compare(match)	
 
Return Value       : None
 
Remarks            : This function configures the Output Compare Module Control register
                     (CCPxCON)with the parameters like Clock select, mode of operation, 
                      operation in Idle mode.It also configures the OCxRS and OCxR registers.
**********************************************************************************************/

void OpenOC2_v3(unsigned int config, unsigned int period)
{
    CCPR2L = period;       	// load CA2L 
   CCPR2H = (period >> 8);   // load CA2H

   CCP2CON = config & 0x0F;  // Configure compare
   if(config&0x80)
   {
    IFS0bits.CCP2IF = 0;   // Clear the interrupt flag
    IEC0bits.CCP2IE = 1;   // Enable the interrupt
   }
}

#else
#warning "Does not build on this target"
#endif
