 
#include <outcompare.h>

#if defined (ocmp_v2_1) ||defined (ocmp_v2_2)|| defined (ocmp_v2_5)|| defined (LIB_BUILD)
/************************************************************************************************
Function Prototype : void OpenOC56_GB(unsigned int config1,unsigned int config2, 
                                      unsigned long int value1, unsigned long int value2)

Include            : outcompare.h
 
Description        : For seamless migration, it is recommended to call the above function as "OpenOC56". 
 
Arguments          : config1 - This contains the parameters to be configured in the
				     OCxCON1 register 
					 
					 config2 - This contains the parameters to be configured in the
					 OCxCON2 register 
							   
					 value1 - This contains the value to be stored into OCxRS Secondary					
					 Register.[In single compare mode, user may set this parameter as 0x0000]
										
					 value2 - This contains the value to be stored into OCxR Main					
					 Register
 
Return Value       : None
 
Remarks            : This function configures the Output Compare Module Control register
                     (OCxCON)with the parameters like Clock select, mode of operation, 
                      operation in Idle mode.It also configures the OCxRS and OCxR registers.
**********************************************************************************************/

void OpenOC56_GB(unsigned int config1,unsigned int config2, unsigned long int value1, unsigned long int value2)
{
    OC5CON1bits.OCM = 0; /* turn off OC before switching to new mode */
    OC6CON1bits.OCM = 0;
    
    OC5RS = value1;     /* assign value1 to OCxRS Secondary Register */
    OC6RS = value1>>16;
    OC5R = value2;      /* assign value2 to OCxR Main Register*/  
    OC6R = value2>>16;       
        
    OC6CON2 = config1;    /* assign config to OCxCON Register*/
    OC5CON2 = config2;
    OC6CON2 = config2;
    
    OC5CON2bits.OC32 = 1; /*cascade mode is enabled*/
    OC6CON2bits.OC32 = 1;
    
    OC5CON2bits.OCTRIS = 1; // Output compare 1 not generate pulses.
	OC5CON1 = config1;
}

#else
#warning "Does not build on this target"
#endif
