 
#include <outcompare.h>

#if defined (ocmp_v2_1) ||defined (ocmp_v2_2)||defined (ocmp_v2_3)|| defined (ocmp_v2_5)|| defined (LIB_BUILD)
/**************************************************************************************
Function Prototype : char SetPulseOC5_v4(UINTpulse_start,UINTpulse_stop)
 
Include            : outcompare.h
 
Description        : This function configures the Output Compare main and secondary
                     registers (OCxR and OCxRS ) when the module is not in PWM mode.
 
Arguments          : pulse_start - This is the value to be stored into Output Compare 
                     Main register (OCxR).
                     pulse_stop - This is the value to be stored into Output Compare 
                     Secondary register (OCxRS). 
                     [For Single Compare Mode pulse_stop value is ignored.]
 
Return Value       : Returns '1' if value is loaded.Else �-1� is returned.
 
Remarks            : The Output Compare duty cycle registers (OCxR and OCxRS) will be
                     configured with new values only if the module is not in PWM mode.
**************************************************************************************/

char SetPulseOC5_v4(unsigned int pulse_start, unsigned int pulse_stop)
{   
   
    if( (OC5CON1bits.OCM & 0x06) != 0x06) /* check if OC is in NON PWM Mode */
    {
	     if(((OC5CON1bits.OCM & 0x07) >> 2)==0x01) /* check if OC is in Dual Compare Mode */
	     {
	        OC5R = pulse_start; /* assign pulse_start to Main Register */
	        OC5RS = pulse_stop; /* assign pulse_stop to Secondary Register */
	     }
	     else
	       OC5R = pulse_start;
	       
       return 1;
    }     
    else    
       return -1;   
       
}

#else
#warning "Does not build on this target"
#endif
