 
#include <outcompare.h>

#if defined (ocmp_v2_3) || defined (ocmp_v2_2) || defined (ocmp_v2_1) ||defined (ocmp_v2_4)|| defined (LIB_BUILD)
/************************************************************************************************
Function Prototype : void OpenOC12_GB(unsigned int config1,unsigned int config2, 
                                      unsigned long value1, unsigned long value2)

Include            : outcompare.h
 
Description        : This function configures the Output Compare module.
 
Arguments          : config1 - This contains the parameters to be configured in the
				 OCxCON1 register as defined below	
					 
					 Idle mode operation					
					   *	OC_IDLE_STOP					
					   *	OC_IDLE_CON					
					 Clock select
					   *	OC_SYSCLK_SRC
					   *	OC_TIMER1_SRC
					   *	OC_TIMER5_SRC
					   *	OC_TIMER4_SRC
					   *	OC_TIMER3_SRC					
					   *	OC_TIMER2_SRC	
					Fault 2 Input Enable/Disable (Applicable to 64GB family)
					*	CMP_FAULT2_IN_ENABLE  
					*	CMP_FAULT2_IN_DISABLE  
					Fault 1 Input Enable/Disable (Applicable to 64GB family)
					*	OC_FAULT1_IN_ENABLE       
					*	OC_FAULT1_IN_DISABLE     		
					 Fault 0 Input Enable/Disable
					   *	OC_FAULT0_IN_ENABLE     
					   *	OC_FAULT0_IN_DISABLE 
					 PWM Fault Condition
					   *	OC_PWM_FAULT_CLEAR
					 One Shot Enable/Disable
					   *	OC_TRIG_CLEAR_SYNC
					   *	OC_TRIG_CLEAR_SW  				
					 Output Compare modes of operation					
					   *	OC_PWM_CENTRE_ALIGN
					   *	OC_PWM_EDGE_ALIGN	
					   *	OC_CONTINUE_PULSE					
					   *	OC_SINGLE_PULSE					
					   *	OC_TOGGLE_PULSE					
					   *	OC_HIGH_LOW					
					   *	OC_LOW_HIGH					
					   *	OC_OFF
					  
			 config2 - This contains the parameters to be configured in the
			 OCxCON2 register as defined below
					 
					 Fault Mode Bit
					   *	OC_FAULT_MODE_CLEAR_SW
					   *	OC_FAULT_MODE_PWM_CYCLE 
					 Fault Out Bit
					   *	OC_PWM_FAULT_OUT_HIGH
					   *	OC_PWM_FAULT_OUT_LOW
					 Fault Output state select bit 
					   *	OC_FAULT_PIN_OUT
					   *	OC_FAULT_PIN_UNCHANGE
					 Ouput Compare Invert Bit
					   *	OC_OUT_INVERT
					   *	OC_OUT_NOT_INVERT
					 OC Pulse Width Least Significant bits for delay selection (Applicable to 64GB family)
					*	DELAY_OC_FALL_EDGE_34   
					*	DELAY_OC_FALL_EDGE_12            
					*	DELAY_OC_FALL_EDGE_14   
					*	DELAY_OC_FALL_EDGE_00   					   
					 Output Compare Cascade Module Operation
					   *	OC_CASCADE_ENABLE
					   *	OC_CASCADE_DISABLE
					 Output Compare Trigger Operation Select        
					   *	OC_TRIGGER_ENABLE
					   *	OC_SYNC_ENABLE
					 Output Compare Timer Trigger
					   *	OC_TRIGGER_TIMER
					   *	OC_UNTRIGGER_TIMER
					 Output Compare Off bit
					   *	OC_DIRN_OUTPUT
					   *	OC_DIRN_TRIS
					 Source Select for Synchronization and Trigger Operation 
					   *	OC_SYNC_TRIG_IN_DISABLE 	
					   *	OC_SYNC_TRIG_IN_OC1			
					   *	OC_SYNC_TRIG_IN_OC2			
					   *	OC_SYNC_TRIG_IN_OC3				
					   *	OC_SYNC_TRIG_IN_OC4				
					   *	OC_SYNC_TRIG_IN_OC5			
					   *	OC_SYNC_TRIG_IN_OC6	  	
					   *	OC_SYNC_TRIG_IN_OC7	   		
					   *	OC_SYNC_TRIG_IN_OC8	  		
					   *	OC_SYNC_TRIG_IN_OC9	  		
					   *	OC_SYNC_TRIG_IN_IC5			
					   *	OC_SYNC_TRIG_IN_TMR1			
					   *	OC_SYNC_TRIG_IN_TMR2			
					   *	OC_SYNC_TRIG_IN_TMR3			
					   *	OC_SYNC_TRIG_IN_TMR4			
					   *	OC_SYNC_TRIG_IN_TMR5			
					   *	OC_SYNC_TRIG_IN_IC7	  	
					   *	OC_SYNC_TRIG_IN_IC8	   
					   *	OC_SYNC_TRIG_IN_IC1			
					   *	OC_SYNC_TRIG_IN_IC2			
					   *	OC_SYNC_TRIG_IN_IC3				
					   *	OC_SYNC_TRIG_IN_IC4			
					   *	OC_SYNC_TRIG_IN_CMP1		
					   *	OC_SYNC_TRIG_IN_CMP2			
					   *	OC_SYNC_TRIG_IN_CMP3			
					   *	OC_SYNC_TRIG_IN_AD			
					   *	OC_SYNC_TRIG_IN_CTMU			
					   *	OC_SYNC_TRIG_IN_IC6	 			
					   *	OC_SYNC_TRIG_IN_IC9	  
					   *	OC_SYNC_TRIG_IN_MASK	
					   
			 value1 - This contains the value to be stored into OCxRS Secondary					
			 Register.[In single compare mode, user may set this parameter as 0x0000]
								
			 value2 - This contains the value to be stored into OCxR Main					
			 Register
 
Return Value       : None
 
Remarks            : This function configures the Output Compare Module Control register
                     (OCxCON)with the parameters like Clock select, mode of operation, 
                      operation in Idle mode.It also configures the OCxRS and OCxR registers.
**********************************************************************************************/

void OpenOC12_GB(unsigned int config1,unsigned int config2, unsigned long value1, unsigned long value2)
{
    OC1CON1bits.OCM = 0; /* turn off OC before switching to new mode */
    OC2CON1bits.OCM = 0;
    
    OC1RS = value1;     /* assign value1 to OCxRS Secondary Register */
    OC2RS = value1>>16;
    OC1R = value2;      /* assign value2 to OCxR Main Register*/  
    OC1R = value2>>16;      
       
    OC1CON2 = config2; /* assign config to OCxCON Register*/
    OC2CON2 = config2;
    
    OC1CON2bits.OC32 = 1; /*cascade mode is enabled*/
    OC2CON2bits.OC32 = 1;
    
    OC1CON2bits.OCTRIS = 1; // Output compare 1 not generate pulses.
	
	OC1CON1 = config1;    
    OC2CON2 = config1; 
}

#else
#warning "Does not build on this target"
#endif
