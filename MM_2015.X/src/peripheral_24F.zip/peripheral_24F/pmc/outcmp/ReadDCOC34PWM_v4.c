 
#include <outcompare.h>

#if defined (ocmp_v2_1) ||defined (ocmp_v2_2)||defined (ocmp_v2_3)|| defined (ocmp_v2_5)|| defined (LIB_BUILD)
/**********************************************************************
Function Prototype : unsigned long int ReadDCOC34PWM(void)
 
Include            : outcompare.h
 
Description        : This function reads the duty cycle for cascaded output 
                     compare module.
 
Arguments          : None
 
Return Value       : This function returns the content of OCxR register 
 
Remarks            : Odd OCxR contains LSB and Even OCxR contains MSB value.
**********************************************************************/

unsigned long int ReadDCOC34PWM(void)
{
   
   unsigned long int value=0;
   
   value = OC4R;
   value = value << 16;
   value = value | OC3R;
   
   return value;      
   
}

#else
#warning "Does not build on this target"
#endif
