 

#include <outcompare.h>

#if defined (ocmp_v1_2) || defined (LIB_BUILD)
/*****************************************************************************
Function Prototype : void OpenOC4_v1(unsigned int config, unsigned int value1, unsigned int value2);

Include            : outcompare.h
 
Description        : For seamless migration, it is recommended to call the above function as "OpenOC4".
 
Arguments          : config - This contains the parameters to be configured in the
				    OCxCON register as defined below				   				
					 value1 - This contains the value to be stored into OCxRS Secondary					
					 Register.[In single compare mode, user may set this parameter as 0x0000]		 
					 value2 - This contains the value to be stored into OCxR Main					
					 Register
 
Return Value       : None
 
Remarks            : This function configures the Output Compare Module Control register
                     (OCxCON)with the following parameters:
                      Clock select, mode of operation, operation in Idle mode.
                      It also configures the OCxRS and OCxR registers.
*****************************************************************************/


void OpenOC4_v1(unsigned int config, unsigned int value1, unsigned int value2)
{
    OC4CONbits.OCM = 0; /* turn off OC before switching to new mode */
    OC4RS = value1;     /* assign value1 to OCxRS Secondary Register */
    OC4R = value2;      /* assign value2 to OCxR Main Register*/  
    OC4CON = config;    /* assign config to OCxCON Register*/
}


#else
#warning "Does not build on this target"
#endif
