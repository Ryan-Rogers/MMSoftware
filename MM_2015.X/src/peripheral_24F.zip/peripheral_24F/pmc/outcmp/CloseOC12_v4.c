 
#include <outcompare.h>

#if defined (ocmp_v2_1) ||defined (ocmp_v2_2)|| defined (ocmp_v2_3)|| defined (ocmp_v2_4)|| defined (ocmp_v2_5)||defined (LIB_BUILD)
/**************************************************************************
Function Prototype : void CloseOC12(void) 

Include            : outcompare.h
 
Description        : This function turns off the output compare cascade module 
                    
Arguments          : None
 
Return Value       : None
 
Remarks            : This function disables the Output Compare interrupt and 
                     then turns off the module. The Interrupt Flag bit is 
                     also cleared for OC1 and OC2.
**************************************************************************/

void CloseOC12(void)
{   
    IEC0bits.OC1IE = 0;  /* Disable the Output Compare1 interrupt */    
    IEC0bits.OC2IE = 0; /* Disable the Output Compare2 interrupt*/
    	
    OC1CON1bits.OCM = 0;  /* Turn off Output Compare1 */
    OC2CON1bits.OCM = 0; /* Turn off Output Compare2*/      
    
    IFS0bits.OC1IF = 0;  /* Disable the Interrupt Flag of Output Compare1 */
    IFS0bits.OC2IF = 0; /* Disable the Interrupt Flag of Output Compare2 */
}

#else
#warning "Does not build on this target"
#endif
