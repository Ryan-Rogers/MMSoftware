 
#include "dpslp.h"

#if defined (dpslp_v1_1) || defined (dpslp_v1_2) || defined (LIB_BUILD)
/*************************************************************************
 Function Prototype : unsigned char GotoDeepSleep_v1_1(void)

 Include            : dpslp.h

 Description        : For seamless migration, it is recommended to call the above function as "GotoDeepSleep".
					  This function configures and puts the device to deep sleep.
 
 Arguments          : none
                      
 Return Value       : -1 : if device did not enter Deep Sleep due to error in Deep Sleep sequence or interrupts
 
 Remarks            : There has to be delay of 3 Tcy between immediate successive calling of this function
*************************************************************************/

unsigned char GotoDeepSleep_v1_1(void)
{

		asm("disi #2");                                     // Block all interrupts with priority <7 for next 2 instructions

		asm("bset  DSCON, #15");                            // Enable Deep Sleep 

		asm("nop");                                         // special sequence (to handle missed interrupts)

        asm("nop");

		asm("btss  IFS0, #0");                              // Skip entering deep sleep if any interrupt occurred

        asm("pwrsav #0");                                   // Put the device into SLEEP mode

		return(-1);											//Return error code if did not enter Deep Sleep
}
#else
#warning "Does not build on this target"
#endif

