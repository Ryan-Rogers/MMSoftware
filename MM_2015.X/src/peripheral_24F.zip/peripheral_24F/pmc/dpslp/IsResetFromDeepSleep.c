 
#include "dpslp.h"

#if defined (dpslp_v1_1) || defined (dpslp_v2_1) || defined (dpslp_v2_2) || defined (dpslp_v2_3)|| defined (LIB_BUILD)
/*************************************************************************
 Function Prototype : BOOL IsResetFromDeepSleep( void )

 Include            : dpslp.h

 Description        : Returns TRUE if the device resets due to deepsleep wakeup
            		  FLASE if not

 Arguments          : None
                      
 Return Value       : BOOL
 
 Remarks            : None.
*************************************************************************/

BOOL IsResetFromDeepSleep( void )
{

	if( (RCONbits.DPSLP) && (RCONbits.POR) )
	{	RCONbits.DPSLP = 0;				//Manual clearing of bit
		return(TRUE);					//Reset source is Deep Sleep wake up
	}	
	else
		return(FALSE);	
}
#else
#warning "Does not build on this target"
#endif

