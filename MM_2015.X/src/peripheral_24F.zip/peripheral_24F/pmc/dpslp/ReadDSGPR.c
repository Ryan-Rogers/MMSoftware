 
#include "dpslp.h"

#if defined (dpslp_v1_1) || defined (dpslp_v1_2) || defined (dpslp_v2_1) || defined (dpslp_v2_2)  || defined (LIB_BUILD)
/*************************************************************************
 Function Prototype : CONTEXT* ReadDSGPR( void)

 Include            : dpslp.h

 Description        : Reads context saved in DSGPRx registers and updates in CONTEXT structure.
 
 Arguments          : None
                      
 Return Value       : None.
 
 Remarks            : None.
*************************************************************************/

void ReadDSGPR( CONTEXT* ptr )
{

	ptr->Reg0 = DSGPR0;		//Context saved in DSGPR0 register before deep sleep.
	ptr->Reg1 = DSGPR1;		//Context saved in DSGPR1 register before deep sleep.
		
}
#else
#warning "Does not build on this target"
#endif


