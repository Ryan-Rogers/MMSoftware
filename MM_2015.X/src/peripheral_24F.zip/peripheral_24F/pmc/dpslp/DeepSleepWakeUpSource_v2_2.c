 
#include "dpslp.h"

#if defined (dpslp_v2_2) || defined (LIB_BUILD)
/*************************************************************************
 Function Prototype : void DeepSleepWakeUpSource_v2_2( SRC* ptr)

 Include            : dpslp.h

 Description        : For seamless migration, it is recommended to call the above function as "DeepSleepWakeUpSource".
					  This function updates the deep sleep wake up source to the union SRC
 
 Arguments          : Pointer to union that reflects the status of deep sleep wake up source 
                      
 Return Value       : None
 
 Remarks            : Upon calling this function, union SRC reflects the wake up source of deep sleep.
*************************************************************************/

void DeepSleepWakeUpSource_v2_2(SRC* ptr)
{
	ptr->WKSRC=0x00;				//Clear all source bit if set previously
		if(DSWSRCbits.DSPOR)
			ptr->WK_SRC.DS_POR=1;		//wake up source is Power on reset
		if(DSWSRCbits.DSMCLR)
			ptr->WK_SRC.DS_MCLR=1;		//wake up source is master reset pin set to low
		if(DSWSRCbits.DSWDT)
			ptr->WK_SRC.DS_WDT=1;		//wake up source is deep sleep watch dog timer expiry
		if(DSWSRCbits.DSFLT)
			ptr->WK_SRC.DS_FLT=1;		//wake up due to fault in deep sleep configuration corruption
		if(DSWSRCbits.DSINT0)
			ptr->WK_SRC.DS_INT0=1;		//wake up source is external interrupt
		if(DSCONbits.DSBOR)
			ptr->WK_SRC.DS_BOR=1;		//Brown out occured during sleep
	
}
#else
#warning "Does not build on this target"
#endif


