 
#include "epmp.h"

#if defined (epmp_v1_1) || defined (epmp_v1_2) || defined (epmp_v2_1) ||defined (LIB_BUILD)
/******************************************************************************
  Function:        void EPMPPortConfig(DWORD config)
 
  PreCondition:    None
 
  Side Effects:    None
  				
  Input:           config - This contains the parameters to be configured in the
                              PMCON3<7:0> & PMCON4<15:0> register as defined below							  
								*      EPMP_P22
								*      EPMP_P21
								*      EPMP_P20
								*      EPMP_P19
								*      EPMP_P18
								*      EPMP_P17
								*      EPMP_P16
								*      EPMP_P15_CS2
								*      EPMP_P14_CS1
								*      EPMP_P13
								*      EPMP_P12
								*      EPMP_P11
								*      EPMP_P10
								*      EPMP_P9
								*      EPMP_P8
								*      EPMP_P7
								*      EPMP_P6
								*      EPMP_P5
								*      EPMP_P4
								*      EPMP_P3
								*      EPMP_P2
								*      EPMP_P1
								*      EPMP_P0      
 
  Returns:          None
 
  Note:			DWORD corresponds to unsigned long.
 *****************************************************************************/

void EPMPPortConfig(DWORD config)
{
   PMCON3 |= ( (config & 0x00FF0000) >> 16);
   PMCON4 = (WORD) (config & 0x0000FFFF);
}

#else
#warning "Does not build on this target"
#endif

