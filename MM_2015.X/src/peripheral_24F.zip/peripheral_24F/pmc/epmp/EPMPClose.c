 
#include "epmp.h"

#if defined (epmp_v1_1) || defined (epmp_v1_2) ||defined (epmp_v2_1) || defined (LIB_BUILD)
/******************************************************************************
 * Function     : void EPMPClose(void)
 *
 * PreCondition : None
 *
 * Overview     : disables PMP module, disables interrupt
 *
 * Input        : None
 *
 * Returns      : None 
 *
 * Side Effects : PMCON1,PMCON2,PMCON3,PMCON4.PMCS1CF,PMCS2CF,PMCS1MD,PMCS2MD IEC2.PMPIE, IFS2.PMPIF are cleared.
 *****************************************************************************/
 void EPMPClose(void)
 {
	IEC2bits.PMPIE = 0;
	PMCON1bits.PMPEN = 0;
	IFS2bits.PMPIF = 0;
 }

#else
#warning "Does not build on this target"
#endif

