 
#include "epmp.h"

#if defined (epmp_v1_1) || defined (epmp_v1_2) || defined (LIB_BUILD)
/******************************************************************************
  Function:        void EPMPOpen_v1(CONFIG_PMP* config)
 
  PreCondition:    None
 
  Side Effects:    Configures the PMP module as per the input data
  
  Overview:        For seamless migration, it is recommended to call the above function as "EPMPOpen".
                   Provides method for setting PMP registers using bit masks provided in this header file.
 
  Input:           	config.control1 - This contains the parameters to be configured in the 
						PMCON1 register as defined below	
						
				PMPEN BIT 
					*       EPMP_ON
					*       EPMP_OFF
					*       EPMP_MASK

				STOP DURING IDLE BIT 
					*       EPMP_SIDL_ON
					*       EPMP_SIDL_OFF
					*       EPMP_SIDL_MASK

				ADDRESS MULTIPLEXING BITS 
					*       EPMP_ADDR_MUX_3_ADDR_PHS
					*       EPMP_ADDR_MUX_2_ADDR_PHS
					*       EPMP_ADDR_MUX_1_ADDR_PHS
					*       EPMP_ADDR_MUX_NONE
					*       EPMP_ADDR_MUX_MASK

				MODE1:MODE0 Parallel Port Mode Select 
					*       EPMP_MOD_MASTER
					*       EPMP_MOD_ENH_SLAVE
					*       EPMP_MOD_BUF_SLAVE
					*       EPMP_MOD_LEGACY_SLAVE
					*       EPMP_MOD_MASK

				CS FUNCTION SELECTION BITS
					*       EPMP_USE_ALTCS2_ALTCS1
					*       EPMP_USE_ALTCS2_CS1
					*       EPMP_USE_CS2_CS1
					*       EPMP_CS_FUNC_MASK

				AL BIT configuration
					*       EPMP_LATCH_HI
					*       EPMP_LATCH_LO
					*       EPMP_LATCH_MASK

				ALMODE  BIT 
					*       EPMP_SMART_LATCH_ON
					*       EPMP_SMART_LATCH_OFF
					*       EPMP_LATCH_MASK

				BUSKEEP  BIT 
					*       EPMP_BUSKEEP_ON
					*       EPMP_BUSKEEP_OFF
					*       EPMP_BUSKEEP_MASK

				IRQM FUNCTION SELECTION BITS 
					*       EPMP_IRQ_BUF
					*       EPMP_IRQ_RW
					*       EPMP_IRQ_NONE
					*       EPMP_IRQ_MASK  

   
		 config.control2 - This contains the parameters to be configured in the 
		                              PMCON2 register as defined below 
									  
				MSTSEL1:MSTSEL0 Parallel Port Master Select 
					*       EPMP_ALT_MASTER_IO_DIR
					*       EPMP_ALT_MASTER
					*       EPMP_CPU_MASTER
					*       EPMP_MASTER_MASK					
					
		 config.control3 - This contains the parameters to be configured in the 
		                              PMCON3 register as defined below	
									  
				BYTE ENABLE BIT configuration 
					*       EPMP_HIGH_BE_ON
					*       EPMP_HIGH_BE_OFF
					*       EPMP_HIGH_BE_MASK

					*       EPMP_LOW_BE_ON 
					*       EPMP_LOW_BE_OFF
					*       EPMP_LOW_BE_MASK

				RD and WR STROBE FUNCTION BIT 
					*       EPMP_WR_ON
					*       EPMP_WR_OFF

					*       EPMP_RD_ON
					*       EPMP_RD_OFF

					*       EPMP_RD_WR_ON
					*       EPMP_RD_WR_OFF
					*       EPMP_RD_WR_MASK

				AWAITM1:AWAITM0 Address Latch Strobe Wait States bits
					*       EPMP_AWAITM_3_12_TCY
					*       EPMP_AWAITM_2_12_TCY
					*       EPMP_AWAITM_1_12_TCY
					*       EPMP_AWAITM_0_12_TCY
					*       EPMP_AWAITM_MASK

				AWAITE Address Hold After Address Latch Strobe Wait States bits
					*       EPMP_AWAITE_1_14_TCY
					*       EPMP_AWAITE_0_14_TCY
					*       EPMP_AWAITE_MASK					
					
		 config.master_res_addr - This contains the parameters to be configured in the 
		                              PMCON2 register that sets the Parallel Master Port Reserved Address Space bits
							  
									  
 		 config.port - This contains the parameters to be configured in the 
		                              PMCON3 & PMCON4 registers to select the PMP pin functionality 
									  
				PTEN22:PTEN0 PMP Address Port Enable bits
					*      EPMP_P22
					*      EPMP_P21
					*      EPMP_P20
					*      EPMP_P19
					*      EPMP_P18
					*      EPMP_P17
					*      EPMP_P16
					*      EPMP_P15_CS2
					*      EPMP_P14_CS1
					*      EPMP_P13
					*      EPMP_P12
					*      EPMP_P11
					*      EPMP_P10
					*      EPMP_P9
					*      EPMP_P8
					*      EPMP_P7
					*      EPMP_P6
					*      EPMP_P5
					*      EPMP_P4
					*      EPMP_P3
					*      EPMP_P2
					*      EPMP_P1
					*      EPMP_P0
 
 
 
  		 config.cs1_config & config.cs2_config - This contains the parameters to be configured in the 
		                              PMCS1CF & PMCS2CF register
									  
				CSDIS Chip Select x Disable
					*      EPMP_CSDIS_ON
					*      EPMP_CSDIS_OFF
					*      EPMP_CSDIS_MASK

				CSP Chip Select x Polarity
					*      EPMP_CS_POL_HIGH
					*      EPMP_CS_POL_LOW
					*      EPMP_CS_POL_MASK

				CSPTEN PMCSx Port Enable
					*      EPMP_CS_PORT_ON
					*      EPMP_CS_PORT_OFF
					*      EPMP_CS_PORT_MASK

				BEP Chip Select x Nibble/Byte Enable Polarity
					*      EPMP_CS_BE_ON
					*      EPMP_CS_BE_OFF
					*      EPMP_CS_BE_MASK

				WRSP Chip Select x Write Strobe Polarity
					*      EPMP_CS_WR_STROBE_HIGH
					*      EPMP_CS_WR_STROBE_LOW
					*      EPMP_CS_WR_STROBE_MASK

				RDSP Chip Select x Read Strobe Polarity
					*      EPMP_CS_RD_STROBE_HIGH
					*      EPMP_CS_RD_STROBE_LOW
					*      EPMP_CS_RD_STROBE_MASK

				SM Chip Select x Strobe Mode
					*      EPMP_CS_STROBE_ON
					*      EPMP_CS_STROBE_OFF
					*      EPMP_CS_SRTOBE_MASK

				ACKP Chip Select x Acknowledge Polarity
					*      EPMP_CS_ACK_HIGH
					*      EPMP_CS_ACK_LOW
					*      EPMP_CS_ACK_POL_MASK

				PTSZ1:PTSZ0 Chip Select x Port Size
					*      EPMP_CS_PORT_16
					*      EPMP_CS_PORT_4
					*      EPMP_CS_PORT_8
					*      EPMP_CS_PORT_SIZE_MASK
 
 
 
   		 config.cs1_mode & config.cs2_mode - This contains the parameters to be configured in the 
		                              PMCS1MD & PMCS2MD register
									  
				ACKM1:ACKM0 Chip Select x Acknowledge Mode
					*       EPMP_CS_ACK_MOD_RW_COM
					*       EPMP_CS_ACK_MOD_RW_TIME
					*       EPMP_CS_ACK_MOD_OFF
					*       EPMP_CS_ACK_MASK

				AMWAIT2:AMWAIT0 Chip Select x Alternate Master Wait States
					*       EPMP_CS_AMWAIT_10
					*       EPMP_CS_AMWAIT_9
					*       EPMP_CS_AMWAIT_8
					*       EPMP_CS_AMWAIT_7
					*       EPMP_CS_AMWAIT_6
					*       EPMP_CS_AMWAIT_5
					*       EPMP_CS_AMWAIT_4
					*       EPMP_CS_AMWAIT_3
					*       EPMP_CS_AMWAITM_MASK

				DWAITB1:DWAITB0 Chip Select x Data Setup Before Read/Write Strobe Wait States
					*       EPMP_WAITB_3_TCY
					*       EPMP_WAITB_2_TCY
					*       EPMP_WAITB_1_TCY
					*       EPMP_WAITB_0_TCY
					*       EPMP_WAITB_TCY_MASK

				DWAITM3:DWAITM0 Chip Select x Data Read/Write Strobe Wait States
					*       EPMP_WAITM_15_TCY
					*       EPMP_WAITM_14_TCY
					*       EPMP_WAITM_13_TCY
					*       EPMP_WAITM_12_TCY
					*       EPMP_WAITM_11_TCY
					*       EPMP_WAITM_10_TCY
					*       EPMP_WAITM_9_TCY
					*       EPMP_WAITM_8_TCY
					*       EPMP_WAITM_7_TCY
					*       EPMP_WAITM_6_TCY
					*       EPMP_WAITM_5_TCY
					*       EPMP_WAITM_4_TCY
					*       EPMP_WAITM_3_TCY
					*       EPMP_WAITM_2_TCY
					*       EPMP_WAITM_1_TCY
					*       EPMP_WAITM_0_TCY
					*       EPMP_WAITM_TCY_MASK

				DWAITE1:DWAITE0 Chip Select x Data Hold After Read/Write Strobe Wait States
					*       EPMP_WAITE_3_TCY
					*       EPMP_WAITE_2_TCY
					*       EPMP_WAITE_1_TCY
					*       EPMP_WAITE_0_TCY
					*       EPMP_WAITE_TCY_MASK
 
 
    		 config.cs1_addr & config.cs2_addr - This contains the Chip Select Base Address to be configured in
		                              PMCS1BS & PMCS2BS registers
 
 
		     interrupt - PMP interrupt priority and enable/disable information 
				as defined below
							 
					  PMP Interrupt enable/disable
						*	EPMP_INT_ON
						*	EPMP_INT_OFF
				       PMP Interrupt priority
						*	EPMP_INT_PRI_0
						*	EPMP_INT_PRI_1
						*	EPMP_INT_PRI_2
						*	EPMP_INT_PRI_3
						*	EPMP_INT_PRI_4
						*	EPMP_INT_PRI_5
						*	EPMP_INT_PRI_6
						*	EPMP_INT_PRI_7
  
  Returns:          None           
 *****************************************************************************/
void EPMPOpen_v1(CONFIG_PMP* config)
{
    PMSTAT = 0;									//Clear the status of PMP
    IEC2bits.PMPIE = 0;							//Interrupt disabled
    IFS2bits.PMPIF = 0;							//Interrupt flag cleared
    IPC11bits.PMPIP = 0;						//Interrupt priority cleared
    
    PMCON1 = config->control1;
	PMCON2 = config->control2;
	PMCON3 = config->control3;
	
	PMCON3 |= ((config->port & 0x00FF0000) >> 16);
	PMCON4 = (UINT) (config->port & 0x0000FFFF);
	
	PMCON2bits.RADDR = config->master_res_addr;
	
	PMCS1CF = config->cs1_config;
	PMCS2CF = config->cs2_config;
	
	PMCS1MD = config->cs1_mode;
	PMCS2MD = config->cs2_mode;
	
	PMCS1BS = config->cs1_addr & 0xFF88;
	PMCS2BS = config->cs2_addr & 0xFF88;
    
    IPC11bits.PMPIP = config->interrupt;     // mask just the pmp priority bits  
	
	if( (config->interrupt & 0x80) == 1)
		IEC2bits.PMPIE = 1;         // mask just the pmp interrupt enable bit
		
    PMCON1bits.PMPEN = 1;        // last, enable the module
}
#else
#warning "Does not build on this target"
#endif


