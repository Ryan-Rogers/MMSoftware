 
#include "epmp.h"

#if defined (epmp_v1_1) || defined (epmp_v1_2) || defined (epmp_v2_1) ||defined (LIB_BUILD)
/******************************************************************************
 * Function:        BOOL EPMPIsInputBufferNFull (BUFFER buf)
 *
 * PreCondition:    None
 *
 * Side Effects:    None
 *
 * Overview:        Returns state of PMSTAT.IBxF (input buffer(s) full bit)
 * 					
 * Input:           buf - buffer(0..3)
 *
 * Returns:          TRUE/FALSE
 *
 * Note:            Use in SLAVE BUFFERED mode, MODE[1:0] = 00
 *					or SLAVE ENHANCED mode, MODE[1:0] = 00  and INCM[1:0]=11
 *****************************************************************************/
BOOL EPMPIsBufferNFull(BUFFER buf)
{
	BOOL status = FALSE;
	
	switch(buf)
	{
	case 0:
		status = PMSTATbits.IB0F;
		break;
	case 1:
		status = PMSTATbits.IB1F;
		break;
	case 2:
		status = PMSTATbits.IB2F;
		break;
	case 3:
		status = PMSTATbits.IB3F;
		break;	
	}	
	return(status);
}
#else
#warning "Does not build on this target"
#endif


