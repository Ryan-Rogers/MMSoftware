 
#include "epmp.h"

#if defined (epmp_v1_1) || defined (epmp_v1_2) ||defined (epmp_v2_1) ||defined (LIB_BUILD)
/******************************************************************************
 * Function:        BOOL EPMPSlaveWriteBufferN(BUFFER buf, BYTE value)
 *
 * PreCondition:    None
 *
 * Side Effects:    None
 *
 * Overview:        writes the desired value into the selected output buffer
 * 					
 * Input:           buf - buffer(0..3)
 *                  value - value to be written
 *
 * Returns:          Returns the state of PMSTAT.OBE prior to the write operation.
 *
 * Note:            Use in SLAVE BUFFERED mode, MODE[1:0] = 01
 *					or SLAVE ENHANCED mode, MODE[1:0] = 10  and INCM[1:0]=11           
 *****************************************************************************/
BOOL EPMPSlaveWriteBufferN(BUFFER buf, BYTE value)
{

	WORD_VAL reg;
	BOOL status;
	reg.Val = 0;
	
	if(PMSTATbits.OBE)	
		status = TRUE;

	switch(buf)
	{
	case 0:
		reg.Val = PMDOUT1;				// copy upper/lower bytes of PMDATAOUT1 into temp
		reg.v[0] = value;				// update lower byte only
		PMDOUT1 = reg.Val;				// write it back to PMDATAOUT1
		break;

	case 1:
		reg.Val = PMDOUT1;				// copy upper/lower bytes of PMDATAOUT1 into temp
		reg.v[1] = value;				// update upper byte only
		PMDOUT1 = reg.Val;				// write it back to PMDATAOUT1
		break;

	case 2:
		reg.Val = PMDOUT2;				// copy upper/lower bytes of PMDATAOUT2 into temp
		reg.v[0] = value;					// update lower byte only
		PMDOUT2 = reg.Val;				// write it back to PMDATAOUT2
		break;
		
	case 3:
		reg.Val = PMDOUT2;				// copy upper/lower bytes of PMDATAOUT2 into temp
		reg.v[1] = value;					// update upper byte only
		PMDOUT2 = reg.Val;				// write it back to PMDATAOUT2
		break;
	}
	return(status);
}

#else
#warning "Does not build on this target"
#endif


