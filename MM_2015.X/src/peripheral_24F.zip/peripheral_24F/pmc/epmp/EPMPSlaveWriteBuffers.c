 
#include "epmp.h"

#if defined (epmp_v1_1) || defined (epmp_v1_2) || defined (epmp_v2_1) ||defined (LIB_BUILD)
/******************************************************************************
 * Function:        BOOL EPMPSlaveWriteBuffers(BYTE* ref)
 *
 * PreCondition:    None
 *
 * Side Effects:    None
 *
 * Overview:        Copies 4 bytes, addressed by the pointer/ref argument, into
 *					the corresponding output registers. Byte[0] -> OUT1[7:0],
 *					byte[1] -> OUT1[15:8], ... etc. If entire buffer is empty,
 *					(IBF = 0) function returns TRUE, else the bytes are not
 *					copied and returns FALSE.
 *
 * Input:           ref - BYTE pointer
 *
 * Returns:          Returns the state of PMSTAT.OBE prior to the write operation.
 *
 * Note:            Use in SLAVE BUFFERED mode, MODE[1:0] = 01
 *					or SLAVE ENHANCED mode, MODE[1:0] = 10  and INCM[1:0]=11              
 *****************************************************************************/
BOOL EPMPSlaveWriteBuffers(BYTE* ref)
{
	WORD_VAL reg1, reg2;
	BOOL status;
	
	if(PMSTATbits.OBE)
		status = TRUE;

	reg1.v[0] = *ref++;
	reg1.v[1] = *ref++;
	reg2.v[0] = *ref++;
	reg2.v[1] = *ref;

	PMDOUT1 = reg1.Val;
	PMDOUT2 = reg2.Val;
	
	return(status);
}

#else
#warning "Does not build on this target"
#endif


