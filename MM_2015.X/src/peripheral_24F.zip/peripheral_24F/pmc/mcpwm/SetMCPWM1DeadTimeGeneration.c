#include "mcpwm.h"

#if defined (pwm_v1_1)|| defined (LIB_BUILD)

/***********************************************************************
* Function Name     : SetMCPWM1DeadTimeSourceGeneration 
* Description       : This function configures dead time values and clock                       
*					  prescalers.
* Parameters        : unsigned int config
* Return Value      : None 
************************************************************************/

void SetMCPWM1DeadTimeGeneration (unsigned int config)
{
    P1DTCON1 = config;
}

#else
#warning "Does not build on this target"
#endif
