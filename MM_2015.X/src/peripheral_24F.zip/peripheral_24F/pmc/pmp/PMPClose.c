 
#include "pmp.h"

#if defined (pmp_v1_2) || defined (pmp_v1_1)|| defined (pmp_v2_2) ||\
    defined (pmp_v2_1) || defined (LIB_BUILD)
/******************************************************************************
 * Function     : void PMPClose(void)
 *
 * PreCondition : None
 *
 * Overview     : disables PMP module, disables interrupt
 *
 * Input        : None
 *
 * Returns      : None 
 *
 * Side Effects : PMCON.PMPEN, IEC2.PMPIE, IFS2.PMPIF are cleared.
 *****************************************************************************/
 void PMPClose(void)
 {
	IEC2bits.PMPIE = 0;
	PMCONbits.PMPEN = 0;
	IFS2bits.PMPIF = 0;
 }

#else
#warning "Does not build on this target"
#endif

