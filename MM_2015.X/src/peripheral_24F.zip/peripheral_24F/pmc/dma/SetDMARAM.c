#include "dma.h"

#if defined (dma_v1_1) || defined (dma_v1_2) || defined (LIB_BUILD) 
/*************************************************************************************
Function    : void SetDMARAM(unsigned short int DMAL,unsigned short int DMAH)					
					                                
Overview    : This function sets DMA RAM Area

Parameters  : DMAL- Set the starting address(lower boundary) for DMA Ram Area		 
			  DMAH- Set the end address(higher boundary) for DMA Ram Area		 
						 
Returns     : None
			
Remarks     : This function is used to set DMA RAM Area for effective Memory
************************************************************************************************/

void SetDMARAM(unsigned short int DMAL,unsigned short int DMAH)
{
    
    /*Set start address of the memory for DMA RAM Area*/
	DMAL=DMAL;
	
	/*Set end address of the memory for DMA RAM Area*/
	DMAH=DMAH;
		
}

#else
#warning "Does not build on this target"
#endif
