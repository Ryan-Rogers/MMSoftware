#include "dma.h"

#if defined (dma_v1_1) || defined (dma_v1_2) || defined (LIB_BUILD) 
/***********************************************************************************************
Function:    void CloseDMA0_v1(void)

Overview:    This function turns off the DMA Channel 0 and disables the DMA Channel 0 interrupts. 

Parameters:  None 

Returns:     None
 
Remarks:     This function first disables the DMA Channel 0 interrupt and then turns off the DMA 
			Channel 0 module.The Interrupt Flag bit (DMA0IF) is also cleared.
***********************************************************************************************/
void CloseDMA0_v1(void)
{
    /* disable DMA Channel 0 interrupt */
    IEC0bits.DMA0IE = 0;

    /* turn off DMA Channel 0 */
    DMACH0bits.CHEN = 0;    

    /* clear DMA0IF bit */
    IFS0bits.DMA0IF = 0;
}

#else
#warning "Does not build on this target"
#endif
