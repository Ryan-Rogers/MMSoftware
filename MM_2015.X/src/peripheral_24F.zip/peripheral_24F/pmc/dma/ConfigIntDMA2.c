#include "dma.h"

#if defined (dma_v1_1) || defined (dma_v1_2) || defined (LIB_BUILD) 
/***************************************************************************************
Function           : void ConfigIntDMA2(unsigned int config)

Overview           : This function configures the DMA Channel 2 interrupt.

Parameters         : config - DMA Channel 2 interrupt priority and enable/disable information 
                     as defined below 
					 
                     DMA Channel 2 Interrupt enable/disable
					   * DMA_CHAN2_INT_ENABLE              
					   * DMA_CHAN2_INT_DISABLE  
						         
					 DMA Channel 2 Interrupt priority
                       * DMA_CHAN2_INT_PRI_0              
					   * DMA_CHAN2_INT_PRI_1               
					   * DMA_CHAN2_INT_PRI_2               
					   * DMA_CHAN2_INT_PRI_3               
					   * DMA_CHAN2_INT_PRI_4               
					   * DMA_CHAN2_INT_PRI_5               
					   * DMA_CHAN2_INT_PRI_6              
					   * DMA_CHAN2_INT_PRI_7    
                                            
Returns            : None 

Remarks            : This function clears the Interrupt Flag (DMA0IF) bit and then 
                     sets the interrupt priority and enables/disables the interrupt. 
****************************************************************************************/

void ConfigIntDMA2(unsigned int config)
{
    /* Clearing the Interrupt Flag bit */
    IFS1bits.DMA2IF = 0;

    /* Setting Priority */
    IPC6bits.DMA2IP = config & 0x07;

    /* Setting the Interrupt enable bit */
    IEC1bits.DMA2IE = (config & 0x08)>>3;
}

#else
#warning "Does not build on this target"
#endif
