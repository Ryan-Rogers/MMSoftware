#include "dma.h"

#if defined (dma_v1_1) || defined (dma_v1_2) || defined (LIB_BUILD) 
/*************************************************************************************
Function    : void LoadDMA1(unsigned short int Count,unsigned int DMA_Src,unsigned int DMA_Dst)					
					                                
Overview    : This function loads DMA Transfer count, DMA Source address and DMA Destination Address

Parameters  : Count- Used to load DMA Transfer Count
			  DMA_Src- Load DMA Source Address 
			  DMA_Dst- Load DMA Destination Address	 
						 
Returns     : None
			
Remarks     : This function is used to load the DMA Transfer Count and to set the DMA Source 
			  Address from where transfer of data should occur and DMA Destination address to 
			  where data should be transferred for Channel 1.
************************************************************************************************/

void LoadDMA1(unsigned short int Count,unsigned char* DMA_Src,unsigned char* DMA_Dst)
{
    
    /*Load DMA Transfer Count for Channel 1*/
	DMACNT1=Count;
	
	/*Load DMA Source Address for Channel 1*/	
	DMASRC1=(unsigned int)DMA_Src;		   
	
    /*Load DMA Destination Address for Channel 1*/		
    DMADST1=(unsigned int)DMA_Dst;
		 
}

#else
#warning "Does not build on this target"
#endif
