#include "dma.h"

#if defined (dma_v1_1) || defined (dma_v1_2) || defined (LIB_BUILD) 
/*************************************************************************************
Function    : void TriggerSrc0(unsigned int Trigger_Select)					
					                                
Overview    : This function selects the Trigger Source to start DMA Transfer

Parameters  : Trigger_Select- determines the Trigger source select for DMA Channel 0		 
					 
						 
Returns     : None
			
Remarks     : This function is used to select the DMA trigger source for DMA transfer 
				operation to begin with respect to channel 0
************************************************************************************************/

void TriggerSrc0(unsigned int Trigger_Select)
{
    
    /* config DMA Channel 0 for Trigger source   */
    DMAINT0 = Trigger_Select;
	
}

#else
#warning "Does not build on this target"
#endif
