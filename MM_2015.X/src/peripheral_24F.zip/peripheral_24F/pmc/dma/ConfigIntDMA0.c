#include "dma.h"

#if defined (dma_v1_1) || defined (dma_v1_2) || defined (LIB_BUILD) 
/***************************************************************************************
Function           : void ConfigIntDMA0(unsigned int config)

Overview           : This function configures the DMA Channel 0 interrupt.

Parameters         : config - DMA Channel 0 interrupt priority and enable/disable information 
                     as defined below 
					 
                     DMA Channel 0 Interrupt enable/disable
					   * DMA_CHAN0_INT_ENABLE              
					   * DMA_CHAN0_INT_DISABLE  
						         
					 DMA Channel 0 Interrupt priority
                       * DMA_CHAN0_INT_PRI_0              
					   * DMA_CHAN0_INT_PRI_1               
					   * DMA_CHAN0_INT_PRI_2               
					   * DMA_CHAN0_INT_PRI_3               
					   * DMA_CHAN0_INT_PRI_4               
					   * DMA_CHAN0_INT_PRI_5               
					   * DMA_CHAN0_INT_PRI_6              
					   * DMA_CHAN0_INT_PRI_7    
                                            
Returns            : None 

Remarks            : This function clears the Interrupt Flag (DMA0IF) bit and then 
                     sets the interrupt priority and enables/disables the interrupt. 
****************************************************************************************/

void ConfigIntDMA0(unsigned int config)
{
    /* Clearing the Interrupt Flag bit */
    IFS0bits.DMA0IF = 0;

    /* Setting Priority */
    IPC1bits.DMA0IP = config & 0x07;

    /* Setting the Interrupt enable bit */
    IEC0bits.DMA0IE = (config & 0x08)>>3;
}

#else
#warning "Does not build on this target"
#endif
