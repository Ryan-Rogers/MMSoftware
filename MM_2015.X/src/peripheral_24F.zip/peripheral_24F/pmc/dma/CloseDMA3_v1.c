#include "dma.h"

#if defined (dma_v1_1) || defined (dma_v1_2) || defined (LIB_BUILD) 

/***********************************************************************************************
Function:    void CloseDMA3_v1(void)

Overview:    This function turns off the DMA Channel 3 and disables the DMA Channel 3 interrupts. 

Parameters:  None 

Returns:     None
 
Remarks:     This function first disables the DMA Channel 3 interrupt and then turns off the DMA 
			Channel 3 module.The Interrupt Flag bit (DMA3IF) is also cleared.
***********************************************************************************************/

void CloseDMA3_v1(void)
{
    /* disable DMA Channel 3 interrupt */
    IEC2bits.DMA3IE = 0;

    /* turn off DMA Channel 3 */
    DMACH3bits.CHEN = 0;    

    /* clear DMA3IF bit */
    IFS2bits.DMA3IF = 0;
}

#else
#warning "Does not build on this target"
#endif
