#include "dma.h"

#if defined (dma_v1_1) || defined (dma_v1_2) || defined (LIB_BUILD) 
/*************************************************************************************
Function    :void OpenDMA2_v1(unsigned int config1, unsigned int config2, unsigned int config3,
             unsigned int config_bg,unsigned int configscan_low, unsigned int configscan_high)					
					                                
Overview    : This function configures the DMA Channel 2

Parameters  : config1 - This contains the parameters to be configured in the DMACON register 	                    
              config2 - This contains the parameters to be configured in the DMACH2 register
       		  config3 - This contains the parameters to be configured in the DMAINT2 					 
					 
						 
Returns     : None
			
Remarks     : This function configures the DMA for the following parameters:
			  Transaction from source to destination; Transfer modes such as One-shot,Continuous ,
			  Repeated One-Shot and Repeated Continuous; Adderssing modes like Fixed-to-Fixed , 
			  Fixed-to-block, Block-to-Fixed and Block-to Block and Inetrrupt trigger sources.
************************************************************************************************/

void OpenDMA2_v1(unsigned int config1, unsigned int config2, unsigned int config3)
{
    /*Initialise DMACON to 0*/
	DMACONbits.DMAEN=0;
	
	/* config DMA Channel 2 Interrupt */
    DMAINT2 = config3;

    /* config DMA Channel 2 */
    DMACH2 = config2;

    /* config DMACON */
    DMACON = config1;
	
	/* enable the DMA Channel 2 */
	DMACH2bits.CHEN = 1;
}

#else
#warning "Does not build on this target"
#endif
