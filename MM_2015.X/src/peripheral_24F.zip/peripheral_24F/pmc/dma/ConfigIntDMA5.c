#include "dma.h"

#if defined (dma_v1_1) || defined (dma_v1_2) || defined (LIB_BUILD) 
/***************************************************************************************
Function           : void ConfigIntDMA5(unsigned int config)

Overview           : This function configures the DMA Channel 5 interrupt.

Parameters         : config - DMA Channel 5 interrupt priority and enable/disable information 
                     as defined below 
					 
                     DMA Channel 5 Interrupt enable/disable
					   * DMA_CHAN5_INT_ENABLE              
					   * DMA_CHAN5_INT_DISABLE  
						         
					 DMA Channel 5 Interrupt priority
                       * DMA_CHAN5_INT_PRI_0              
					   * DMA_CHAN5_INT_PRI_1               
					   * DMA_CHAN5_INT_PRI_2               
					   * DMA_CHAN5_INT_PRI_3               
					   * DMA_CHAN5_INT_PRI_4               
					   * DMA_CHAN5_INT_PRI_5               
					   * DMA_CHAN5_INT_PRI_6              
					   * DMA_CHAN5_INT_PRI_7    
                                            
Returns            : None 

Remarks            : This function clears the Interrupt Flag (DMA5IF) bit and then 
                     sets the interrupt priority and enables/disables the interrupt. 
****************************************************************************************/

void ConfigIntDMA5(unsigned int config)
{
    /* Clearing the Interrupt Flag bit */
    IFS3bits.DMA5IF = 0;

    /* Setting Priority */
    IPC15bits.DMA5IP = config & 0x07;

    /* Setting the Interrupt enable bit */
    IEC3bits.DMA5IE = (config & 0x08)>>3;
}

#else
#warning "Does not build on this target"
#endif
