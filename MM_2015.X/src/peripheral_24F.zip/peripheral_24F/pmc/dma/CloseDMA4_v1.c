#include "dma.h"

#if defined (dma_v1_1) || defined (dma_v1_2) || defined (LIB_BUILD) 

/***********************************************************************************************
Function:    void CloseDMA4_v1(void)

Overview:    This function turns off the DMA Channel 4 and disables the DMA Channel 4 interrupts. 

Parameters:  None 

Returns:     None
 
Remarks:     This function first disables the DMA Channel 4 interrupt and then turns off the DMA 
			Channel 4 module.The Interrupt Flag bit (DMA4IF) is also cleared.
***********************************************************************************************/

void CloseDMA4_v1(void)
{
    /* disable DMA Channel 4 interrupt */
    IEC2bits.DMA4IE = 0;

    /* turn off DMA Channel 4 */
    DMACH4bits.CHEN = 0;    

    /* clear DMA4IF bit */
    IFS2bits.DMA4IF = 0;
}

#else
#warning "Does not build on this target"
#endif
