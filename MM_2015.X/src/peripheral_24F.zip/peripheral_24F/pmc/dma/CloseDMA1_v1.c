#include "dma.h"

#if defined (dma_v1_1) || defined (dma_v1_2) || defined (LIB_BUILD) 
 
/***********************************************************************************************
Function:    void CloseDMA1_v1(void)

Overview:    This function turns off the DMA Channel 1 and disables the DMA Channel 1 interrupts. 

Parameters:  None 

Returns:     None
 
Remarks:     This function first disables the DMA Channel 1 interrupt and then turns off the DMA 
			Channel 1 module.The Interrupt Flag bit (DMA1IF) is also cleared.
***********************************************************************************************/

void CloseDMA1_v1(void)
{
    /* disable DMA Channel 1 interrupt */
    IEC0bits.DMA1IE = 0;

    /* turn off DMA Channel 1 */
    DMACH1bits.CHEN = 0;    

    /* clear DMA1IF bit */
    IFS0bits.DMA1IF = 0;
}

#else
#warning "Does not build on this target"
#endif
