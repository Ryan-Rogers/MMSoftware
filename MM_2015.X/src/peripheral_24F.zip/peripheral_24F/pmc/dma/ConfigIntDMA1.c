#include "dma.h"

#if defined (dma_v1_1) || defined (dma_v1_2) || defined (LIB_BUILD) 
/***************************************************************************************
Function           : void ConfigIntDMA1(unsigned int config)

Overview           : This function configures the DMA Channel 1 interrupt.

Parameters         : config - DMA Channel 1 interrupt priority and enable/disable information 
                     as defined below 
					 
                     DMA Channel 1 Interrupt enable/disable
					   * DMA_CHAN1_INT_ENABLE              
					   * DMA_CHAN1_INT_DISABLE  
						         
					 DMA Channel 1 Interrupt priority
                       * DMA_CHAN1_INT_PRI_0              
					   * DMA_CHAN1_INT_PRI_1               
					   * DMA_CHAN1_INT_PRI_2               
					   * DMA_CHAN1_INT_PRI_3               
					   * DMA_CHAN1_INT_PRI_4               
					   * DMA_CHAN1_INT_PRI_5               
					   * DMA_CHAN1_INT_PRI_6              
					   * DMA_CHAN1_INT_PRI_7    
                                            
Returns            : None 

Remarks            : This function clears the Interrupt Flag (DMA1IF) bit and then 
                     sets the interrupt priority and enables/disables the interrupt. 
****************************************************************************************/

void ConfigIntDMA1(unsigned int config)
{
    /* Clearing the Interrupt Flag bit */
    IFS0bits.DMA1IF = 0;

    /* Setting Priority */
    IPC3bits.DMA1IP = config & 0x07;

    /* Setting the Interrupt enable bit */
    IEC0bits.DMA1IE = (config & 0x08)>>3;
}

#else
#warning "Does not build on this target"
#endif
