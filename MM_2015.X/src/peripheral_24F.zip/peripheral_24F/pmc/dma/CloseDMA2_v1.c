#include "dma.h"

#if defined (dma_v1_1) || defined (dma_v1_2) || defined (LIB_BUILD) 

/***********************************************************************************************
Function:    void CloseDMA2_v1(void)

Overview:    This function turns off the DMA Channel 2 and disables the DMA Channel 2 interrupts. 

Parameters:  None 

Returns:     None
 
Remarks:     This function first disables the DMA Channel 2 interrupt and then turns off the DMA 
			Channel 2 module.The Interrupt Flag bit (DMA2IF) is also cleared.
***********************************************************************************************/

void CloseDMA2_v1(void)
{
    /* disable DMA Channel 2 interrupt */
    IEC1bits.DMA2IE = 0;

    /* turn off DMA Channel 2 */
    DMACH2bits.CHEN = 0;    

    /* clear DMA2IF bit */
    IFS1bits.DMA2IF = 0;
}

#else
#warning "Does not build on this target"
#endif
