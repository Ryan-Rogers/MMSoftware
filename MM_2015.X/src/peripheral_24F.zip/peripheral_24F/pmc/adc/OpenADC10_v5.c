#include "adc.h"

#if defined (adc_v5_1)||defined (adc_v5_2)||defined (LIB_BUILD) 
/*****************************************************************************************************************************************************************************
Function Prototype:	void OpenADC10_v5(unsigned int config1, unsigned int config2, unsigned int config3, unsigned int config4,unsigned int config5,unsigned int configctmu_low,unsigned int
					configctmu_high, unsigned int configscan_low, unsigned int configscan_high)
     
Overview          :  For seamless migration, it is recommended to call the above function as "OpenADC10".
 
Parameters  	  : config1 -          This contains the parameters to be configured in the ADCON1 register register
					config2 -          This contains the parameters to be configured in the ADCON2 register
					config3 -          This contains the parameters to be configured in the ADCON3
					config4 -          This contains the parameters to be configured in the ADCON4
					config5 -          This contains the parameters to be configured in the ADCON5
					configctmu_low  -  This contains the scan select parameter to be configured into the AD1CTMUENL
					configctmu_high -  This contains the scan select parameter to be configured into the AD1CTMUENH
					configscan_low  -  This contains the scan select parameter to be configured into the AD1CSSL
					configscan_high -  This contains the scan select parameter to be configured into the AD1CSSH 
	 
Returns           : None
     
     
Remarks			  : This function configures the ADC for the following parameters: Operating mode, Sleep mode behavior, Data o/p format, Sample Clk Source, VREF source, No of samples/int,
					Buffer Fill mode, Alternate i/p sample mode, Auto sample time, Charge Pump enable/disable,Conv clock source, Conv Clock Select bits, Config Control bits.              
//*****************************************************************************************************************************************************************************/

void OpenADC10_v5(unsigned int config1, unsigned int config2, unsigned int config3,unsigned int config4,
                  unsigned int config5,unsigned int configctmu_low,unsigned int configctmu_high,
				  unsigned int configscan_low,unsigned int configscan_high)
{
    /*configure ctmu selction bits*/
	AD1CTMENL = configctmu_low;
	AD1CTMENH = (configctmu_high & 0x7C03);
	
    /* configures the input scan selection bits */
    AD1CSSL = configscan_low;
    AD1CSSH = (configscan_high & 0x7C03);
	
	/* config AD1CON5 */
    AD1CON5 = config5;
	
	/* config AD1CON4 */
    AD1CON4 = config4;
	
    /* config AD1CON3 */
    AD1CON3 = config3;

    /* config AD1CON2 */
    AD1CON2 = config2;

    /* config AD1CON1 */
    AD1CON1 = config1;

    /* assign SAMP bit */
    AD1CON1bits.SAMP = config1 >> 1;
}

#else
#warning "Does not build on this target"
#endif
