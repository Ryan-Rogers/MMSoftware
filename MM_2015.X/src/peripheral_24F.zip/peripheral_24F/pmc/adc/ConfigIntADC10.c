#include "adc.h"

#if defined (adc_v1_1)|| defined (adc_v1_2) || defined (adc_v1_3)|| defined (adc_v1_4) ||defined (adc_v1_5)||\
    defined (adc_v1_6) || defined (adc_v1_7) || defined (adc_v1_8)|| defined (adc_v2_1) ||defined (adc_v3_1) ||\
	defined (adc_v3_2)||defined (adc_v4_1)||defined (adc_v4_2) || defined (adc_v4_3) ||defined (adc_v5_1)||\
	defined (adc_v5_2) || defined (adc_v6_1)|| defined (adc_v6_2)||defined (adc_v7_1) || defined (adc_v7_2) ||\
	defined (LIB_BUILD) 
/***************************************************************************************
Function           : void ConfigIntADC10(unsigned int config)

Overview           : This function configures the ADC interrupt.

Parameters         : config - ADC interrupt priority and enable/disable information 
                     as defined below 
					 
                     ADC Interrupt enable/disable
					   *	ADC_INT_ENABLE 
					   *	ADC_INT_DISABLE
					 ADC Interrupt priority
                       *	ADC_INT_PRI_0 
                       *	ADC_INT_PRI_1
                       *	ADC_INT_PRI_2
                       *	ADC_INT_PRI_3
                       *	ADC_INT_PRI_4
                       *	ADC_INT_PRI_5
                       *	ADC_INT_PRI_6
                       *	ADC_INT_PRI_7
                                            
Returns            : None 

Remarks            : This function clears the Interrupt Flag (ADIF) bit and then 
                     sets the interrupt priority and enables/disables the interrupt. 
****************************************************************************************/

void ConfigIntADC10(unsigned int config)
{
    /* Clearing the Interrupt Flag bit */
    IFS0bits.AD1IF = 0;

    /* Setting Priority */
    IPC3bits.AD1IP = config & 0x07;

    /* Setting the Interrupt enable bit */
    IEC0bits.AD1IE = (config & 0x08)>>3;
}

#else
#warning "Does not build on this target"
#endif
