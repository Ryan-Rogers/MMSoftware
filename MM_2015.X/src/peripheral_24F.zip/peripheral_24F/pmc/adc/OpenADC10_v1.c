 
#include "adc.h"

#if  defined (adc_v1_1) || defined (adc_v1_4)|| defined (adc_v1_3)||defined (adc_v1_2)|| defined (adc_v1_6) ||\
     defined (adc_v1_5) || defined (adc_v1_7)|| defined (adc_v1_8) ||defined (LIB_BUILD)
/*************************************************************************************
Function           : void OpenADC10_v1(unsigned int config1, unsigned int config2,
                                   unsigned int config3, unsigned int configport,
                                   unsigned int configscan)
                                  
Overview           : For seamless migration, it is recommended to call the above function as "OpenADC10".                   

Parameters         : config1 - This contains the parameters to be configured in the ADCON1 register
                     config2 - This contains the parameters to be configured in the ADCON2 register
		             config3 - This contains the parameters to be configured in the ADCON3 register
					 configport - This contains the pin select to be configured into the ADPCFG register          
					 configscan - This contains the scan select parameter to be configured into the ADCSSL register		 
					 
Returns           : None
			
Remarks           : This function configures the ADC for the following parameters:
			Operating mode, Sleep mode behavior, Data o/p format, Sample Clk
			Source, VREF source, No of samples/int, Buffer Fill mode, Alternate i/p
			sample mode, Auto sample time, Charge Pump enable/disable,Conv clock source, 
			Conv Clock Select bits, Port Config Control bits. 
************************************************************************************************/

void OpenADC10_v1(unsigned int config1, unsigned int config2, unsigned int config3,
                unsigned int configport, unsigned int configscan)
{

    /* digital/analog mode selection on the port bits */
    AD1PCFG = configport;

    /* configures the input scan selection bits */
    AD1CSSL = configscan;

    /* config AD1CON3 */
    AD1CON3 = config3;

    /* config AD1CON2 */
    AD1CON2 = config2;

    /* config AD1CON1 */ 
    AD1CON1 = config1;

    /* assign SAMP bit */
    AD1CON1bits.SAMP = config1 >> 1;
}

#else
#warning "Does not build on this target"
#endif
