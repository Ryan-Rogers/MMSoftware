 
#include "adc.h"

#if defined (adc_v1_4)|| defined (adc_v1_1) || defined (adc_v1_2)|| defined (adc_v1_5) ||defined (adc_v1_6)||\
    defined (adc_v1_3) || defined (adc_v1_7) || defined (LIB_BUILD)
/*************************************************************************************
Function           : void OpenADC10(unsigned int config1, unsigned int config2,
                                   unsigned int config3, unsigned int configport,
                                   unsigned int configscan)
                                  
Overview           : This function starts the A/D conversion. 

Parameters         : config1 - This contains the parameters to be configured in the 
                     ADCON1 register as defined below 
					 
                     Module On/Off
	                    *	ADC_MODULE_ON
	                    *	ADC_MODULE_OFF
	                 Idle mode operation
	                    *	ADC_IDLE_CONTINUE
	                    *	ADC_IDLE_STOP
                     Result output format
	                    *	ADC_FORMAT_SIGN_FRACT
	                    *	ADC_FORMAT_FRACT
	                    *	ADC_FORMAT_SIGN_INT
	                    *	ADC_FORMAT_INTG
                     Conversion trigger source (for GB family refer adc.h )
	                    *	ADC_CLK_AUTO
	                    *	ADC_CLK_TMR3
	                    *	ADC_CLK_INT0
	                    *	ADC_CLK_MANUAL					
                     Auto sampling select
	                    *	ADC_AUTO_SAMPLING_ON
	                    *	ADC_AUTO_SAMPLING_OFF
                     Sample enable
	                    *	ADC_SAMP_ON
	                    *	ADC_SAMP_OFF
	                    
                     config2 - This contains the parameters to be configured in the
                     ADCON2 register as defined below
					 
                     Voltage Reference
	                    *	ADC_VREF_AVDD_AVSS
	                    *	ADC_VREF_EXT_AVSS
	                    *	ADC_VREF_AVDD_EXT
	                    *	ADC_VREF_EXT_EXT
                     Scan selection
	                    *	ADC_SCAN_ON
	                    *	ADC_SCAN_OFF
                     Number of samples between interrupts
	                   *	ADC_INTR_EACH_CONV
	                   *	ADC_INTR_2_CONV          
			*	ADC_INTR_3_CONV           
			*	.....      
			*	ADC_INTR_15_CONV          
			*	ADC_INTR_16_CONV   
		 Buffer mode select
			*	ADC_ALT_BUF_ON
			*	ADC_ALT_BUF_OFF
		 Alternate Input Sample mode select
			*	ADC_ALT_INPUT_ON
			*	ADC_ALT_INPUT_OFF										 
					
		 config3 - This contains the parameters to be configured in the
		 ADCON3 register as defined below
		 
		  Conversion Clock Source select
			*	ADC_CONV_CLK_INTERNAL_RC
			*	ADC_CONV_CLK_SYSTEM
		 Auto Sample Time bits
			*	ADC_SAMPLE_TIME_0
			*	ADC_SAMPLE_TIME_1
			*	.....
			*	ADC_SAMPLE_TIME_30
			*	ADC_SAMPLE_TIME_31		
		 Conversion clock select
			*	ADC_CONV_CLK_1Tcy
			*	ADC_CONV_CLK_2Tcy
			*	....
			*	ADC_CONV_CLK_256Tcy		
					
		 configport - This contains the pin select to be configured into
		 the ADPCFG register as defined below
		 
			*	ENABLE_AN0_DIG                 
			*	ENABLE_AN1_DIG                  
			*	.....        
			*	ENABLE_AN14_DIG                 
			*	ENABLE_AN15_DIG                 
			*	ENABLE_ALL_ANA_0_15             
			*	ENABLE_ALL_DIG_0_15            
							
		 configscan - This contains the scan select parameter to be configured
		 into the  ADCSSL register as defined below
		 
			*	ADC_SKIP_SCAN_AN0      
			*	ADC_SKIP_SCAN_AN1      
			*	.....
			*	ADC_SKIP_SCAN_AN14     
			*	ADC_SKIP_SCAN_AN15 
			*	ENABLE_ALL_INPUT_SCAN       
			*	DISABLE_ALL_INPUT_SCAN   
					 
Returns           : None
			
Remarks           : This function configures the ADC for the following parameters:
			Operating mode, Sleep mode behavior, Data o/p format, Sample Clk
			Source, VREF source, No of samples/int, Buffer Fill mode, Alternate i/p
			sample mode, Auto sample time, Charge Pump enable/disable,Conv clock source, 
			Conv Clock Select bits, Port Config Control bits.
************************************************************************************************/

void OpenADC10(unsigned int config1, unsigned int config2, unsigned int config3,
                unsigned int configport, unsigned int configscan)
{

    /* digital/analog mode selection on the port bits */
    AD1PCFG = configport;

    /* configures the input scan selection bits */
    AD1CSSL = configscan;

    /* config AD1CON3 */
    AD1CON3 = config3;

    /* config AD1CON2 */
    AD1CON2 = config2;

    /* config AD1CON1 */ 
    AD1CON1 = config1;

    /* assign SAMP bit */
    AD1CON1bits.SAMP = config1 >> 1;
}

#else
#warning "Does not build on this target"
#endif
