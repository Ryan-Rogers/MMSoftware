#include "adc.h"

#if defined (adc_v1_1)|| defined (adc_v1_2) || defined (adc_v1_3)|| defined (adc_v1_4) ||defined (adc_v1_5)||\
    defined (adc_v1_6) || defined (adc_v1_7) || defined (adc_v1_8)|| defined (adc_v2_1) ||defined (adc_v3_1) ||\
	defined (adc_v3_2) ||defined (adc_v4_1)||defined (adc_v4_2) || defined (adc_v4_3)||defined (adc_v5_1)||\
	defined (adc_v5_2) || defined (adc_v7_1) || defined (adc_v7_2) ||defined (LIB_BUILD) 
/*********************************************************************
Function           : void SetChanADC10(unsigned int channel0) 

Overview           : This function sets the positive and negative inputs for 
                     the sample multiplexers A and B. 

Parameters         : channel0 - This contains the input select parameter to be 
                          configured into the ADCHS register
						  
Returns            : None 

Remarks            : This function configures the inputs for sample multiplexers 
                     A and B by writing to ADCHS register.
*********************************************************************/


void SetChanADC10(unsigned int channel0)
{
   
    AD1CHS = channel0;
	
}

#else
#warning "Does not build on this target"
#endif

