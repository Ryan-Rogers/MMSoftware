 
#include <i2c.h>

#if defined (i2c_v1_1) || defined (i2c_v1_2) || defined (i2c_v1_3) || defined (i2c_v1_4)|| defined (i2c_v2_1) || defined (LIB_BUILD)

/***********************************************************************
Function Prototype : void SlaveWaitForIntrI2C1(void)
 
Include            : i2c.h
 
Description        : This routine will wait for Slave interrupt request and
                     then clear interrupt Flag.
 
Arguments          : None
 
Return Value       : None
 
Remarks            : None
************************************************************************/

void SlaveWaitForIntrI2C1(void)
{
   while(0 == IFS1bits.SI2C1IF);
   IFS1bits.SI2C1IF = 0;
}

#else
#warning "Does not build on this target"
#endif
