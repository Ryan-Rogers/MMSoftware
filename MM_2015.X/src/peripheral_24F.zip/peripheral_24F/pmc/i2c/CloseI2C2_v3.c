 
#include <i2c.h>

#if  defined (i2c_v3_2) || defined (LIB_BUILD)
/*********************************************************************
Function Prototype : void CloseI2C2_v3(void)

Include            : i2c.h 

Description        : This function turns off the I2C module 

Arguments          : None 

Return Value       : None
 
Remarks            : This function disables the I2C module and clears the
                     Master and Slave Interrupt Enable and Flag bits.
*********************************************************************/

void CloseI2C2_v3(void)
{
    /* clear the SSPEN bit */
    SSP2CON1bits.SSPEN = 0;

    /* clear the SSP2IE Interrupt enable bits */
    IEC3bits.SSP2IE = 0;
    
    /* clear the SSP2IF Interrupt flag bits */
    IFS3bits.SSP2IF = 0;
    }

#else
#warning "Does not build on this target"
#endif
