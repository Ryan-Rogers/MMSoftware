 
#include <i2c.h>

#if defined (i2c_v1_3) || defined (LIB_BUILD)  
/******************************************************************************
Function Prototype : void OpenI2C3(unsigned int config1, unsigned int config2)

Include            : i2c.h
 
Description        : Configures the I2C module
 
Arguments          : config1 - This contains the parameter to configure the I2CCON register

					 I2C Enable bit					
					   *	I2C_ON					
					   *	I2C_OFF					
					 I2C Stop in Idle Mode bit					
					   *	I2C_IDLE_STOP					
					   *	I2C_IDLE_CON					
					 SCL Release Control bit					
					   *	I2C_CLK_REL					
					   *	I2C_CLK_HLD					
					 Intelligent Peripheral Management Interface Enable bit					
					   *	I2C_IPMI_EN					
					   *	I2C_IPMI_DIS					
					 10-bit Slave Address bit					
					   *	I2C_10BIT_ADD					
					   *	I2C_7BIT_ADD					
					 Disable Slew Rate Control bit					
					   *	I2C_SLW_DIS					
					   *	I2C_SLW_EN					
					 SMBus Input Level bits					
					   *	I2C_SM_EN					
					   *	I2C_SM_DIS					
					 General Call Enable bit					
					   *	I2C_GCALL_EN					
					   *	I2C_GCALL_DIS					
					 SCL Clock Stretch Enable bit					
					   *	I2C_STR_EN					
					   *	I2C_STR_DIS					
					 Acknowledge Data bit					
					   *	I2C_ACK					
					   *	I2C_NACK					
					 Acknowledge Sequence Enable bit					
					   *	I2C_ACK_EN					
					   *	I2C_ACK_DIS					
					 Receive Enable bit					
					   *	I2C_RCV_EN					
					   *	I2C_RCV_DIS					
					 Stop Condition Enable bit					
					   *	I2C_STOP_EN					
					   *	I2C_STOP_DIS					
					 Repeated Start Condition Enable bit					
					   *	I2C_RESTART_EN					
					   *	I2C_RESTART_DIS					
					 Start Condition Enable bit					
					   *	I2C_START_EN					
					   *	I2C_START_DIS			 
					
					 config2 - computed value for the baud rate generator
	 
Return Value      :  None
					 
Remarks           :  This function configures the I2C Control register and I2C 
                     Baud Rate Generator register
*******************************************************************************/

void OpenI2C3(unsigned int config1,unsigned int config2)
{
    I2C3BRG = config2;
    I2C3CON = config1;
}

#else
#warning "Does not build on this target"
#endif
