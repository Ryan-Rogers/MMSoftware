 
#include <i2c.h>

#if defined (i2c_v1_2) || defined (i2c_v1_3) || defined (LIB_BUILD)
/*********************************************************************
Function Prototype : ConfigIntI2C2(unsigned int config) 

Include            : i2c.h

Description        : This function configures the I2C Interrupt.
 
Arguments          : config - I2C interrupt priority and enable/disable 
                     information as defined below
					 
                     Master I2C Interrupt Enable/Disable
                       *	MI2C_INT_ON  
                       *	MI2C_INT_OFF
                     I2C slave Interrupt enable/disable
                       *	SI2C_INT_ON
                       *	SI2C_INT_OFF
                     I2C master Interrupt priority
                       *	MI2C_INT_PRI_7					
					   *	MI2C_INT_PRI_6					
					   *	MI2C_INT_PRI_5					
					   *	MI2C_INT_PRI_4					
					   *	MI2C_INT_PRI_3					
					   *	MI2C_INT_PRI_2					
					   *	MI2C_INT_PRI_1					
					   *	MI2C_INT_PRI_0
					   *	MI2C_SRC_DIS 					
					 I2C slave Interrupt priority					
					   *	SI2C_INT_PRI_7					
					   *	SI2C_INT_PRI_6					
					   *	SI2C_INT_PRI_5					
					   *	SI2C_INT_PRI_4					
					   *	SI2C_INT_PRI_3					
					   *	SI2C_INT_PRI_2					
					   *	SI2C_INT_PRI_1					
					   *	SI2C_INT_PRI_0
					   *	SI2C_SRC_DIS	
					   				 
Return Value       : None 

Remarks            : This function clears the Interrupt Flag bits, 
                     sets the interrupt priorities of master and slave
                     and enables/disables the interrupt.
*********************************************************************/

void ConfigIntI2C2(unsigned int config)
{
     IFS3bits.SI2C2IF = 0;                       /* clear the MI2C & SI2C Interrupts */
     IFS3bits.MI2C2IF = 0;

		 IPC12bits.SI2C2P = (config & 0x0007);       /* set the SI2C priority */
		 IPC12bits.MI2C2P = (config & 0x0070) >> 4;    /* set the MI2C priority */

     IEC3bits.SI2C2IE = (config & 0x0008)>> 3;   /* enable/disable the SI2C Interrupt */
     IEC3bits.MI2C2IE = (config & 0x0080) >> 7;    /* enable/disable the MI2C Interrupt */
}

#else
#warning "Does not build on this target"
#endif
