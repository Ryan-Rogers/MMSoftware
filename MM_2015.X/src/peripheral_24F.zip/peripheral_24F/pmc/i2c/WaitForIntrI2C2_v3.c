 
#include <i2c.h>

#if defined (i2c_v3_2) || defined (LIB_BUILD)

/***********************************************************************
Function Prototype : void WaitForIntrI2C2_v3(void)
 
Include            : i2c.h
 
Description        : This routine will wait for Slave interrupt request and
                     then clear interrupt Flag.
 
Arguments          : None
 
Return Value       : None
 
Remarks            : None
************************************************************************/

void WaitForIntrI2C2_v3(void)
{
   while(0 == IFS3bits.SSP2IF);
   IFS3bits.SSP2IF = 0;
}

#else
#warning "Does not build on this target"
#endif
