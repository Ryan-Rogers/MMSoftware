 
#include <i2c.h>

#if defined (i2c_v1_1) || defined (i2c_v1_2) || defined (i2c_v1_3) || defined (i2c_v1_4)|| defined (i2c_v2_1) || defined (LIB_BUILD)
/******************************************************************************
Function Prototype : unsigned char MasterReadI2C1(void)
 
Include            : i2c.h
 
Description        : This function is used to read a single byte from I2C bus
 
Arguments          : None
 
Return Value       : The return value is the data byte read from the I2C bus.
 
Remarks            : This function reads in a single byte from the I2C bus.
                     This function performs the same function as MastergetcI2C.
********************************************************************************/

unsigned char MasterReadI2C1(void)
{
    I2C1CONbits.RCEN = 1;
    while(I2C1CONbits.RCEN);
    I2C1STATbits.I2COV = 0;
    return(I2C1RCV);
}

#else
#warning "Does not build on this target"
#endif
