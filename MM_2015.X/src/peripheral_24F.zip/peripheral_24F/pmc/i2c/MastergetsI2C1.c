 
#include <i2c.h>

#if defined (i2c_v1_1) || defined (i2c_v1_2) || defined (i2c_v1_3)|| defined (i2c_v1_4) || defined (i2c_v2_1) || defined (LIB_BUILD)
/***************************************************************************************************
Function Prototype :  unsigned int MastergetsI2C1(unsigned int length,
                          unsigned char *rdptr, unsigned int i2c_data_wait)
                           
Include            :  i2c.h 

Description        :  This function reads predetermined data string length from the I2C bus. 

Arguments          :  length - Number of bytes to read from I2C device.
                      rdptr - Character type pointer to RAM for storage of data read from I2C device
                      i2c_data_wait - This is the timeout count for which the module has
                      to wait before return. If the timeout count is �N�, the actual time out would
                      be about (20 * N � 1) instruction cycles. 
                      
Return Value       :  This function returns �0� if all bytes have been sent or number of bytes
                      read from I2C bus if its not able to read the data with in the specified
                      i2c_data_wait time out value 
                     
Remarks            :  This routine reads a predefined data string from the I2C bus.
******************************************************************************************************/

unsigned int MastergetsI2C1(unsigned int length, unsigned char * rdptr, unsigned int i2c1_data_wait)
{
    int wait = 0;
    while(length)                    /* Receive the number of bytes specified by length */
    {
        I2C1CONbits.RCEN = 1;
        while(!DataRdyI2C1())
        {
            if(wait < i2c1_data_wait)
                wait++ ;                 
            else
            return(length);          /* Time out, return number of byte/word to be read */			
        }
        wait = 0;
        *rdptr = I2C1RCV;             /* save byte received */
        rdptr++;
        length--;
        if(length == 0)              /* If last char, generate NACK sequence */
        {
            I2C1CONbits.ACKDT = 1;
            I2C1CONbits.ACKEN = 1;
        }
        else                         /* For other chars,generate ACK sequence */
        {
            I2C1CONbits.ACKDT = 0;
            I2C1CONbits.ACKEN = 1;
        }
            while(I2C1CONbits.ACKEN == 1);    /* Wait till ACK/NACK sequence is over */
    }
    return 0;    /* return status that number of bytes specified by length was received */
}

#else
#warning "Does not build on this target"
#endif
