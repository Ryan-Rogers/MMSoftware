 
#include <i2c.h>

#if defined (i2c_v3_2) || defined (LIB_BUILD)
/*********************************************************************
Function Prototype : ConfigIntI2C2_v3(unsigned int config) 

Include            : i2c.h

Description        : This function configures the I2C Interrupt.
 
Arguments          : config - I2C interrupt priority and enable/disable 
                     information as defined below
					 
                     Master I2C Interrupt Enable/Disable
                       *	I2C_INT_ON  
                       *	I2C_INT_OFF
                     
                     I2C master Interrupt priority
                       *	I2C_INT_PRI_7					
					   *	I2C_INT_PRI_6					
					   *	I2C_INT_PRI_5					
					   *	I2C_INT_PRI_4					
					   *	I2C_INT_PRI_3					
					   *	I2C_INT_PRI_2					
					   *	I2C_INT_PRI_1					
					   *	I2C_INT_PRI_0
					   *	I2C_SRC_DIS 					
					 
					   				 
Return Value       : None 

Remarks            : This function clears the Interrupt Flag bits, 
                     sets the interrupt priorities of master and slave
                     and enables/disables the interrupt.
*********************************************************************/

void ConfigIntI2C2_v3(unsigned int config)
{
     IFS3bits.SSP2IF = 0;                       /* clear the SSP2IF Interrupts */
     
	 IPC12bits.SSP2IP = (config & 0x0007);       /* set the SSP2IP priority */
	 	
     IEC3bits.SSP2IE = (config & 0x0008)>> 3;   /* enable/disable the SSP2IP Interrupt */
     
}

#else
#warning "Does not build on this target"
#endif
