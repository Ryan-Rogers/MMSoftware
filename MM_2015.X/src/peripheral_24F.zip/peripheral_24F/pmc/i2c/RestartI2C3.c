 
#include <i2c.h>


#if defined (i2c_v1_3) || defined (LIB_BUILD)  
/*************************************************************************
Function Prototype : void RestartI2C3(void)

Include            : i2c.h
 
Description        : Generates I2C Bus Restart condition.
 
Arguments          : None
 
Return Value       : None
 
Remarks            : This function generates an I2C Bus Restart condition.
**************************************************************************/

void RestartI2C3(void)
{
    I2C3CONbits.RSEN = 1;   /* initiate restart on SDA and SCL pins */
}

#else
#warning "Does not build on this target"
#endif
