 
#include <i2c.h>

#if defined (i2c_v1_2) || defined (i2c_v1_3) || defined (i2c_v1_4)|| defined (LIB_BUILD)
/************************************************************************
Function Prototype : char DataRdyI2C2(void) 

Include            : i2c.h 

Description        : This function provides status back to user if I2CRCV
                     register contain data. 
                     
Arguments          : None 

Return Value       : This function returns �1� if there is data in I2CRCV register;
                     else return �0� which indicates no data in I2CRCV register. 

Remarks            : This function determines if there is any byte to read from
                     I2CRCV register.
*************************************************************************/

char DataRdyI2C2(void)
{
     return I2C2STATbits.RBF;
}

#else
#warning "Does not build on this target"
#endif
