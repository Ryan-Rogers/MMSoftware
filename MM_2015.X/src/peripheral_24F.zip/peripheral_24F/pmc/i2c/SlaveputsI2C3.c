 
#include <i2c.h>

#if defined (i2c_v1_3) || defined (LIB_BUILD)  
/**************************************************************************************
Function Prototype : unsigned int SlaveputsI2C3(unsigned char *wrptr)

Include            : i2c.h
 
Description        : This function is used to write out a data string to the I2C bus.
 
Arguments          : wrptr - Character type pointer to data objects in RAM. The data 
                     objects are written to the I2C device.
 
Return Value       : This function returns �0� if the null character was reached in the 
                     data string.
 
Remarks            : This routine writes a data string out to the I2C bus until a null 
                     character is reached
***************************************************************************************/

unsigned int SlaveputsI2C3(unsigned char * wrptr)
{
    I2C3CONbits.STREN = 1;            /* SCL clock stretch enable bit */
    while(*wrptr)                /* transmit data until null char */
    {
        SlaveputcI2C3(*wrptr++);         /* Send a byte */
    while(I2C3STATbits.TBF);         /* wait till the transmit buffer is clear */
        while(!IFS5bits.SI2C3IF);     /* Wait till the ACK from master is received */
	    IFS5bits.SI2C3IF = 0;        /* Clear Flag */
    }
    return 0;                        /* null char was reached */
}

#else
#warning "Does not build on this target"
#endif
