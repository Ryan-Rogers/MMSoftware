 
#include <i2c.h>

#if defined (i2c_v1_3)  || defined (LIB_BUILD) 
/*********************************************************************
Function Prototype : void CloseI2C3(void)

Include            : i2c.h 

Description        : This function turns off the I2C module 

Arguments          : None 

Return Value       : None 

Remarks            : This function disables the I2C module and clears the
                     Master and Slave Interrupt Enable and Flag bits.
*********************************************************************/
void CloseI2C3(void)
{
    /* clear the I2CEN bit */
    I2C3CONbits.I2CEN = 0;

    /* clear the SI2C3 & MI2C3 Interrupt enable bits */
    IEC5bits.SI2C3IE = 0;
    IEC5bits.MI2C3IE = 0;

    /* clear the SI2C2 & MI2C2 Interrupt flag bits */
    IFS5bits.SI2C3IF = 0;
    IFS5bits.MI2C3IF = 0;
}

#else
#warning "Does not build on this target"
#endif
