 
#include <i2c.h>

#if defined (i2c_v1_3) || defined (LIB_BUILD)  
/*********************************************************************************
Function Prototype : void NotAckI2C3(void)
 
Include            : i2c.h
 
Description        : Generates I2C bus Not Acknowledge condition during Master Receive.
 
Arguments          : None
 
Return Value       : None
 
Remarks            : This function generates an I2C bus Not Acknowledge condition.
**********************************************************************************/
void NotAckI2C3(void)
{
    I2C3CONbits.ACKDT = 1;
    I2C3CONbits.ACKEN = 1;
}

#else
#warning "Does not build on this target"
#endif
