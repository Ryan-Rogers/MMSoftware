 
#include <i2c.h>

#if defined (i2c_v1_3) || defined (LIB_BUILD)  
/*********************************************************************
Function Prototype : void StartI2C3(void)
 
Include            : i2c.h
 
Description        : Generates I2C Bus Start condition.
 
Arguments          : None
 
Return Value       : None
 
Remarks            : This function generates a I2C Bus Start condition.
*********************************************************************/

void StartI2C3(void)
{
     I2C3CONbits.SEN = 1;   /* initiate Start on SDA and SCL pins */
}
#else
#warning "Does not build on this target"
#endif
