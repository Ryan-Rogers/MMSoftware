 
#include <i2c.h>

#if defined (i2c_v1_2) || defined (i2c_v1_3) || defined (i2c_v1_4)|| defined (LIB_BUILD)
/***********************************************************************
Function Prototype : void MasterWaitForIntrI2C2(void)
 
Include            : i2c.h
 
Description        : This routine will wait for Master interrupt request 
                     and then clear interrupt Flag.
                      
Arguments          : None
 
Return Value       : None
 
Remarks            : It wait for Master interrupt request and then 
                     clear interrupt Flag.
************************************************************************/

void MasterWaitForIntrI2C2(void)
{
   while(0 == IFS3bits.MI2C2IF);
   IFS3bits.MI2C2IF = 0;
}

#else
#warning "Does not build on this target"
#endif
