 
#include <i2c.h>

#if defined (i2c_v1_1) || defined (i2c_v1_2) || defined (i2c_v1_3) || defined (i2c_v1_4)|| defined (i2c_v2_1) || defined (LIB_BUILD)
/*********************************************************************
Function Prototype : void StopI2C1(void)
 
Include            : i2c.h
 
Description        : Generates I2C Bus Stop condition.
 
Arguments          : None
 
Return Value       : None
 
Remarks            : This function generates a I2C Bus Stop condition.
*********************************************************************/

void StopI2C1(void)
{
     I2C1CONbits.PEN = 1;   /* initiate Stop on SDA and SCL pins */
}
#else
#warning "Does not build on this target"
#endif
