 
#include <i2c.h>

#if defined (i2c_v1_3) || defined (LIB_BUILD)  
/**********************************************************************************
Function Prototype : unsigned int SlavegetsI2C3(unsigned char *rdptr, 
                                              unsigned int i2c_data_wait)
                                              
Include            : i2c.h
 
Description        : This function reads pre-determined data string length 
                     from the I2C bus.
 
Arguments          : rdptr - Character type pointer to RAM for storage of data 
                     read from I2C device.
                     i2c_data_wait - This is the time-out count for which the 
                     module has  to wait before return.
                     If the timeout count is �N�, the actual time out would
                     be about (20*N-1) instruction cycles.
 
Return Value       : Returns the number of bytes received from the I2C bus.
 
Remarks            : This routine reads a predefined data string from the I2C bus.
************************************************************************************/

unsigned int SlavegetsI2C3(unsigned char * rdptr, unsigned int i2c3_data_wait)
{
    int i = 0;                          /* i indicates number of bytes received */
    int wait = 0;
    unsigned char temp = I2C3RCV;       /* flush out old data already on I2CRCV to clear RBF flag */

    I2C3STATbits.I2COV = 0;             /* clear OV flag */

    while(!I2C3STATbits.P)              /* check for stop bit */
    {
        while(!DataRdyI2C3())
        {
            if(wait < i2c3_data_wait)   /* timeout check */
                wait++ ;
            else
                return i;               /* return the number of bytes received */
        }
        wait = 0;
        *rdptr++ = I2C3RCV;             /* save byte received */

        i++;                            /* Increment the number of bytes read */

	// Below Commented Sequence is applicable only to Master		
    //    I2C3CONbits.ACKDT = 0;      	/* generate ACK sequence */
    //    I2C3CONbits.ACKEN = 1;
    //    while(I2C3CONbits.ACKEN == 1);  /* Wait till ACK sequence is over */

        if((I2C3CONbits.STREN) && (!I2C3CONbits.SCLREL))
            I2C3CONbits.SCLREL = 1; 	/* Clock is released after ACK */

    }
    return i;               			/* return the number of bytes received */
}

#else
#warning "Does not build on this target"
#endif
