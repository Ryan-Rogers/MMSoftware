 
#include <i2c.h>

#if defined (i2c_v3_1) || defined (i2c_v3_2)  || defined (LIB_BUILD)
/**********************************************************************************
Function Prototype : unsigned int getsI2C1_v3(unsigned char *rdptr, 
                                                unsigned int i2c_data_wait)
                                              
Include            : i2c.h
 
Description        : This function reads pre-determined data string length 
                     from the I2C bus.
 
Arguments          : rdptr - Character type pointer to RAM for storage of data 
                     read from I2C device.
                     i2c_data_wait - This is the time-out count for which the 
                     module has  to wait before return.
                     If the timeout count is �N�, the actual time out would
                     be about (20*N-1) instruction cycles.
 
Return Value       : Returns the number of bytes received from the I2C bus.
 
Remarks            : This routine reads a predefined data string from the I2C bus.
************************************************************************************/

unsigned int getsI2C1_v3(unsigned char * rdptr, unsigned char length )
{
while ( length-- )            // perform getcI2C1() for 'length' number of bytes
    {
      unsigned int word;
	   *rdptr++ = word;       // save byte received
	  
      while ( SSP1CON2bits.RCEN ); // check that receive sequence is over    

      if ( IFS1bits.SSP1BCIF )       // test for bus collision
      {
        return ( -1 );             // return with Bus Collision error 
      }

	  
	if( ((SSP1CON1&0x0F)==0x08) || ((SSP1CON1&0x0F)==0x0B) )	//master mode only
	{	
      if ( length )               // test if 'length' bytes have been read
      {
        SSP1CON2bits.ACKDT = 0;    // set acknowledge bit state for ACK        
        SSP1CON2bits.ACKEN = 1;    // initiate bus acknowledge sequence
        while ( SSP1CON2bits.ACKEN ); // wait until ACK sequence is over 
      } 
	} 
	  
    }
    return ( 0 );                
}




#else
#warning "Does not build on this target"
#endif
