
#include <i2c.h>

#if defined (i2c_v3_2) || defined (LIB_BUILD)
/********************************************************************
*     Function Name:    ReadI2C1                                    *
*     Return Value:     contents of SSP2BUF register                *
*     Parameters:       void                                        *
*     Description:      Read single byte from I2C1 bus.             *
********************************************************************/
unsigned char ReadI2C2_v3( void )
{

if( ((SSP2CON1&0x0F)==0x08) || ((SSP2CON1&0x0F)==0x0B) )	//master mode only
  {
  SSP2CON2bits.RCEN = 1;           // enable master for 1 byte reception
  while ( !SSP2STATbits.BF );      // wait until byte received  
  return ( SSP2BUF );              // return with read byte 
  }
  
 else if( ((SSP2CON1&0x0F)== !0x08) || ((SSP2CON1&0x0F)== !0x0B) )	//slave mode
  {
  while ( !SSP2STATbits.BF );      // wait until byte received  
  return ( SSP2BUF );              // return with read byte 
  }
}
#endif
