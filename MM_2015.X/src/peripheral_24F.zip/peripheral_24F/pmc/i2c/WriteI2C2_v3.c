 
#include <i2c.h>

#if  defined (i2c_v3_2) || defined (LIB_BUILD)
/****************************************************************************
Function Prototype : unsigned char WriteI2C2_v3(unsigned char data_out)
 
Include            : i2c.h
 
Description        : This function is used to write out a single byte to the I2C bus.
 
Arguments          : data_out - A single data byte to be written to the I2C bus device.
 
Return Value       : None
 
Remarks            : This function writes out a single data byte to the I2C bus device.
                     This function performs the same function as SlaveputcI2C.
******************************************************************************/

unsigned char WriteI2C2_v3(unsigned char data_out)
{
  SSP2BUF = data_out;           // write single byte to SSP1BUF
  if ( SSP2CON1bits.WCOL )      // test if write collision occurred
    return ( -1 );              // if WCOL bit is set return negative #
  else
  {
    if( ((SSP2CON1&0x0F)!=0x08) && ((SSP2CON1&0x0F)!=0x0B) )	//slave mode only 
	{
      SSP2CON1bits.CKP = 1;        // release clock line 
      while ( !IFS3bits.SSP2IF );  // wait until ninth clock pulse received

      if ( ( !SSP2STATbits.R_W ) && ( !SSP2STATbits.BF ) )// if R/W=0 and BF=0, NOT ACK was received
      {
        return ( -2 );             //Return NACK
      }	
	  else return(0);				//Return ACK
	
    }
	else if( ((SSP2CON1&0x0F)==0x08) || ((SSP2CON1&0x0F)==0x0B) )	//master mode only	
	{
		while( SSP2STATbits.BF );   // wait until write cycle is complete      
		while(SSP1CON2bits.SEN || SSP1CON2bits.RSEN || SSP1CON2bits.PEN || SSP1CON2bits.RCEN ||
           SSP1CON2bits.ACKEN ||  SSP1STATbits.R_W );  // ensure module is idle
	    if ( SSP2CON2bits.ACKSTAT ) // test for ACK condition received
	    	 return ( -2 );				//Return NACK	
		else return ( 0 );               //Return ACK
	}
  }
}

#else
#warning "Does not build on this target"
#endif
