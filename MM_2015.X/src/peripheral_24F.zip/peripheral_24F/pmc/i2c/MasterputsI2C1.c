 
#include <i2c.h>

#if defined (i2c_v1_1) || defined (i2c_v1_2) || defined (i2c_v1_3) || defined (i2c_v1_4)|| defined (i2c_v2_1) || defined (LIB_BUILD)
/**************************************************************************************
Function Prototype : char MasterputsI2C1(unsigned char *wrptr) 

Include            : i2c.h 

Description        : This function is used to write out a data string to the I2C bus. 

Arguments          : wrptr - Character type pointer to data objects in RAM. The data
                     objects are written to the I2C device.
                      
Return Value       : This function returns -3 if a write collision occurred.
                     This function returns �0� if the null character was reached 
                     in data string.
	                  
Remarks            : This routine writes a predefined data string from the I2C bus.
**************************************************************************************/

char MasterputsI2C1(unsigned char * wrptr)
{
    while(*wrptr)                           //transmit data until null char
    {
        if(MasterputcI2C1(*wrptr) == -1)        // write a byte
        return -3;                          //return with write collison error

        while(I2C1STATbits.TBF);             //Wait till data is transmitted.

        IdleI2C1();
        wrptr++;
    }
    return 0;           
}
#else
#warning "Does not build on this target"
#endif
