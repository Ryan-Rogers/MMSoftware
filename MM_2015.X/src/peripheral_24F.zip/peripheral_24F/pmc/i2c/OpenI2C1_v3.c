 
#include <i2c.h>

#if defined (i2c_v3_1) || defined (i2c_v3_2) || defined (LIB_BUILD)  
/******************************************************************************
Function Prototype : void OpenI2C1_v3(unsigned int config1,unsigned int config2,unsigned int config3,unsigned int config4,unsigned char sync_mode, unsigned char slew)

Include            : i2c.h
 
Description        : Configures the I2C module
 
Arguments          : config1 - This contains the parameter to configure the SSP1CON1 register

					 I2C Enable bit					
					 * I2C_MSSP_ENABLE    		
					 *I2C_MSSP_DISABLE    		
									
					SCL Release Control bit					
					   *	I2C_SLAVE_CLK_REL					
					   *	I2C_SLAVE_CLK_HLD						
				
					MSSP Mode Select bits
					 *I2C_SLAVE_7   			
					 *I2C_SLAVE_10  			
					 *I2C_MASTER    			
					 *I2C_MASTER_FIRMW			
					 *I2C_SLAVE_7_STSP_INT 		
					 *I2C_SLAVE_10_STSP_INT
					 
			        config2- config1 - This contains the parameter to configure the SSP1CON2 register
					 General Call Enable bit
					  * I2C_GEN_CALL_ENABLE 		
					   *I2C_GEN_CALL_DISABLE	

					Acknowledge Sequence Enable bit					
					   *	I2C_ACK_ENABLE					
					   *	I2C_ACK_IDLE	
							
					Receive Enable bit					
					   *	I2C_RECEIVE_ENABLE					
					   *	I2C_RECEIVE_DISABLE	
					   
					 Stop Condition Enable bit					
					   *	I2C_STOP_ENABLE					
					   *	I2C_STOP_IDLE
									
					Repeated Start Condition Enable bit					
					   *	I2C_REP_START_ENABLE					
					   *	I2C_REP_START_IDLE

					Start Condition Enable bit					
					   *	I2C_MASTR_START_ENABLE					
					   *	I2C_MASTR_START_IDLE
					   
					Clock stretching bit for slave 
						* I2C_SLAVE_CLK_STRCH_ENABLE
						* I2C_SLAVE_CLK_STRCH_DISABLE
								 
					config3 - computed value for the baud rate generator
					
					config4- This contains the parameter to configure the SSP1STAT register
						Disable Slew Rate Control bit					
					   *	I2C_SLEW_OFF					
					   *	I2C_SLEW_ON					
					  SMBus Input Level bits					
					   *	I2C_SMBUS_ENABLE					
					   *	I2C_SMBUS_DISABLE		
	 
Return Value      :  None
					 
Remarks           :  This function configures the I2C Control register and I2C 
                     Baud Rate Generator register
*******************************************************************************/

void OpenI2C1_v3(unsigned int config1,unsigned int config2,unsigned int config3,unsigned int config4,unsigned char sync_mode, unsigned char slew)
{
  SSP1STAT = config4;                 
  SSP1CON1 = config1;                 // power on state
  SSP1CON2 = config2;                 // power on state
  SSP1ADD = config3;
  SSP1CON1 |= sync_mode;           // select serial mode 
  SSP1STAT |= slew;                // slew rate on/off 
	
  SSP1CON1bits.SSPEN=1;              // enable synchronous serial port 

    
}

#else
#warning "Does not build on this target"
#endif

