 
#include <i2c.h>

#if defined (i2c_v1_3) || defined (LIB_BUILD)  
/****************************************************************************
Function Prototype : void SlaveWriteI2C3(unsigned char data_out)
 
Include            : i2c.h
 
Description        : This function is used to write out a single byte to the I2C bus.
 
Arguments          : data_out - A single data byte to be written to the I2C bus device.
 
Return Value       : None
 
Remarks            : This function writes out a single data byte to the I2C bus device.
                     This function performs the same function as SlaveputcI2C.
******************************************************************************/

void SlaveWriteI2C3(unsigned char data_out)
{
     I2C3TRN = data_out;      /* data transferred to I2C3TRN reg */
     I2C3CONbits.SCLREL = 1;    /* Release the clock */
}

#else
#warning "Does not build on this target"
#endif
