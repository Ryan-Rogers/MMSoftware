
#include <i2c.h>

#if defined (i2c_v3_1) || defined (i2c_v3_2) || defined (LIB_BUILD)
/********************************************************************
*     Function Name:    ReadI2C1_v3                                    *
*     Return Value:     contents of SSP1BUF register                *
*     Parameters:       void                                        *
*     Description:      Read single byte from I2C1 bus.             *
********************************************************************/
unsigned char ReadI2C1_v3( void )
{

if( ((SSP1CON1&0x0F)==0x08) || ((SSP1CON1&0x0F)==0x0B) )	//master mode only
 {
 SSP1CON2bits.RCEN = 1;           // enable master for 1 byte reception
  while ( !SSP1STATbits.BF );      // wait until byte received  
  return ( SSP1BUF );              // return with read byte 
}  
 else if( ((SSP1CON1&0x0F)== !0x08) || ((SSP1CON1&0x0F)== !0x0B) )	//slave mode 
  {
  while ( !SSP1STATbits.BF );      // wait until byte received  
	return ( SSP1BUF );              // return with read byte 
  }
}
#endif
