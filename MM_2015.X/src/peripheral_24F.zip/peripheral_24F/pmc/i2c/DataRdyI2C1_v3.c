 
#include <i2c.h>

#if defined (i2c_v3_1) || defined (i2c_v3_2) || defined (LIB_BUILD)
/************************************************************************
Function Prototype : char DataRdyI2C1_v3(void) 

Include            : i2c.h 

Description        : This function provides status back to user if I2CRCV
                     register contain data. 
                     
Arguments          : None 

Return Value       : This function returns �1� if there is data in I2CRCV register;
                     else return �0� which indicates no data in I2CRCV register. 

Remarks            : This function determines if there is any byte to read from
                     I2CRCV register.
*************************************************************************/

char DataRdyI2C1_v3(void)
{
     return SSP1STATbits.BF ;
}

#else
#warning "Does not build on this target"
#endif
