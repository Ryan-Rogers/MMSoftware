 
#include <i2c.h>

#if defined (i2c_v1_3) || defined (LIB_BUILD)  
/************************************************************************************************
Function Prototype : char MasterWriteI2C3(unsigned char data_out)

Include            : i2c.h
 
Description        : This function is used to write out a single data byte to the I2C device.
 
Arguments          : data_out - A single data byte to be written to the I2C bus device.
 
Return Value       : This function returns -1 if there was a write collision else it returns a 0.
 
Remarks            : This function writes  a single byte to the I2C bus.
                     This function performs the same function as MasterputcI2C.
**************************************************************************************************/

char MasterWriteI2C3(unsigned char data_out)
{
    I2C3TRN = data_out;

    if(I2C3STATbits.IWCOL)        /* If write collision occurs,return -1 */
        return -1;
    else
    {
        return 0;
    }
}

#else
#warning "Does not build on this target"
#endif
