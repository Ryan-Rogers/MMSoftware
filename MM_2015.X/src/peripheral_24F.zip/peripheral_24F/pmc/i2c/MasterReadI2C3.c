 
#include <i2c.h>

#if defined (i2c_v1_3) || defined (LIB_BUILD)  
/******************************************************************************
Function Prototype : unsigned char MasterReadI2C3(void)
 
Include            : i2c.h
 
Description        : This function is used to read a single byte from I2C bus
 
Arguments          : None
 
Return Value       : The return value is the data byte read from the I2C bus.
 
Remarks            : This function reads in a single byte from the I2C bus.
                     This function performs the same function as MastergetcI2C.
********************************************************************************/

unsigned char MasterReadI2C3(void)
{
    I2C3CONbits.RCEN = 1;
    while(I2C3CONbits.RCEN);
    I2C3STATbits.I2COV = 0;
    return(I2C3RCV);
}

#else
#warning "Does not build on this target"
#endif
