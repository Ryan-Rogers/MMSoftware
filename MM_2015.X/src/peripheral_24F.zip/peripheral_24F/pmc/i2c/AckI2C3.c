 
#include "i2c.h"

#if defined (i2c_v1_3) || defined (LIB_BUILD)  
/*********************************************************************
Function Prototype  : void AckI2C3(void)

Include             : i2c.h

Description         : Generates I2C bus Acknowledge condition.

Arguments           : None

Return Value        : None

Remarks             : This function generates an I2C bus Acknowledge 
                      condition.
*********************************************************************/
void AckI2C3(void)
{
    I2C3CONbits.ACKDT = 0;
    I2C3CONbits.ACKEN = 1;
}

#else
#warning "Does not build on this target"
#endif
