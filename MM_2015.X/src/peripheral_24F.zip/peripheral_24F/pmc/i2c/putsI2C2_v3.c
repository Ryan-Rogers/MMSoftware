 
#include <i2c.h>

#if defined (i2c_v3_2)  || defined (LIB_BUILD)
/**************************************************************************************
Function Prototype : unsigned int putsI2C1_v3(unsigned char *wrptr)

Include            : i2c.h
 
Description        : This function is used to write out a data string to the I2C bus.
 
Arguments          : wrptr - Character type pointer to data objects in RAM. The data 
                     objects are written to the I2C device.
 
Return Value       : This function returns �0� if the null character was reached in the 
                     data string.
 
Remarks            : This routine writes a data string out to the I2C bus until a null 
                     character is reached
***************************************************************************************/

unsigned int putsI2C2_v3(unsigned char * wrptr)
{
    unsigned char temp;  
	while ( *wrptr )                 /* transmit data until null character */
  {
    if ( SSP2CON1bits.SSPM3 )      /* if Master transmitter then execute the following */
    {
	    SSP2BUF = *wrptr ;           // write single byte to SSP1BUF
		 if ( SSP2CON1bits.WCOL )      // test if write collision occurred
		return ( temp =-1 );              // if WCOL bit is set return negative #
		else
		{
			if( ((SSP2CON1&0x0F)!=0x08) && ((SSP2CON1&0x0F)!=0x0B) )	//slave mode only 
			{
			  SSP2CON1bits.CKP = 1;        // release clock line 
			  while ( !IFS3bits.SSP2IF );  // wait until ninth clock pulse received

			  if ( ( !SSP2STATbits.R_W ) && ( !SSP2STATbits.BF ) )// if R/W=0 and BF=0, NOT ACK was received
			  {
				return (temp = -2 );             //Return NACK
			  }	
			  else return(temp =0);				//Return ACK
			
			}
			else if( ((SSP2CON1&0x0F)==0x08) || ((SSP2CON1&0x0F)==0x0B) )	//master mode only	
			{
				while( SSP2STATbits.BF );   // wait until write cycle is complete      
				while(SSP1CON2bits.SEN || SSP1CON2bits.RSEN || SSP1CON2bits.PEN || SSP1CON2bits.RCEN ||
				   SSP1CON2bits.ACKEN ||  SSP1STATbits.R_W );  // ensure module is idle
				if ( SSP2CON2bits.ACKSTAT ) // test for ACK condition received
					 return ( temp =-2 );				//Return NACK	
				else return ( temp =0 );               //Return ACK
			}
		}
			if (temp ) return ( temp );   	
  }

    else                           /* else Slave transmitter */ 
    {
      IFS3bits.SSP2IF = 0;         /* reset SSP1IF bit*/
      SSP1BUF = *wrptr;            /* load SSP1BUF with new data */
      SSP2CON1bits.CKP = 1;        /* release clock line */
      while ( !IFS3bits.SSP2IF );  /* wait until ninth clock pulse received */

      if ( ( SSP2CON1bits.CKP ) && ( !SSP1STATbits.BF ) )/* if R/W=0 and BF=0, NOT ACK was received */
      {
        return ( -2 );             /* terminate PutsI2C1() function */
      }
    }

  wrptr ++;                        /* increment pointer */

  }                                /* continue data writes until null character */

  return ( 0 );
 }

#else
#warning "Does not build on this target"
#endif
