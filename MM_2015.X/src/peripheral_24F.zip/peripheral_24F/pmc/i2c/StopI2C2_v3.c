 
#include <i2c.h>

#if defined (i2c_v3_2) || defined (LIB_BUILD)
/*********************************************************************
Function Prototype : void StopI2C2_v3(void)
 
Include            : i2c.h
 
Description        : Generates I2C Bus Stop condition.
 
Arguments          : None
 
Return Value       : None
 
Remarks            : This function generates a I2C Bus Stop condition.
*********************************************************************/

void StopI2C2_v3(void)
{
     SSP2CON2bits.PEN = 1;   /* initiate Stop on SDA and SCL pins */
}

#else
#warning "Does not build on this target"
#endif
