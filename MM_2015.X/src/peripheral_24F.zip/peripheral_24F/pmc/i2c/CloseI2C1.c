 
#include <i2c.h>

#if defined (i2c_v1_1) || defined (i2c_v1_2)  || defined (i2c_v1_3)|| defined (i2c_v1_4)|| defined (i2c_v2_1) || defined (LIB_BUILD)
/*********************************************************************
Function Prototype : void CloseI2C1(void)

Include            : i2c.h 

Description        : This function turns off the I2C module 

Arguments          : None 

Return Value       : None 

Remarks            : This function disables the I2C module and clears the
                     Master and Slave Interrupt Enable and Flag bits.
*********************************************************************/
void CloseI2C1(void)
{
    /* clear the I2CEN bit */
    I2C1CONbits.I2CEN = 0;

    /* clear the SI2C & MI2C Interrupt enable bits */
    IEC1bits.SI2C1IE = 0;
    IEC1bits.MI2C1IE = 0;

    /* clear the SI2C & MI2C Interrupt flag bits */
    IFS1bits.SI2C1IF = 0;
    IFS1bits.MI2C1IF = 0;
}

#else
#warning "Does not build on this target"
#endif
