 
#include <i2c.h>

#if defined (i2c_v3_1) || defined (i2c_v3_2) || defined (LIB_BUILD)
/*********************************************************************
Function Prototype : void CloseI2C1_v3(void)

Include            : i2c.h 

Description        : This function turns off the I2C module 

Arguments          : None 

Return Value       : None
 
Remarks            : This function disables the I2C module and clears the
                     Master and Slave Interrupt Enable and Flag bits.
*********************************************************************/

void CloseI2C1_v3(void)
{
    /* clear the SSPEN bit */
    SSP1CON1bits.SSPEN = 0;

    /* clear the SSP1IE Interrupt enable bits */
    IEC1bits.SSP1IE = 0;
    
    /* clear the SSP1IF Interrupt flag bits */
    IFS1bits.SSP1IF = 0;
    }

#else
#warning "Does not build on this target"
#endif
