 
#include "i2c.h"

#if defined (i2c_v3_1) || defined (i2c_v3_2)|| defined (LIB_BUILD)
/*********************************************************************
Function Prototype  : void AckI2C1_v3(void)

Include             : i2c.h

Description         : Generates I2C bus Acknowledge condition.

Arguments           : None

Return Value        : None

Remarks             : This function generates an I2C bus Acknowledge 
                      condition.
*********************************************************************/
void AckI2C1_v3(void)
{
    SSP1CON2bits.ACKDT = 0;            // set acknowledge bit state for ACK
	SSP1CON2bits.ACKEN = 1;           // initiate bus acknowledge sequence
}

#else
#warning "Does not build on this target"
#endif
