#include "ecrc.h"
 
#if defined (ecrc_v1_1) || defined (LIB_BUILD)
/***************************************************************************************
Function           : unsigned char CRC_Calc_ChecksumByte(unsigned char* data, unsigned short int Number_of_bytes, 
                                                  unsigned short int prev_CRC)
                                          
Description        : This function calculates CRC checksum for the data provide by the 
                     user,based on the polynomial set in the CRCXOR Register.
 
Arguments          : data - Pointer to the first data byte for which CRC needs to    
                     be calculated.
                     Number_of_bytes - Total number of bytes for which CRC needs 
                     to be calculated.
                     prev_CRC - previous CRC result.
                     
Returns            : Returns One Byte CRC checksum based on the set polynomial.
 
Remarks            : Input parameter is provided as a provision to allow continuation 
                     of previously being computed checksum. In case the checksum is
                     being calculated for a fresh set of data then the input value for
                     prev_CRC should be '0'.
*****************************************************************************************/  
unsigned char ECRC_Calc_ChecksumByte(unsigned char* data, unsigned short int Number_of_bytes, unsigned long int prev_CRC)
{
   SET_ECRC_RESULT(prev_CRC);
   do
   {
       while(1 != Get_ECRC_FIFO_EMPTY_STATUS());
       Stop_ECRC_Calulation();
       while((0 == Get_ECRC_FIFO_FULL_STATUS() && (0 < Number_of_bytes)))
       {
          WRITE_ECRC_DATA_BYTE(*data);
          data++;
          Number_of_bytes--;
       }
       Start_ECRC_Calulation();
   }while (0 < Number_of_bytes);

   while(1 != Get_ECRC_FIFO_EMPTY_STATUS());
   Nop();
   Nop();
   return((unsigned char)GET_ECRC_RESULT());
}
#else
#warning "Does not build on this target"
#endif
