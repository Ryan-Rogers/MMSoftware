#include "ecrc.h"
 
#if defined (ecrc_v1_1) || defined (LIB_BUILD)
/********************************************************************************* 
   Function           : void ECRC_Poly(unsigned short int polylow , unsigned short int polyhigh)
   
   Description        : This function configures CRC module.
   
   Arguments          :  poly - Polynomial to calculate CRC
			 	
   Returns            : None
   
   Remarks            : This function configures the XOR of polynomial term 
***********************************************************************************/

void ECRC_Poly(unsigned short int polylow , unsigned short int polyhigh)
{
   CRCXORL = polylow;
   CRCXORH = polyhigh;
}

#else
#warning "Does not build on this target"
#endif

