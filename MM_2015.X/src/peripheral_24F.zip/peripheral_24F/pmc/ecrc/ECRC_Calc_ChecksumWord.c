#include "ecrc.h"
 
#if defined (ecrc_v1_1) || defined (LIB_BUILD)
/***************************************************************************************
Function           : unsigned short int ECRC_Calc_ChecksumWord(unsigned short int* data,unsigned short int Number_of_words,
                                                    unsigned short int prev_CRC)

Description        : This function calculates CRC checksum for the data provide by the 
                     user,based on the polynomial set in the CRCXOR Register.
 
Arguments          : data - Pointer to the first data word for which CRC needs to    
                     be calculated.
                     Number_of_words - Total number of words for which CRC needs 
                     to be calculated.
                     prev_CRC - previous CRC result.
                     
Returns            : Returns Two Byte CRC checksum based on the set polynomial.
 
Remarks            : Input parameter is provided as a provision to allow continuation 
                     of previously being computed checksum. In case the checksum is
                     being calculated for a fresh set of data then the input value for
                     prev_CRC should be '0'.
***************************************************************************************/  

unsigned short int ECRC_Calc_ChecksumWord(unsigned short int* data, unsigned short int Number_of_words, unsigned long int prev_CRC)
{
   SET_ECRC_RESULT(prev_CRC);
   do
   {
       while(1 != Get_ECRC_FIFO_EMPTY_STATUS());
       Stop_ECRC_Calulation();
       while((0 == Get_ECRC_FIFO_FULL_STATUS() && (0 < Number_of_words)))
       {
          WRITE_ECRC_DATA_WORD(*data);
          data++;
          Number_of_words--;
       }
       Start_ECRC_Calulation();
  }while (0 < Number_of_words);

   while(1 != Get_ECRC_FIFO_EMPTY_STATUS());
   Nop();
   Nop();
   return((unsigned short int)GET_ECRC_RESULT());
}
#else
#warning "Does not build on this target"
#endif
