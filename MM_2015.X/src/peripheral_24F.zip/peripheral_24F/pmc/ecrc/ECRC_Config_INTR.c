#include "ecrc.h"

#if defined (ecrc_v1_1) || defined (LIB_BUILD)
/********************************************************************************** 
   Function           : void ECRC_Config_INTR(unsigned char intr_byte)
   
   Description        :This function configures CRC interrupts.
  
   Arguments          : intr_byte -  I2C interrupt priority and enable/disable
                        information as defined below
                        CRC Interrupt enable/disable
	                        *	ECRC_INT_ENABLE
	                        *	ECRC_INT_DISABLE
                        ECRC Interrupt priority
	                        *	ECRC_INT_PRIOR_7
	                        *	ECRC_INT_PRIOR_6
	                        *	ECRC_INT_PRIOR_5
	                        *	ECRC_INT_PRIOR_4
	                        *	ECRC_INT_PRIOR_3
	                        *	ECRC_INT_PRIOR_2
	                        *	ECRC_INT_PRIOR_1
	                        *	ECRC_INT_PRIOR_0
   
   Returns            : None
   
   Remarks            : This function clears the Interrupt Flag bits, sets the
                        interrupt priorities of master and slave and enables/disables
                        the interrupt  
*************************************************************************************/                                                                                        

void ECRC_Config_INTR(unsigned char intr_byte)
{
   IFS4bits.CRCIF = 0;                       /* clear the CRC Interrupts */

   IPC16bits.CRCIP = (intr_byte & 0x07);
   IEC4bits.CRCIE = (intr_byte & 0x08)>>3;
}
#else
#warning "Does not build on this target"
#endif
