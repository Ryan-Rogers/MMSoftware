#include "ecrc.h"
 
#if defined (ecrc_v1_1) || defined (LIB_BUILD)
/********************************************************************************* 
   Function           : void ECRC_Config(unsigned short int config1 , unsigned short int config2)
   
   Description        : This function configures CRC module.
   
   Arguments          : config1 - This contains the parameter configured in CRCCON1
				      register as defined below
					  ECRC enable
						*    ECRC_MODULE_ENABLE
						*    ECRC_MODULE_RESET
						*    ECRC_MODULE_ENABLE_MASK
					ECRC interrupt selection
						*    ECRC_INTERRUPT_ON_FIFO_EMPTY
						*    ECRC_INTERRUPT_ON_RESULT_READY
						*    ECRC_INTERRUPT_SELLECT_MASK
					ECRC data shift direction
						*    ECRC_LITTLE_ENDIAN
						*    ECRC_BIG_ENDIAN						
					  ECRC Mode bit
						 *	ECRC_IDLE_STOP
						 *	ECRC_IDLE_CON
					  Start CRC bit 
						 *	ECRC_START_SERIAL_SHIFT
						 *	ECRC_SERIAL_SHIFT_OFF
					 config2 - This contains the parameter configured in CRCCON2 
					 register as defined below.
					 Valid Data width words
					 	 *	ECRC_DATA_WIDTH1 
						 *	ECRC_DATA_WIDTH2
						 *	..... 
						 *	ECRC_DATA_WIDTH31
						 *	ECRC_DATA_WIDTH32
					 
					 Valid words 
						 *	ECRC_POLYNOMIAL_LEN1 
						 *	ECRC_POLYNOMIAL_LEN2
						 *	..... 
						 *	ECRC_POLYNOMIAL_LEN31
						 *	ECRC_POLYNOMIAL_LEN32
						 			 
						             
   Returns            : None
   
   Remarks            : This function configures the CRCCON1,CRCCON2 register.
***********************************************************************************/
void ECRC_Config(unsigned short int config1 , unsigned short int config2)
{
   CRCCON1 = config1;
   CRCCON2 = config2;
}


#else
#warning "Does not build on this target"
#endif
