 
#include<ports.h>

#if defined (int_v1_1) || defined (int_v1_2) || defined (LIB_BUILD)
/****************************************************************************
Function Prototype : void CloseINT0(void)
 
Include            : ports.h
 
Description        : This function disables the external interrupt on INT pin.
 
Arguments          : None
 
Return Value       : None
 
Remarks            : This function disables the interrupt on INT pin and 
                     clears the corresponding Interrupt flag.
*******************************************************************************/
void CloseINT0(void)
{
    /* Disables external interrupt INT0 */
    IEC0bits.INT0IE = 0;
    IFS0bits.INT0IF = 0;
}

/* end of function CloseINT0 */

#else
#warning "Does not build on this target"
#endif
