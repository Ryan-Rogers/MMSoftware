 
#include <ports.h>

#if defined (int_v1_2) || defined (LIB_BUILD)
/****************************************************************************
Function Prototype : void CloseINT4(void)
 
Include            : ports.h
 
Description        : This function disables the external interrupt on INT pin.
 
Arguments          : None
 
Return Value       : None
 
Remarks            : This function disables the interrupt on INT pin and 
                     clears the corresponding Interrupt flag.
*******************************************************************************/
void CloseINT4(void)
{
    /* Disables external interrupt INT4 */
    IEC3bits.INT4IE = 0;
    IFS3bits.INT4IF = 0;
}
/* end of function CloseINT4 */

#else
#warning "Does not build on this target"
#endif
