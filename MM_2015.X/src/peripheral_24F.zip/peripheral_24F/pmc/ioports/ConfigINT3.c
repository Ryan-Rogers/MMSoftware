 
#include <ports.h>

#if defined (int_v1_2) || defined (LIB_BUILD)
/****************************************************************************
Function Prototype : void ConfigINT3(unsigned int config)
 
Include            : ports.h
 
Description        : This function configures the external interrupt 
 
Arguments          : config - Interrupt edge, priority and enable/disable 
                          information as defined below
						  
					Interrupt edge selection					
					   *	RISING_EDGE_INT					
					   *	FALLING_EDGE_INT					
					Interrupt enable					
					   *	INT_ENABLE					
					   *	INT_DISABLE					
					Interrupt priority					
					   *	INT_PRI_0					
					   *	INT_PRI_1					
					   *	INT_PRI_2					
					   *	INT_PRI_3					
					   *	INT_PRI_4					
					   *	INT_PRI_5					
					   *	INT_PRI_6					
					   *	INT_PRI_7
 
Return Value       : None
 
Remarks            : This function clears the interrupt flag corresponding 
                     to the INTx pin and then selects the edge detect polarity.
                     It then sets the interrupt priority and enables/disables
                     the interrupt.
********************************************************************************/
void ConfigINT3(unsigned int config)
{

    IFS3bits.INT3IF = 0;                       /* clear the interrupt flag */
    IPC13bits.INT3IP = config & 0x07;           /* assign interrupt priority */
    IEC3bits.INT3IE = (config & 0x08) >> 3;    /* enable/disable interrupt */

    INTCON2bits.INT3EP = (config & 0x10) >> 4; /* assign edge selected */

    
}
/* end of function ConfigINT3 */

#else
#warning "Does not build on this target"
#endif
