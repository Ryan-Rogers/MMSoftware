 
#include <ports.h>

#if defined (int_v1_1) || defined (int_v1_2) || defined (LIB_BUILD)
/****************************************************************************
Function Prototype : void CloseINT1(void)
 
Include            : ports.h
 
Description        : This function disables the external interrupt on INT pin.
 
Arguments          : None
 
Return Value       : None
 
Remarks            : This function disables the interrupt on INT pin and 
                     clears the corresponding Interrupt flag.
*******************************************************************************/
void CloseINT1(void)
{
    /* Disables external interrupt INT1 */
    IEC1bits.INT1IE = 0;
    IFS1bits.INT1IF = 0;
}
/* end of function CloseINT1 */

#else
#warning "Does not build on this target"
#endif
