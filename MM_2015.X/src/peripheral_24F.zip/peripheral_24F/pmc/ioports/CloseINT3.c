 
#include <ports.h>

#if defined (int_v1_2) || defined (LIB_BUILD)
/****************************************************************************
Function Prototype : void CloseINT3(void)
 
Include            : ports.h
 
Description        : This function disables the external interrupt on INT pin.
 
Arguments          : None
 
Return Value       : None
 
Remarks            : This function disables the interrupt on INT pin and 
                     clears the corresponding Interrupt flag.
*******************************************************************************/
void CloseINT3(void)
{
    /* Disables external interrupt INT3 */
    IEC3bits.INT3IE = 0;
    IFS3bits.INT3IF =0;
}
/* end of function CloseINT3 */

#else
#warning "Does not build on this target"
#endif
