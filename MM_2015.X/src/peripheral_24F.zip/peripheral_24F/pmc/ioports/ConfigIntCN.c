 
#include<ports.h>

/******************************************************************************
Function Prototype : void ConfigIntCN(unsigned int config)
 
Include            : ports.h
 
Description        : This function configures the CN interrupts.
 
Arguments          :  config - CN interrupt priority and enable/disable information 
                          as defined below						  
                          CN Interrupt enable/disable
							*	INT_ENABLE
							*	INT_DISABLE
						   CN Interrupt priority
	                       *	INT_PRI_0
	                       *	INT_PRI_1
	                       *	INT_PRI_2
	                       *	INT_PRI_3
	                       *	INT_PRI_4
	                       *	INT_PRI_5
	                       *	INT_PRI_6
	                       *	INT_PRI_7
 
Return Value       : None
 
Remarks            : This function clears the Interrupt Flag bit and then sets
                     the interrupt priority and enables/disables the interrupt.
********************************************************************************/
void ConfigIntCN(unsigned int config)
{ 
    IFS1bits.CNIF = 0; /* Clearing the Interrupt Flag bit */
    
    IPC4bits.CNIP = config & 0x07; /* Setting Priority */
    
    IEC1bits.CNIE = (config & 0x08)>>3; /* Setting the Interrupt enable bit */
}
/* end of function ConfigIntCN */
