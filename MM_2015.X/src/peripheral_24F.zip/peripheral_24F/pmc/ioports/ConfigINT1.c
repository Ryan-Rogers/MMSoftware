 
#include<ports.h>

#if defined (int_v1_1) || defined (int_v1_2) || defined (LIB_BUILD)
/****************************************************************************
Function Prototype : void ConfigINT1(unsigned int config)
 
Include            : ports.h
 
Description        : This function configures the external interrupt 
 
Arguments          : config - Interrupt edge, priority and enable/disable 
                          information as defined below
						  
		            Interrupt edge selection					
					   *	RISING_EDGE_INT					
					   *	FALLING_EDGE_INT					
					Interrupt enable					
					   *	INT_ENABLE					
					   *	INT_DISABLE					
					Interrupt priority					
					   *	INT_PRI_0					
					   *	INT_PRI_1					
					   *	INT_PRI_2					
					   *	INT_PRI_3					
					   *	INT_PRI_4					
					   *	INT_PRI_5					
					   *	INT_PRI_6					
					   *	INT_PRI_7
					   
Return Value       : None
 
Remarks            : This function clears the interrupt flag corresponding 
                     to the INTx pin and then selects the edge detect polarity.
                     It then sets the interrupt priority and enables/disables
                     the interrupt.
********************************************************************************/
void ConfigINT1(unsigned int config)
{
    IFS1bits.INT1IF = 0;     /* clear the interrupt flag */

    IPC5bits.INT1IP = config & 0x07;           /* assign interrupt priority  for 33F and 24H*/

    INTCON2bits.INT1EP = (config & 0x10) >> 4; /* assign edge selected */

    IEC1bits.INT1IE = (config & 0x08) >> 3;    /* enable/disable interrupt */
}
/* end of function ConfigINT1 */

#else
#warning "Does not build on this target"
#endif
