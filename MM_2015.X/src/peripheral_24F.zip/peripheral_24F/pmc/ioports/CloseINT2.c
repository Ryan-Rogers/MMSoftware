 
#include <ports.h>

#if defined (int_v1_1) || defined (int_v1_2) || defined (LIB_BUILD)
/****************************************************************************
Function Prototype : void CloseINT2(void)
 
Include            : ports.h
 
Description        : This function disables the external interrupt on INT pin.
 
Arguments          : None
 
Return Value       : None
 
Remarks            : This function disables the interrupt on INT pin and 
                     clears the corresponding Interrupt flag.
*******************************************************************************/
void CloseINT2(void)
{
    /* Disables external interrupt INT2 */
    IEC1bits.INT2IE = 0;
    IFS1bits.INT2IF = 0;
}
/* end of function CloseINT2 */

#else
#warning "Does not build on this target"
#endif
