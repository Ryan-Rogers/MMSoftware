 
#include <ports.h>

/****************************************************************************
Function Prototype : void CloseIntCN(void)
 
Include            : ports.h
 
Description        : This function disables the CN interrupt.
 
Arguments          : None
 
Return Value       : None
 
Remarks            : This function disables the interrupt and 
                     clears the corresponding Interrupt flag.
*******************************************************************************/
void CloseIntCN(void)
{
    /* Disables CN interrupt*/
    IEC1bits.CNIE = 0;
    IFS1bits.CNIF = 0;
}

