#include "comparator.h"

#if defined (cmp_v3_1) || defined (LIB_BUILD)
/**************************************************************************
Function      : void Config_CMP3_v2(unsigned int config1 , unsigned int config2, unsigned int config3, unsigned int config4, unsigned int config5)

Overview      : This routine configures Reference Voltage level and Comparator module.

Parameters    : config1 - This contains the parameters to be configured in the CM3CON register		
	            config2 - This contains the parameters to be configured in the CM3MSKSRC register
				config3 - This contains the parameters to be configured in the CM3MSKCON register
				config4 - This contains the parameters to be configured in the CM3FLTR register
				config5 - This contains the parameters to be configured in the CVRCON register
				
Returns      : None					 

Remarks      : None                                            
**************************************************************************/

void Config_CMP3_v2(unsigned int config1, unsigned int config2, unsigned int config3, unsigned int config4, unsigned int config5) 

{
	CM3CON = config1;
	CM3MSKSRC = config2;
	CM3MSKCON = config3;
	CM3FLTR = config4;
	CVRCON = config5;
}

#else
#warning "Does not build on this target"
#endif
