 
#include "comparator.h"

#if defined (cmp_v1_1)|| defined (LIB_BUILD)
/*********************************************************************************************
 Function  : void Config_CMP(unsigned short int config1 , unsigned short int config2)                      
                                                                                            
 Overview  : This routine configures Reference Voltage level and Comparator module.
             For macros please go to the link cmp_config 
                                                                                            
 Parameters: config1 - This contains the parameters to be configured in the CVRCON 			
			 config2 - This contains the parameters to be configured in the CMCON 					  		 

 Returns     : None					 

 Remarks     : None
**************************************************************************/

void Config_CMP(unsigned short int config1 , unsigned short int config2)
{
   CVRCON = config1 ;
   CMCON = config2 ;
}

#else
#warning "Does not build on this target"
#endif
