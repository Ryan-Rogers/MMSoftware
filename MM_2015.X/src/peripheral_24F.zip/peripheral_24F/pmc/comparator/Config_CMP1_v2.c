#include "comparator.h"

#if defined (cmp_v3_1) || defined (LIB_BUILD)
/**************************************************************************
Function      : void Config_CMP1_v2(unsigned short int config1 , unsigned short int config2, unsigned short int config3, unsigned short int config4, unsigned short int config5)

Overview      : This routine configures Reference Voltage level and Comparator module.

Parameters    : config1 - This contains the parameters to be configured in the CM1CON register		
	            config2 - This contains the parameters to be configured in the CM1MSKSRC register
				config3 - This contains the parameters to be configured in the CM1MSKCON register
				config4 - This contains the parameters to be configured in the CM1FLTR register
				config5 - This contains the parameters to be configured in the CVRCON register
				
Returns      : None					 

Remarks      : None                                            
**************************************************************************/

void Config_CMP1_v2(unsigned int config1, unsigned int config2, unsigned int config3, unsigned int config4, unsigned int config5) 

{
	CM1CON = config1;
	CM1MSKSRC = config2;
	CM1MSKCON = config3;
	CM1FLTR = config4;
	CVRCON = config5;
}

#else
#warning "Does not build on this target"
#endif
