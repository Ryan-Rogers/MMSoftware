#include "comparator.h"

#if defined (cmp_v3_1) || defined (LIB_BUILD)
/**************************************************************************
Function      : void Config_CMP2_v2(unsigned short int config1 , unsigned short int config2, unsigned short int config3, unsigned short int config4, unsigned short int config5)

Overview      : This routine configures Reference Voltage level and Comparator module.

Parameters    : config1 - This contains the parameters to be configured in the CM2CON register		
	            config2 - This contains the parameters to be configured in the CM2MSKSRC register
				config3 - This contains the parameters to be configured in the CM2MSKCON register
				config4 - This contains the parameters to be configured in the CM2FLTR register
				config5 - This contains the parameters to be configured in the CVRCON register
				
Returns      : None					 

Remarks      : None                                            
**************************************************************************/


void Config_CMP2_v2(unsigned int config1, unsigned int config2, unsigned int config3, unsigned int config4, unsigned int config5) 

{
	CM2CON = config1;
	CM2MSKSRC = config2;
	CM2MSKCON = config3;
	CM2FLTR = config4;
	CVRCON = config5;
}

#else
#warning "Does not build on this target"
#endif
