 
#include "comparator.h"

#if defined (cmp_v2_1) || defined (cmp_v2_2) || defined (cmp_v2_3) || defined (cmp_v2_4) ||\
    defined (cmp_v2_5) ||defined (cmp_v2_6) || defined (cmp_v2_7) ||defined (cmp_v2_8) ||\
	defined (cmp_v2_10) || defined (LIB_BUILD)
/**************************************************************************
Function     : void Config_CMP2(unsigned short int config1 , unsigned short int config2)

Overview     : This routine configures Reference Voltage level and Comparator module.

Parameters   : cconfig1 - This contains the parameters to be configured in the CVRCON register		
	           config2 - This contains the parameters to be configured in the CM1CON register 
			   
Returns      : None					 

Remarks      : None                                             
**************************************************************************/

void Config_CMP2(unsigned short int config1 , unsigned short int config2)
{
   CVRCON = config1 ;
   CM2CON = config2 ;
}

#else
#warning "Does not build on this target"
#endif
