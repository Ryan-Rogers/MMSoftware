#include "comparator.h"

#if defined (cmp_v3_1) || defined (LIB_BUILD)

/**************************************************************************
Function      : unsigned int ReadCMPStatus(void)

Overview      : This routine outputs the status of the comparator module.

Parameters    : None

Returns      : unsigned int					 

Remarks      : None                                            
**************************************************************************/

unsigned int ReadCMPStatus(void)
{
	unsigned int i;
	i = CMSTAT;
	return (i);
}
#else
#warning "Does not build on target"
#endif
